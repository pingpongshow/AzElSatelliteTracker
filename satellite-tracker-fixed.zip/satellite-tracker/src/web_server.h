/**
 * @file web_server.h
 * @brief Web server for UI and REST API
 * 
 * Provides web-based user interface and REST API endpoints
 * for controlling the satellite tracker, including camera
 * streaming and advanced features.
 */

#ifndef WEB_SERVER_H
#define WEB_SERVER_H

#include <Arduino.h>
#include <ESPAsyncWebServer.h>
#include <ArduinoJson.h>
#include <vector>
#include "config.h"

/**
 * @class WebServer
 * @brief Async web server with REST API and camera streaming
 */
class WebServer {
public:
    WebServer();
    ~WebServer();
    
    /**
     * @brief Initialize and start web server
     * @return true if started successfully
     */
    bool begin();
    
    /**
     * @brief Stop web server
     */
    void stop();
    
    /**
     * @brief Update server (broadcast status via WebSocket)
     */
    void update();
    
    /**
     * @brief Check if server is running
     */
    bool isRunning() const { return _running; }
    
    /**
     * @brief Broadcast status to all WebSocket clients
     */
    void broadcastStatus();
    
    /**
     * @brief Send event to WebSocket clients
     * @param event Event name
     * @param data Event data as JSON string
     */
    void sendEvent(const char* event, const char* data);
    
    /**
     * @brief Get number of connected WebSocket clients
     */
    int getClientCount() const;

private:
    AsyncWebServer* _server;
    AsyncWebSocket* _ws;
    bool _running;
    uint32_t _lastBroadcast;
    
    // Camera stream state
    bool _streamActive;
    
    // Track JSON handlers for cleanup on restart
    std::vector<AsyncCallbackJsonWebHandler*> _jsonHandlers;
    
    // Route setup
    void setupRoutes();
    void setupAPIRoutes();
    void setupCameraRoutes();
    void setupAdvancedRoutes();
    void setupWebSocketHandler();
    
    // Static file handlers
    void handleRoot(AsyncWebServerRequest* request);
    void handleNotFound(AsyncWebServerRequest* request);
    
    // API handlers - Status
    void handleGetStatus(AsyncWebServerRequest* request);
    void handleGetPosition(AsyncWebServerRequest* request);
    void handleGetGPS(AsyncWebServerRequest* request);
    void handleGetConfig(AsyncWebServerRequest* request);
    
    // API handlers - Control
    void handleSetPosition(AsyncWebServerRequest* request, JsonVariant& json);
    void handleStop(AsyncWebServerRequest* request);
    void handlePark(AsyncWebServerRequest* request);
    void handleHome(AsyncWebServerRequest* request);
    void handleSetHome(AsyncWebServerRequest* request);
    void handleCalibrate(AsyncWebServerRequest* request, JsonVariant& json);
    
    // API handlers - Tracking
    void handleStartTracking(AsyncWebServerRequest* request, JsonVariant& json);
    void handleStopTracking(AsyncWebServerRequest* request);
    void handleGetNextPass(AsyncWebServerRequest* request);
    
    // API handlers - TLE
    void handleGetTLEs(AsyncWebServerRequest* request);
    void handleLoadTLE(AsyncWebServerRequest* request, JsonVariant& json);
    void handleFetchTLE(AsyncWebServerRequest* request, JsonVariant& json);
    void handleDeleteTLE(AsyncWebServerRequest* request, JsonVariant& json);
    
    // API handlers - WiFi
    void handleGetNetworks(AsyncWebServerRequest* request);
    void handleConnectWiFi(AsyncWebServerRequest* request, JsonVariant& json);
    void handleGetWiFiStatus(AsyncWebServerRequest* request);
    
    // API handlers - System
    void handleReboot(AsyncWebServerRequest* request);
    void handleFactoryReset(AsyncWebServerRequest* request);
    void handleGetSystemInfo(AsyncWebServerRequest* request);
    void handleSetConfig(AsyncWebServerRequest* request, JsonVariant& json);
    
    // API handlers - GPS
    void handleSetManualGPS(AsyncWebServerRequest* request, JsonVariant& json);
    
    // =========================================================================
    // NEW: Camera streaming handlers
    // =========================================================================
    void handleCameraSnapshot(AsyncWebServerRequest* request);
    void handleCameraSnapshotWithOverlay(AsyncWebServerRequest* request);
    void handleCameraStream(AsyncWebServerRequest* request);
    void handleCameraSettings(AsyncWebServerRequest* request, JsonVariant& json);
    void handleCameraDetect(AsyncWebServerRequest* request);
    
    // =========================================================================
    // NEW: Multi-pass prediction handlers
    // =========================================================================
    void handleGetPasses(AsyncWebServerRequest* request);
    void handleSchedulePass(AsyncWebServerRequest* request, JsonVariant& json);
    void handleCancelPass(AsyncWebServerRequest* request, JsonVariant& json);
    void handleGetSchedule(AsyncWebServerRequest* request);
    void handleClearSchedule(AsyncWebServerRequest* request);
    
    // =========================================================================
    // NEW: Doppler calculation handlers
    // =========================================================================
    void handleGetDoppler(AsyncWebServerRequest* request);
    
    // =========================================================================
    // NEW: Health monitoring handlers
    // =========================================================================
    void handleGetHealth(AsyncWebServerRequest* request);
    void handleGetHealthEvents(AsyncWebServerRequest* request);
    void handleClearHealthEvents(AsyncWebServerRequest* request);
    
    // =========================================================================
    // NEW: SD card handlers
    // =========================================================================
    void handleSDStatus(AsyncWebServerRequest* request);
    void handleSDListTLEs(AsyncWebServerRequest* request);
    void handleSDImportTLE(AsyncWebServerRequest* request, JsonVariant& json);
    void handleSDExportTLEs(AsyncWebServerRequest* request);
    void handleSDBackupConfig(AsyncWebServerRequest* request);
    void handleSDRestoreConfig(AsyncWebServerRequest* request);
    void handleGetPassLog(AsyncWebServerRequest* request);
    void handleExportPassLog(AsyncWebServerRequest* request);
    
    // =========================================================================
    // NEW: External API handlers
    // =========================================================================
    void handleSetN2YOKey(AsyncWebServerRequest* request, JsonVariant& json);
    void handleFetchN2YOTLE(AsyncWebServerRequest* request, JsonVariant& json);
    void handleGetVisualPasses(AsyncWebServerRequest* request);
    void handleSearchSatNOGS(AsyncWebServerRequest* request);
    void handleGetTransmitters(AsyncWebServerRequest* request);
    void handleFetchTLEGroup(AsyncWebServerRequest* request, JsonVariant& json);
    
    // =========================================================================
    // NEW: UDP broadcast handlers
    // =========================================================================
    void handleUDPConfig(AsyncWebServerRequest* request, JsonVariant& json);
    void handleUDPStatus(AsyncWebServerRequest* request);
    
    // =========================================================================
    // NEW: EME mode handlers
    // =========================================================================
    void handleEnableEME(AsyncWebServerRequest* request);
    void handleDisableEME(AsyncWebServerRequest* request);
    void handleGetMoonInfo(AsyncWebServerRequest* request);
    void handleGetEMEPathLoss(AsyncWebServerRequest* request);
    
    // =========================================================================
    // NEW: Geo satellite handlers
    // =========================================================================
    void handlePointToGeo(AsyncWebServerRequest* request, JsonVariant& json);
    void handleEnableGeoTracking(AsyncWebServerRequest* request, JsonVariant& json);
    void handleDisableGeoTracking(AsyncWebServerRequest* request);
    
    // =========================================================================
    // NEW: Antenna pattern handlers
    // =========================================================================
    void handleGetAntennaPattern(AsyncWebServerRequest* request);
    void handleSetAntennaPattern(AsyncWebServerRequest* request, JsonVariant& json);
    
    // =========================================================================
    // NEW: Pre-positioning handlers
    // =========================================================================
    void handleSetPrePosition(AsyncWebServerRequest* request, JsonVariant& json);
    
    // WebSocket handler
    void onWebSocketEvent(AsyncWebSocket* server, AsyncWebSocketClient* client,
                          AwsEventType type, void* arg, uint8_t* data, size_t len);
    
    // Helper methods
    void sendJSON(AsyncWebServerRequest* request, JsonDocument& doc, int code = 200);
    void sendError(AsyncWebServerRequest* request, const char* message, int code = 400);
    void sendOK(AsyncWebServerRequest* request, const char* message = "OK");
    String buildStatusJSON();
    String buildPassJSON(const PassInfo& pass);
};

// Global instance
extern WebServer webServer;

#endif // WEB_SERVER_H
