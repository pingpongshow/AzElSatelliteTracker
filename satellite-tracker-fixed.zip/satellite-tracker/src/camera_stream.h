/**
 * @file camera_stream.h
 * @brief MJPEG camera streaming server with overlay support
 * 
 * Provides live camera preview via MJPEG stream with optional
 * overlay showing crosshairs, detected blob, and position info.
 */

#ifndef CAMERA_STREAM_H
#define CAMERA_STREAM_H

#include <Arduino.h>
#include <WiFi.h>
#include <esp_http_server.h>
#include "config.h"
#include "camera_align.h"

/**
 * @class CameraStream
 * @brief MJPEG streaming server
 */
class CameraStream {
public:
    CameraStream();
    
    /**
     * @brief Start streaming server
     * @param port Server port (default 81)
     * @return true if started successfully
     */
    bool begin(uint16_t port = CAMERA_STREAM_PORT);
    
    /**
     * @brief Stop streaming server
     */
    void stop();
    
    /**
     * @brief Check if server is running
     */
    bool isRunning() const { return _running; }
    
    /**
     * @brief Enable/disable overlay on stream
     */
    void setOverlayEnabled(bool enabled) { _overlayEnabled = enabled; }
    
    /**
     * @brief Set overlay configuration
     */
    void setOverlay(const CameraOverlay& overlay) { _overlay = overlay; }
    
    /**
     * @brief Get current client count
     */
    int getClientCount() const { return _clientCount; }
    
    /**
     * @brief Get streaming URL
     */
    String getStreamUrl() const;

private:
    httpd_handle_t _server;
    bool _running;
    uint16_t _port;
    bool _overlayEnabled;
    CameraOverlay _overlay;
    volatile int _clientCount;
    
    static esp_err_t streamHandler(httpd_req_t* req);
    static esp_err_t snapshotHandler(httpd_req_t* req);
    static esp_err_t indexHandler(httpd_req_t* req);
};

// Global instance
extern CameraStream cameraStream;

#endif // CAMERA_STREAM_H
