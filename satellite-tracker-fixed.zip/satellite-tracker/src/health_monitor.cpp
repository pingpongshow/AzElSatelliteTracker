/**
 * @file health_monitor.cpp
 * @brief System health monitoring implementation
 */

#include "health_monitor.h"
#include "gps.h"
#include "stepper_control.h"
#include "wifi_manager.h"
#include "camera_align.h"
#include <WiFi.h>

// Global instance
HealthMonitor healthMonitor;

HealthMonitor::HealthMonitor()
    : _watchdogEnabled(false)
    , _autoRecovery(true)
    , _lastCheckMs(0)
    , _eventHead(0)
    , _eventCount(0)
{
    memset(&_status, 0, sizeof(HealthStatus));
    _status.overallHealthy = true;
}

bool HealthMonitor::begin(bool enableWatchdog) {
    DEBUG_PRINTLN("HealthMonitor: Initializing...");
    
    if (enableWatchdog) {
        // Initialize Task Watchdog Timer
        esp_task_wdt_init(WATCHDOG_TIMEOUT_MS / 1000, true);
        esp_task_wdt_add(NULL);  // Add current task
        _watchdogEnabled = true;
        DEBUG_PRINTF("HealthMonitor: Watchdog enabled (%d ms)\n", WATCHDOG_TIMEOUT_MS);
    }
    
    _lastCheckMs = millis();
    _status.uptime = 0;
    _status.minFreeHeap = ESP.getFreeHeap();
    
    DEBUG_PRINTLN("HealthMonitor: Initialization complete");
    return true;
}

void HealthMonitor::update() {
    uint32_t now = millis();
    
    // Feed watchdog
    if (_watchdogEnabled) {
        feedWatchdog();
    }
    
    // Periodic health check
    if (now - _lastCheckMs >= HEALTH_CHECK_INTERVAL_MS) {
        checkNow();
        _lastCheckMs = now;
    }
    
    _status.uptime = now / 1000;
}

void HealthMonitor::feedWatchdog() {
    if (_watchdogEnabled) {
        esp_task_wdt_reset();
    }
}

void HealthMonitor::checkNow() {
    // Update memory stats
    _status.freeHeap = ESP.getFreeHeap();
    _status.freePsram = ESP.getFreePsram();
    
    if (_status.freeHeap < _status.minFreeHeap) {
        _status.minFreeHeap = _status.freeHeap;
    }
    
    // Run all health checks
    _status.gpsHealthy = checkGPSHealth();
    _status.motorAzHealthy = checkMotorHealth();
    _status.motorElHealthy = _status.motorAzHealthy;  // Combined check
    _status.wifiHealthy = checkNetworkHealth();
    _status.memoryHealthy = checkMemoryHealth();
    _status.cameraHealthy = checkCameraHealth();
    
    // Overall health
    _status.overallHealthy = _status.gpsHealthy && 
                              _status.motorAzHealthy &&
                              _status.wifiHealthy && 
                              _status.memoryHealthy;
}

bool HealthMonitor::checkGPSHealth() {
    GPSData data = gps.getData();
    _status.gpsAge = data.age;
    
    // Check for stale data
    if (data.age > GPS_STALE_TIMEOUT_MS) {
        if (_status.lastIssue != HealthIssue::GPS_STALE) {
            logEvent(HealthIssue::GPS_STALE, "GPS data stale");
            if (_autoRecovery) recoverGPS();
        }
        return false;
    }
    
    // Check for fix (allow manual position)
    if (!data.valid && !gps.isUsingManualPosition()) {
        if (_status.lastIssue != HealthIssue::GPS_NO_FIX) {
            logEvent(HealthIssue::GPS_NO_FIX, "No GPS fix");
        }
        return false;
    }
    
    return true;
}

bool HealthMonitor::checkMotorHealth() {
    // Check driver communication
    if (!stepperControl.driversConnected()) {
        if (_status.lastIssue != HealthIssue::MOTOR_COMM_FAIL) {
            logEvent(HealthIssue::MOTOR_COMM_FAIL, "Motor driver communication failed");
            if (_autoRecovery) recoverMotor();
        }
        return false;
    }
    
    // Check for stalls
    if (stepperControl.getState(Axis::AZIMUTH) == MotorState::STALLED ||
        stepperControl.getState(Axis::ELEVATION) == MotorState::STALLED) {
        if (_status.lastIssue != HealthIssue::MOTOR_STALL) {
            logEvent(HealthIssue::MOTOR_STALL, "Motor stall detected");
            if (_autoRecovery) recoverMotor();
        }
        return false;
    }
    
    // Get driver temperatures (from DRV_STATUS)
    uint32_t azStatus = stepperControl.getDriverStatus(Axis::AZIMUTH);
    uint32_t elStatus = stepperControl.getDriverStatus(Axis::ELEVATION);
    
    // Check overtemperature flags (bit 1 = ot, bit 2 = otpw)
    if ((azStatus & 0x06) || (elStatus & 0x06)) {
        if (_status.lastIssue != HealthIssue::MOTOR_OVERTEMP) {
            logEvent(HealthIssue::MOTOR_OVERTEMP, "Motor driver overtemperature");
            if (_autoRecovery) {
                stepperControl.stop();
                stepperControl.setEnabled(false);
            }
        }
        return false;
    }
    
    return true;
}

bool HealthMonitor::checkNetworkHealth() {
    _status.wifiRSSI = wifiManager.getRSSI();
    
    // Check connection
    if (!wifiManager.isConnected() && !wifiManager.isAPMode()) {
        if (_status.lastIssue != HealthIssue::WIFI_DISCONNECTED) {
            logEvent(HealthIssue::WIFI_DISCONNECTED, "WiFi disconnected");
            if (_autoRecovery) recoverNetwork();
        }
        return false;
    }
    
    // Check signal strength (only in station mode)
    if (wifiManager.isConnected() && _status.wifiRSSI < WIFI_MIN_RSSI) {
        if (_status.lastIssue != HealthIssue::WIFI_WEAK_SIGNAL) {
            logEvent(HealthIssue::WIFI_WEAK_SIGNAL, "Weak WiFi signal");
        }
        // Don't fail health for weak signal, just warn
    }
    
    return true;
}

bool HealthMonitor::checkMemoryHealth() {
    // Check heap
    if (_status.freeHeap < HEAP_MIN_FREE_BYTES) {
        if (_status.lastIssue != HealthIssue::HEAP_LOW) {
            logEvent(HealthIssue::HEAP_LOW, "Low heap memory");
        }
        return false;
    }
    
    // Check for fragmentation (largest free block vs total free)
    size_t largestBlock = ESP.getMaxAllocHeap();
    if (largestBlock < _status.freeHeap / 2) {
        if (_status.lastIssue != HealthIssue::HEAP_FRAGMENTED) {
            logEvent(HealthIssue::HEAP_FRAGMENTED, "Heap fragmentation detected");
        }
        // Don't fail for fragmentation, just warn
    }
    
    return true;
}

bool HealthMonitor::checkCameraHealth() {
    if (!cameraAlign.isInitialized()) {
        // Camera not initialized - may be intentional
        return true;
    }
    
    // Try to get a frame to verify camera is working
    size_t len;
    const uint8_t* frame = cameraAlign.getLastFrame(len);
    
    if (!frame || len == 0) {
        if (_status.lastIssue != HealthIssue::CAMERA_FAIL) {
            logEvent(HealthIssue::CAMERA_FAIL, "Camera capture failed");
            if (_autoRecovery) recoverCamera();
        }
        return false;
    }
    
    return true;
}

void HealthMonitor::attemptRecovery(HealthIssue issue) {
    switch (issue) {
        case HealthIssue::GPS_STALE:
        case HealthIssue::GPS_NO_FIX:
            recoverGPS();
            break;
            
        case HealthIssue::MOTOR_STALL:
        case HealthIssue::MOTOR_COMM_FAIL:
        case HealthIssue::MOTOR_OVERTEMP:
            recoverMotor();
            break;
            
        case HealthIssue::WIFI_DISCONNECTED:
        case HealthIssue::WIFI_WEAK_SIGNAL:
            recoverNetwork();
            break;
            
        case HealthIssue::CAMERA_FAIL:
            recoverCamera();
            break;
            
        default:
            break;
    }
}

void HealthMonitor::recoverGPS() {
    DEBUG_PRINTLN("HealthMonitor: Attempting GPS recovery...");
    // GPS recovery is mostly passive - just wait for fix
    // Could send reset command to GPS module if supported
}

void HealthMonitor::recoverMotor() {
    DEBUG_PRINTLN("HealthMonitor: Attempting motor recovery...");
    
    // Stop motion
    stepperControl.stop();
    
    // Brief disable then re-enable
    stepperControl.setEnabled(false);
    delay(500);
    stepperControl.setEnabled(true);
    
    logRecovery(HealthIssue::MOTOR_STALL);
}

void HealthMonitor::recoverNetwork() {
    DEBUG_PRINTLN("HealthMonitor: Attempting network recovery...");
    // WiFiManager handles reconnection automatically
}

void HealthMonitor::recoverCamera() {
    DEBUG_PRINTLN("HealthMonitor: Attempting camera recovery...");
    
    // Deinitialize and reinitialize camera
    esp_camera_deinit();
    delay(500);
    
    if (cameraAlign.begin()) {
        logRecovery(HealthIssue::CAMERA_FAIL);
    }
}

void HealthMonitor::logEvent(HealthIssue issue, const char* description) {
    HealthEvent event;
    event.timestamp = millis() / 1000;
    event.issue = issue;
    event.resolved = false;
    strncpy(event.description, description, sizeof(event.description) - 1);
    event.description[sizeof(event.description) - 1] = '\0';
    
    // Add to circular buffer
    _eventLog[_eventHead] = event;
    _eventHead = (_eventHead + 1) % MAX_EVENTS;
    if (_eventCount < MAX_EVENTS) _eventCount++;
    
    // Update status
    _status.lastIssue = issue;
    _status.issueCount++;
    _status.lastIssueTime = event.timestamp;
    
    DEBUG_PRINTF("HealthMonitor: %s\n", description);
}

void HealthMonitor::logRecovery(HealthIssue issue) {
    // Mark last matching issue as resolved
    for (int i = _eventCount - 1; i >= 0; i--) {
        int idx = (_eventHead - 1 - i + MAX_EVENTS) % MAX_EVENTS;
        if (_eventLog[idx].issue == issue && !_eventLog[idx].resolved) {
            _eventLog[idx].resolved = true;
            break;
        }
    }
    
    DEBUG_PRINTF("HealthMonitor: Recovered from issue %d\n", (int)issue);
}

int HealthMonitor::getEventLog(HealthEvent* events, int maxEvents) {
    int count = min(_eventCount, maxEvents);
    
    for (int i = 0; i < count; i++) {
        int idx = (_eventHead - _eventCount + i + MAX_EVENTS) % MAX_EVENTS;
        events[i] = _eventLog[idx];
    }
    
    return count;
}

void HealthMonitor::clearEventLog() {
    _eventHead = 0;
    _eventCount = 0;
    _status.issueCount = 0;
}

String HealthMonitor::getStatusString() const {
    String status = "Health: ";
    
    if (_status.overallHealthy) {
        status += "OK";
    } else {
        status += "ISSUES - ";
        if (!_status.gpsHealthy) status += "GPS ";
        if (!_status.motorAzHealthy) status += "Motor ";
        if (!_status.wifiHealthy) status += "WiFi ";
        if (!_status.memoryHealthy) status += "Memory ";
        if (!_status.cameraHealthy) status += "Camera ";
    }
    
    status += " | Heap: " + String(_status.freeHeap / 1024) + "KB";
    status += " | Up: " + String(_status.uptime / 3600) + "h";
    
    return status;
}
