/**
 * @file config.h
 * @brief Main configuration file for Az/El Satellite Tracker
 * 
 * This file contains all pin definitions, constants, and configuration
 * parameters for the satellite tracker system.
 * 
 * Hardware:
 * - ESP32-S3-CAM
 * - TMC2209 stepper drivers (x2)
 * - NEMA 17 5.18:1 geared steppers (x2)
 * - GPS module (NMEA)
 * - OV2640 camera
 */

#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

// =============================================================================
// VERSION INFO
// =============================================================================
#define FIRMWARE_VERSION "1.0.0"
#define DEVICE_NAME "SatTracker"
#define DEVICE_MODEL "AzEl-S3"

// =============================================================================
// WIFI CONFIGURATION
// =============================================================================
#define WIFI_CONNECT_TIMEOUT_MS     15000
#define WIFI_RECONNECT_INTERVAL_MS  30000

// Access Point configuration (fallback mode)
#define AP_SSID                     "SatTracker-AP"
#define AP_PASSWORD                 "satellite123"
#define AP_CHANNEL                  6
#define AP_MAX_CONNECTIONS          4

// mDNS hostname
#define MDNS_HOSTNAME               "satellite-tracker"

// =============================================================================
// WEB SERVER CONFIGURATION
// =============================================================================
#define WEB_SERVER_PORT             80
#define WEBSOCKET_PORT              81
#define API_PREFIX                  "/api"

// =============================================================================
// ROTCTLD CONFIGURATION (Hamlib protocol)
// =============================================================================
#define ROTCTLD_PORT                4533
#define ROTCTLD_MAX_CLIENTS         2
#define ROTCTLD_BUFFER_SIZE         256

// =============================================================================
// TMC2209 STEPPER DRIVER PINS
// =============================================================================
// Note: These pins are selected to avoid conflicts with camera DVP interface

// Azimuth motor
#define TMC_AZ_STEP_PIN             38
#define TMC_AZ_DIR_PIN              39
#define TMC_AZ_DIAG_PIN             40      // StallGuard diagnostic output

// Elevation motor  
#define TMC_EL_STEP_PIN             41
#define TMC_EL_DIR_PIN              42
#define TMC_EL_DIAG_PIN             2       // StallGuard diagnostic output

// Shared pins
#define TMC_EN_PIN                  1       // Shared enable (active LOW)
#define TMC_UART_TX_PIN             43      // UART TX to both drivers
#define TMC_UART_RX_PIN             44      // UART RX from both drivers

// TMC2209 UART addresses (directly wired to MS1/MS2)
#define TMC_AZ_ADDRESS              0b00    // MS1=LOW, MS2=LOW
#define TMC_EL_ADDRESS              0b01    // MS1=HIGH, MS2=LOW

// =============================================================================
// TMC2209 MOTOR CONFIGURATION
// =============================================================================
#define TMC_SERIAL_BAUD             115200
#define TMC_R_SENSE                 0.11f   // Sense resistor value (ohms)

// Motor current settings (RMS milliamps)
#define MOTOR_RUN_CURRENT_MA        800     // Running current
#define MOTOR_HOLD_CURRENT_MA       400     // Holding current
#define MOTOR_HOLD_MULTIPLIER       0.5f    // Hold current = run * multiplier

// Microstepping (256 is max for TMC2209)
#define TMC_MICROSTEPS              32      // Balance of resolution vs speed

// StallGuard threshold (0-255, lower = more sensitive)
#define TMC_STALL_THRESHOLD         50

// =============================================================================
// STEPPER MOTOR MECHANICAL CONFIGURATION
// =============================================================================
#define STEPS_PER_REV               200     // 1.8° stepper
#define GEAR_RATIO                  5.18f   // 5.18:1 geared stepper

// Calculated steps per degree
// (STEPS_PER_REV * GEAR_RATIO * TMC_MICROSTEPS) / 360
#define STEPS_PER_DEGREE            ((STEPS_PER_REV * GEAR_RATIO * TMC_MICROSTEPS) / 360.0f)

// Speed limits (degrees per second)
#define MAX_SLEW_SPEED_DEG_S        30.0f   // Fast repositioning
#define TRACKING_SPEED_DEG_S        5.0f    // Normal tracking
#define HOMING_SPEED_DEG_S          10.0f   // Homing speed

// Acceleration (degrees per second squared)
#define ACCELERATION_DEG_S2         20.0f

// =============================================================================
// AXIS LIMITS
// =============================================================================
// Azimuth limits (continuous rotation possible, but limit for safety)
#define AZ_MIN_DEG                  -180.0f
#define AZ_MAX_DEG                  540.0f  // Allow 1.5 rotations for cable wrap

// Elevation limits
#define EL_MIN_DEG                  0.0f
#define EL_MAX_DEG                  90.0f

// Zenith avoidance threshold
#define ZENITH_THRESHOLD_DEG        87.0f   // Start flip planning above this

// Park position
#define PARK_AZ_DEG                 0.0f
#define PARK_EL_DEG                 45.0f

// =============================================================================
// GPS CONFIGURATION
// =============================================================================
#define GPS_SERIAL_NUM              1       // Hardware serial port number
#define GPS_RX_PIN                  14      // GPS TX -> ESP RX
#define GPS_TX_PIN                  21      // ESP TX -> GPS RX  
#define GPS_BAUD                    9600

// GPS timeout and update intervals
#define GPS_FIX_TIMEOUT_MS          120000  // 2 minutes to get fix
#define GPS_UPDATE_INTERVAL_MS      1000    // Position update rate

// Default position (used before GPS fix)
// Set this to your approximate location
#define DEFAULT_LATITUDE            40.7128f    // New York City
#define DEFAULT_LONGITUDE           -74.0060f
#define DEFAULT_ALTITUDE            10.0f       // meters

// =============================================================================
// CAMERA CONFIGURATION
// =============================================================================
#define CAMERA_FB_COUNT             2
#define CAMERA_JPEG_QUALITY         10      // 0-63, lower = better quality
#define CAMERA_FRAME_SIZE           FRAMESIZE_VGA   // 640x480

// Alignment detection thresholds
#define SUN_BRIGHTNESS_THRESHOLD    240     // Pixel value for sun detection
#define MOON_BRIGHTNESS_THRESHOLD   180     // Pixel value for moon detection
#define MIN_BLOB_PIXELS             100     // Minimum pixels for valid detection
#define ALIGNMENT_TOLERANCE_DEG     0.5f    // Acceptable alignment error

// Camera field of view (degrees) - approximate for OV2640 with standard lens
#define CAMERA_FOV_H                60.0f
#define CAMERA_FOV_V                45.0f

// =============================================================================
// TRACKING ENGINE CONFIGURATION
// =============================================================================
// TLE update interval (milliseconds)
#define TLE_UPDATE_INTERVAL_MS      86400000    // 24 hours
#define TLE_FETCH_TIMEOUT_MS        30000       // 30 seconds

// TLE sources
#define TLE_SOURCE_CELESTRAK        "https://celestrak.org/NORAD/elements/gp.php"
#define TLE_SOURCE_AMATEUR          "https://celestrak.org/NORAD/elements/gp.php?GROUP=amateur&FORMAT=tle"

// Maximum stored TLEs
#define MAX_STORED_TLES             20

// Position calculation interval during tracking
#define TRACKING_UPDATE_INTERVAL_MS 100     // 10 Hz update rate

// Look-ahead time for zenith flip prediction (seconds)
#define ZENITH_LOOKAHEAD_SEC        10

// =============================================================================
// NVS STORAGE KEYS
// =============================================================================
#define NVS_NAMESPACE               "sattracker"
#define NVS_KEY_WIFI_SSID           "wifi_ssid"
#define NVS_KEY_WIFI_PASS           "wifi_pass"
#define NVS_KEY_AZ_OFFSET           "az_offset"
#define NVS_KEY_EL_OFFSET           "el_offset"
#define NVS_KEY_AZ_POSITION         "az_pos"
#define NVS_KEY_EL_POSITION         "el_pos"
#define NVS_KEY_LATITUDE            "latitude"
#define NVS_KEY_LONGITUDE           "longitude"
#define NVS_KEY_ALTITUDE            "altitude"
#define NVS_KEY_TRACKING_SAT        "track_sat"

// =============================================================================
// TIMING AND SCHEDULING
// =============================================================================
#define MAIN_LOOP_INTERVAL_MS       10      // Main loop target interval
#define STATUS_UPDATE_INTERVAL_MS   500     // Status broadcast to WebSocket
#define POSITION_SAVE_INTERVAL_MS   60000   // Save position to NVS

// =============================================================================
// DEBUG CONFIGURATION
// =============================================================================
#define DEBUG_SERIAL                Serial
#define DEBUG_BAUD                  115200

#ifdef CORE_DEBUG_LEVEL
    #if CORE_DEBUG_LEVEL >= 3
        #define DEBUG_PRINT(x)      DEBUG_SERIAL.print(x)
        #define DEBUG_PRINTLN(x)    DEBUG_SERIAL.println(x)
        #define DEBUG_PRINTF(...)   DEBUG_SERIAL.printf(__VA_ARGS__)
    #else
        #define DEBUG_PRINT(x)
        #define DEBUG_PRINTLN(x)
        #define DEBUG_PRINTF(...)
    #endif
#else
    #define DEBUG_PRINT(x)
    #define DEBUG_PRINTLN(x)
    #define DEBUG_PRINTF(...)
#endif

// =============================================================================
// TASK PRIORITIES (FreeRTOS)
// =============================================================================
#define TASK_PRIORITY_STEPPER       5       // Highest - motor control
#define TASK_PRIORITY_GPS           3       // Medium - GPS parsing
#define TASK_PRIORITY_TRACKING      3       // Medium - position calculation
#define TASK_PRIORITY_NETWORK       2       // Lower - web/API
#define TASK_PRIORITY_CAMERA        1       // Lowest - alignment

// Task stack sizes (words)
#define TASK_STACK_STEPPER          4096
#define TASK_STACK_GPS              2048
#define TASK_STACK_TRACKING         4096
#define TASK_STACK_NETWORK          8192
#define TASK_STACK_CAMERA           8192

// =============================================================================
// MULTI-PASS PREDICTION & SCHEDULING
// =============================================================================
#define MAX_PREDICTED_PASSES        20      // Maximum passes to predict
#define MAX_SCHEDULED_PASSES        10      // Maximum scheduled auto-track passes
#define PASS_SEARCH_HOURS           48      // Hours to search ahead
#define PASS_MIN_ELEVATION          5.0f    // Minimum max elevation for valid pass
#define PRE_POSITION_SECONDS        120     // Seconds before AOS to pre-position
#define PRE_POSITION_ELEVATION      5.0f    // Elevation to start at for pre-position

// =============================================================================
// DOPPLER CONFIGURATION
// =============================================================================
#define SPEED_OF_LIGHT_KMS          299792.458  // km/s

// =============================================================================
// CAMERA STREAMING
// =============================================================================
#define CAMERA_STREAM_PORT          81
#define CAMERA_STREAM_FPS           10
#define ALIGNMENT_CROSSHAIR_SIZE    20      // Pixels
#define BLOB_MARKER_RADIUS          15      // Pixels

// =============================================================================
// HEALTH MONITORING & WATCHDOG
// =============================================================================
#define WATCHDOG_TIMEOUT_MS         30000   // 30 second watchdog
#define HEALTH_CHECK_INTERVAL_MS    5000    // Check health every 5 seconds
#define GPS_STALE_TIMEOUT_MS        10000   // GPS data stale after 10 seconds
#define WIFI_MIN_RSSI               -80     // Minimum acceptable RSSI
#define HEAP_MIN_FREE_BYTES         20000   // Minimum free heap warning
#define MOTOR_MAX_TEMP_C            80      // TMC2209 temperature limit

// =============================================================================
// EXTERNAL API INTEGRATION
// =============================================================================
#define N2YO_API_URL                "https://api.n2yo.com/rest/v1/satellite"
#define N2YO_API_TIMEOUT_MS         15000
#define SATNOGS_API_URL             "https://db.satnogs.org/api"
#define CELESTRAK_API_URL           "https://celestrak.org/NORAD/elements/gp.php"

// =============================================================================
// UDP BROADCAST (GPredict compatible)
// =============================================================================
#define UDP_BROADCAST_PORT          4532
#define UDP_BROADCAST_INTERVAL_MS   100     // 10 Hz update rate
#define UDP_MULTICAST_ADDR          "239.255.0.1"

// =============================================================================
// SD CARD CONFIGURATION
// =============================================================================
#define SD_CS_PIN                   -1      // Set to actual CS pin if using SD
#define SD_SPI_FREQ_MHZ             20
#define TLE_STORAGE_DIR             "/tle"
#define PASS_LOG_DIR                "/logs"
#define CONFIG_BACKUP_FILE          "/config.json"

// =============================================================================
// ANTENNA PATTERN COMPENSATION
// =============================================================================
#define DEFAULT_AZ_BEAM_OFFSET      0.0f    // Degrees
#define DEFAULT_EL_BEAM_OFFSET      0.0f    // Degrees
#define DEFAULT_BEAMWIDTH           30.0f   // Degrees (3dB beamwidth)

// =============================================================================
// EME (MOON BOUNCE) MODE
// =============================================================================
#define EME_TRACKING_RATE           0.5f    // Slower tracking for EME
#define EME_MOON_RADIUS_KM          1737.4  // For libration calculations
#define EME_AVG_DISTANCE_KM         384400  // Average Earth-Moon distance

// =============================================================================
// GEOSTATIONARY SATELLITE MODE
// =============================================================================
#define GEO_ALTITUDE_KM             35786   // Geostationary orbit altitude
#define GEO_POSITION_TOLERANCE      0.1f    // Degrees - repoint if drift exceeds
#define GEO_UPDATE_INTERVAL_MS      60000   // Check geo position every minute

#endif // CONFIG_H
