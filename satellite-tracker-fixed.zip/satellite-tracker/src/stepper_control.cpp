/**
 * @file stepper_control.cpp
 * @brief TMC2209 stepper motor control implementation
 */

#include "stepper_control.h"

// Global instance
StepperControl stepperControl;

StepperControl::StepperControl() 
    : _tmcAz(nullptr)
    , _tmcEl(nullptr)
    , _tmcSerial(nullptr)
    , _azState(MotorState::IDLE)
    , _elState(MotorState::IDLE)
    , _azOffset(0.0f)
    , _elOffset(0.0f)
    , _enabled(false)
    , _lastUpdateMicros(0)
    , _azLastStepMicros(0)
    , _elLastStepMicros(0)
    , _profileMutex(nullptr)
{
    // Initialize motion profiles
    memset(&_azProfile, 0, sizeof(MotionProfile));
    memset(&_elProfile, 0, sizeof(MotionProfile));
    
    _azProfile.maxSpeed = TRACKING_SPEED_DEG_S;
    _elProfile.maxSpeed = TRACKING_SPEED_DEG_S;
    _azProfile.acceleration = ACCELERATION_DEG_S2;
    _elProfile.acceleration = ACCELERATION_DEG_S2;
    
    // Create mutex for thread-safe profile access
    _profileMutex = xSemaphoreCreateMutex();
}

bool StepperControl::begin() {
    DEBUG_PRINTLN("StepperControl: Initializing...");
    
    // Configure GPIO pins
    pinMode(TMC_AZ_STEP_PIN, OUTPUT);
    pinMode(TMC_AZ_DIR_PIN, OUTPUT);
    pinMode(TMC_AZ_DIAG_PIN, INPUT);
    
    pinMode(TMC_EL_STEP_PIN, OUTPUT);
    pinMode(TMC_EL_DIR_PIN, OUTPUT);
    pinMode(TMC_EL_DIAG_PIN, INPUT);
    
    pinMode(TMC_EN_PIN, OUTPUT);
    digitalWrite(TMC_EN_PIN, HIGH);  // Disabled initially
    
    // Initialize TMC UART
    _tmcSerial = new HardwareSerial(2);
    _tmcSerial->begin(TMC_SERIAL_BAUD, SERIAL_8N1, TMC_UART_RX_PIN, TMC_UART_TX_PIN);
    
    // Create TMC2209 driver instances
    _tmcAz = new TMC2209Stepper(_tmcSerial, TMC_R_SENSE, TMC_AZ_ADDRESS);
    _tmcEl = new TMC2209Stepper(_tmcSerial, TMC_R_SENSE, TMC_EL_ADDRESS);
    
    // Small delay for drivers to power up
    delay(100);
    
    // Initialize both drivers
    initDriver(_tmcAz, TMC_AZ_ADDRESS);
    initDriver(_tmcEl, TMC_EL_ADDRESS);
    
    // Verify communication
    if (!driversConnected()) {
        DEBUG_PRINTLN("StepperControl: ERROR - Driver communication failed!");
        return false;
    }
    
    // Enable drivers
    setEnabled(true);
    
    _lastUpdateMicros = micros();
    
    DEBUG_PRINTLN("StepperControl: Initialization complete");
    return true;
}

void StepperControl::initDriver(TMC2209Stepper* driver, uint8_t address) {
    driver->begin();
    
    // Basic configuration
    driver->toff(4);                    // Enable driver
    driver->blank_time(24);             // Comparator blank time
    driver->rms_current(MOTOR_RUN_CURRENT_MA);
    driver->hold_multiplier(MOTOR_HOLD_MULTIPLIER);
    driver->microsteps(TMC_MICROSTEPS);
    driver->intpol(true);               // Interpolation to 256 microsteps
    
    // StealthChop for quiet operation
    driver->en_spreadCycle(false);
    driver->pwm_autoscale(true);
    driver->pwm_autograd(true);
    
    // StallGuard configuration
    driver->TCOOLTHRS(0xFFFFF);         // Enable StallGuard at all speeds
    driver->semin(5);                   // Minimum current
    driver->semax(2);                   // Maximum current increase
    driver->sedn(0b01);                 // Current down step speed
    driver->SGTHRS(TMC_STALL_THRESHOLD);
    
    DEBUG_PRINTF("StepperControl: Driver 0x%02X configured, version=0x%02X\n", 
                 address, driver->version());
}

void StepperControl::update() {
    if (!_enabled) return;
    
    // Take mutex with short timeout (non-blocking for real-time task)
    if (xSemaphoreTake(_profileMutex, pdMS_TO_TICKS(1)) != pdTRUE) {
        return;  // Skip this cycle if mutex not available
    }
    
    uint32_t now = micros();
    
    // Update both axes
    if (_azProfile.isMoving) {
        updateAxis(_azProfile, TMC_AZ_STEP_PIN, TMC_AZ_DIR_PIN, 
                   _azLastStepMicros, AZ_MIN_DEG, AZ_MAX_DEG);
    }
    
    if (_elProfile.isMoving) {
        updateAxis(_elProfile, TMC_EL_STEP_PIN, TMC_EL_DIR_PIN,
                   _elLastStepMicros, EL_MIN_DEG, EL_MAX_DEG);
    }
    
    _lastUpdateMicros = now;
    
    xSemaphoreGive(_profileMutex);
}

void StepperControl::updateAxis(MotionProfile& profile, uint8_t stepPin, uint8_t dirPin,
                                 uint32_t& lastStepMicros, float minPos, float maxPos) {
    if (!profile.isMoving) return;
    
    uint32_t now = micros();
    
    // Calculate step position difference
    int32_t stepsToGo = profile.targetSteps - profile.currentSteps;
    
    if (stepsToGo == 0) {
        // Reached target
        profile.isMoving = false;
        profile.currentSpeed = 0;
        profile.currentPosition = profile.targetPosition;
        return;
    }
    
    // Set direction
    bool forward = stepsToGo > 0;
    digitalWrite(dirPin, forward ? HIGH : LOW);
    
    // Calculate distance to target (for deceleration)
    float distanceToTarget = abs(stepsToDegrees(stepsToGo));
    
    // Calculate stopping distance at current speed
    float stoppingDistance = (profile.currentSpeed * profile.currentSpeed) / 
                             (2.0f * profile.acceleration);
    
    // Determine target speed (accelerate or decelerate)
    float targetSpeed;
    if (distanceToTarget <= stoppingDistance) {
        // Need to decelerate
        targetSpeed = sqrt(2.0f * profile.acceleration * distanceToTarget);
    } else {
        // Can accelerate or maintain speed
        targetSpeed = profile.maxSpeed;
    }
    
    // Apply acceleration limit
    float dt = (now - lastStepMicros) / 1000000.0f;
    if (dt > 0.01f) dt = 0.01f;  // Cap dt to prevent large jumps
    
    if (profile.currentSpeed < targetSpeed) {
        profile.currentSpeed += profile.acceleration * dt;
        if (profile.currentSpeed > targetSpeed) {
            profile.currentSpeed = targetSpeed;
        }
    } else if (profile.currentSpeed > targetSpeed) {
        profile.currentSpeed -= profile.acceleration * dt;
        if (profile.currentSpeed < targetSpeed) {
            profile.currentSpeed = targetSpeed;
        }
    }
    
    // Minimum speed to prevent stalling
    if (profile.currentSpeed < 0.1f) {
        profile.currentSpeed = 0.1f;
    }
    
    // Calculate step interval using integer math to avoid FP division every cycle
    // stepsPerSecond = currentSpeed * STEPS_PER_DEGREE
    // stepIntervalMicros = 1000000 / stepsPerSecond
    // Optimized: precompute (1000000 / STEPS_PER_DEGREE) = ~10989 for typical config
    // Then: stepIntervalMicros = constant / currentSpeed
    static const uint32_t MICROS_PER_STEP_AT_1DPS = (uint32_t)(1000000.0f / STEPS_PER_DEGREE);
    uint32_t stepIntervalMicros;
    if (profile.currentSpeed > 0.01f) {
        // Use precomputed constant and single division
        stepIntervalMicros = (uint32_t)(MICROS_PER_STEP_AT_1DPS / profile.currentSpeed);
    } else {
        stepIntervalMicros = 100000;  // Very slow fallback
    }
    
    // Minimum step interval (maximum frequency)
    if (stepIntervalMicros < 20) stepIntervalMicros = 20;
    
    // Time to step?
    if (now - lastStepMicros >= stepIntervalMicros) {
        // Generate step pulse
        pulseStep(stepPin);
        
        // Update position
        if (forward) {
            profile.currentSteps++;
        } else {
            profile.currentSteps--;
        }
        profile.currentPosition = stepsToDegrees(profile.currentSteps);
        
        lastStepMicros = now;
    }
}

void StepperControl::pulseStep(uint8_t stepPin) {
    digitalWrite(stepPin, HIGH);
    delayMicroseconds(2);
    digitalWrite(stepPin, LOW);
}

void StepperControl::moveAzimuthTo(float degrees, float speed) {
    if (!_enabled) return;
    
    // Take mutex for thread-safe profile modification
    if (xSemaphoreTake(_profileMutex, pdMS_TO_TICKS(100)) != pdTRUE) {
        return;
    }
    
    // Apply offset
    float targetWithOffset = degrees + _azOffset;
    
    // Normalize and find shortest path
    float current = _azProfile.currentPosition;
    float target = shortestPath(current, targetWithOffset);
    
    // Clamp to limits
    if (target < AZ_MIN_DEG) target = AZ_MIN_DEG;
    if (target > AZ_MAX_DEG) target = AZ_MAX_DEG;
    
    _azProfile.targetPosition = target;
    _azProfile.targetSteps = degreesToSteps(target);
    _azProfile.maxSpeed = (speed > 0) ? speed : TRACKING_SPEED_DEG_S;
    _azProfile.isMoving = true;
    
    _azState = MotorState::MOVING;
    
    xSemaphoreGive(_profileMutex);
    
    DEBUG_PRINTF("StepperControl: Az move to %.2f° (speed %.1f°/s)\n", target, _azProfile.maxSpeed);
}

void StepperControl::moveElevationTo(float degrees, float speed) {
    if (!_enabled) return;
    
    // Take mutex for thread-safe profile modification
    if (xSemaphoreTake(_profileMutex, pdMS_TO_TICKS(100)) != pdTRUE) {
        return;
    }
    
    // Apply offset
    float target = degrees + _elOffset;
    
    // Clamp to limits
    if (target < EL_MIN_DEG) target = EL_MIN_DEG;
    if (target > EL_MAX_DEG) target = EL_MAX_DEG;
    
    _elProfile.targetPosition = target;
    _elProfile.targetSteps = degreesToSteps(target);
    _elProfile.maxSpeed = (speed > 0) ? speed : TRACKING_SPEED_DEG_S;
    _elProfile.isMoving = true;
    
    _elState = MotorState::MOVING;
    
    xSemaphoreGive(_profileMutex);
    
    DEBUG_PRINTF("StepperControl: El move to %.2f° (speed %.1f°/s)\n", target, _elProfile.maxSpeed);
}

void StepperControl::moveTo(float azDegrees, float elDegrees, float speed) {
    moveAzimuthTo(azDegrees, speed);
    moveElevationTo(elDegrees, speed);
}

void StepperControl::stop() {
    // Take mutex for thread-safe profile modification
    if (xSemaphoreTake(_profileMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        _azProfile.isMoving = false;
        _azProfile.currentSpeed = 0;
        _azProfile.targetPosition = _azProfile.currentPosition;
        _azProfile.targetSteps = _azProfile.currentSteps;
        
        _elProfile.isMoving = false;
        _elProfile.currentSpeed = 0;
        _elProfile.targetPosition = _elProfile.currentPosition;
        _elProfile.targetSteps = _elProfile.currentSteps;
        
        _azState = MotorState::IDLE;
        _elState = MotorState::IDLE;
        
        xSemaphoreGive(_profileMutex);
    }
    
    DEBUG_PRINTLN("StepperControl: Motion stopped");
}

void StepperControl::emergencyStop() {
    stop();
    setEnabled(false);
    DEBUG_PRINTLN("StepperControl: EMERGENCY STOP");
}

void StepperControl::setEnabled(bool enabled) {
    _enabled = enabled;
    digitalWrite(TMC_EN_PIN, enabled ? LOW : HIGH);  // Active LOW
    
    if (!enabled) {
        _azProfile.isMoving = false;
        _elProfile.isMoving = false;
        _azState = MotorState::IDLE;
        _elState = MotorState::IDLE;
    }
    
    DEBUG_PRINTF("StepperControl: Motors %s\n", enabled ? "ENABLED" : "DISABLED");
}

bool StepperControl::home() {
    DEBUG_PRINTLN("StepperControl: Starting homing sequence...");
    
    // Home elevation first (down to 0°)
    if (!homeAxis(Axis::ELEVATION)) {
        DEBUG_PRINTLN("StepperControl: Elevation homing failed");
        return false;
    }
    
    // Then home azimuth
    if (!homeAxis(Axis::AZIMUTH)) {
        DEBUG_PRINTLN("StepperControl: Azimuth homing failed");
        return false;
    }
    
    DEBUG_PRINTLN("StepperControl: Homing complete");
    return true;
}

bool StepperControl::homeAxis(Axis axis) {
    TMC2209Stepper* driver = (axis == Axis::AZIMUTH) ? _tmcAz : _tmcEl;
    uint8_t stepPin = (axis == Axis::AZIMUTH) ? TMC_AZ_STEP_PIN : TMC_EL_STEP_PIN;
    uint8_t dirPin = (axis == Axis::AZIMUTH) ? TMC_AZ_DIR_PIN : TMC_EL_DIR_PIN;
    uint8_t diagPin = (axis == Axis::AZIMUTH) ? TMC_AZ_DIAG_PIN : TMC_EL_DIAG_PIN;
    MotionProfile& profile = (axis == Axis::AZIMUTH) ? _azProfile : _elProfile;
    MotorState& state = (axis == Axis::AZIMUTH) ? _azState : _elState;
    
    const char* axisName = (axis == Axis::AZIMUTH) ? "Azimuth" : "Elevation";
    
    DEBUG_PRINTF("StepperControl: Homing %s...\n", axisName);
    
    state = MotorState::HOMING;
    
    // Configure for StallGuard detection
    driver->TCOOLTHRS(0xFFFFF);
    driver->SGTHRS(TMC_STALL_THRESHOLD);
    
    // Direction: elevation down (false), azimuth CCW (true)
    bool direction = (axis == Axis::ELEVATION) ? false : true;
    digitalWrite(dirPin, direction ? HIGH : LOW);
    
    // Move until stall detected
    uint32_t stepInterval = (uint32_t)(1000000.0f / (HOMING_SPEED_DEG_S * STEPS_PER_DEGREE));
    uint32_t timeout = millis() + 30000;  // 30 second timeout
    uint32_t lastStep = micros();
    
    while (millis() < timeout) {
        // Check for stall
        if (digitalRead(diagPin) == HIGH || driver->diag()) {
            DEBUG_PRINTF("StepperControl: %s stall detected!\n", axisName);
            delay(100);
            
            // Back off slightly
            digitalWrite(dirPin, !direction ? HIGH : LOW);
            for (int i = 0; i < 100; i++) {
                pulseStep(stepPin);
                delayMicroseconds(stepInterval);
            }
            
            // Set position to zero
            profile.currentSteps = 0;
            profile.currentPosition = 0;
            profile.targetSteps = 0;
            profile.targetPosition = 0;
            profile.isMoving = false;
            profile.currentSpeed = 0;
            
            state = MotorState::IDLE;
            
            DEBUG_PRINTF("StepperControl: %s homed to 0°\n", axisName);
            return true;
        }
        
        // Step if interval elapsed
        if (micros() - lastStep >= stepInterval) {
            pulseStep(stepPin);
            lastStep = micros();
        }
        
        yield();  // Allow other tasks
    }
    
    DEBUG_PRINTF("StepperControl: %s homing timeout!\n", axisName);
    state = MotorState::ERROR;
    return false;
}

void StepperControl::setHome() {
    _azProfile.currentSteps = 0;
    _azProfile.currentPosition = 0;
    _azProfile.targetSteps = 0;
    _azProfile.targetPosition = 0;
    
    _elProfile.currentSteps = 0;
    _elProfile.currentPosition = 0;
    _elProfile.targetSteps = 0;
    _elProfile.targetPosition = 0;
    
    DEBUG_PRINTLN("StepperControl: Current position set as home (0,0)");
}

void StepperControl::park() {
    DEBUG_PRINTLN("StepperControl: Moving to park position");
    moveTo(PARK_AZ_DEG, PARK_EL_DEG, MAX_SLEW_SPEED_DEG_S);
}

float StepperControl::getAzimuth() const {
    return _azProfile.currentPosition - _azOffset;
}

float StepperControl::getElevation() const {
    return _elProfile.currentPosition - _elOffset;
}

bool StepperControl::isMoving() const {
    return _azProfile.isMoving || _elProfile.isMoving;
}

MotorState StepperControl::getState(Axis axis) const {
    return (axis == Axis::AZIMUTH) ? _azState : _elState;
}

void StepperControl::setCalibrationOffset(float azOffset, float elOffset) {
    _azOffset = azOffset;
    _elOffset = elOffset;
    DEBUG_PRINTF("StepperControl: Calibration offsets set: Az=%.2f°, El=%.2f°\n", 
                 azOffset, elOffset);
}

void StepperControl::setPosition(float azDegrees, float elDegrees) {
    _azProfile.currentPosition = azDegrees + _azOffset;
    _azProfile.currentSteps = degreesToSteps(_azProfile.currentPosition);
    _azProfile.targetPosition = _azProfile.currentPosition;
    _azProfile.targetSteps = _azProfile.currentSteps;
    
    _elProfile.currentPosition = elDegrees + _elOffset;
    _elProfile.currentSteps = degreesToSteps(_elProfile.currentPosition);
    _elProfile.targetPosition = _elProfile.currentPosition;
    _elProfile.targetSteps = _elProfile.currentSteps;
    
    DEBUG_PRINTF("StepperControl: Position set to Az=%.2f°, El=%.2f°\n", 
                 azDegrees, elDegrees);
}

void StepperControl::setMotorCurrent(uint16_t runCurrent_mA, uint16_t holdCurrent_mA) {
    _tmcAz->rms_current(runCurrent_mA);
    _tmcEl->rms_current(runCurrent_mA);
    
    float holdMult = (float)holdCurrent_mA / (float)runCurrent_mA;
    _tmcAz->hold_multiplier(holdMult);
    _tmcEl->hold_multiplier(holdMult);
    
    DEBUG_PRINTF("StepperControl: Motor current set: run=%dmA, hold=%dmA\n",
                 runCurrent_mA, holdCurrent_mA);
}

uint32_t StepperControl::getDriverStatus(Axis axis) {
    TMC2209Stepper* driver = (axis == Axis::AZIMUTH) ? _tmcAz : _tmcEl;
    return driver->DRV_STATUS();
}

bool StepperControl::driversConnected() {
    bool azOk = (_tmcAz->test_connection() == 0);
    bool elOk = (_tmcEl->test_connection() == 0);
    
    DEBUG_PRINTF("StepperControl: Driver connection test - Az:%s, El:%s\n",
                 azOk ? "OK" : "FAIL", elOk ? "OK" : "FAIL");
    
    return azOk && elOk;
}

float StepperControl::stepsToDegrees(int32_t steps) {
    return (float)steps / STEPS_PER_DEGREE;
}

int32_t StepperControl::degreesToSteps(float degrees) {
    return (int32_t)(degrees * STEPS_PER_DEGREE);
}

bool StepperControl::detectStall(Axis axis) {
    uint8_t diagPin = (axis == Axis::AZIMUTH) ? TMC_AZ_DIAG_PIN : TMC_EL_DIAG_PIN;
    TMC2209Stepper* driver = (axis == Axis::AZIMUTH) ? _tmcAz : _tmcEl;
    
    return digitalRead(diagPin) == HIGH || driver->diag();
}

float StepperControl::normalizeAzimuth(float degrees) {
    while (degrees < 0) degrees += 360.0f;
    while (degrees >= 360.0f) degrees -= 360.0f;
    return degrees;
}

float StepperControl::shortestPath(float current, float target) {
    // Calculate the shortest path considering wrap-around
    float normalized_target = normalizeAzimuth(target);
    float normalized_current = normalizeAzimuth(current);
    
    float diff = normalized_target - normalized_current;
    
    // Find shortest path
    if (diff > 180.0f) {
        return current + (diff - 360.0f);
    } else if (diff < -180.0f) {
        return current + (diff + 360.0f);
    } else {
        return current + diff;
    }
}
