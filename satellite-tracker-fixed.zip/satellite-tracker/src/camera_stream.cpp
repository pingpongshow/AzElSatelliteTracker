/**
 * @file camera_stream.cpp
 * @brief MJPEG streaming server implementation
 */

#include "camera_stream.h"
#include "stepper_control.h"
#include "tracking_engine.h"

// Global instance
CameraStream cameraStream;

// MJPEG stream boundary
#define PART_BOUNDARY "123456789000000000000987654321"
static const char* STREAM_CONTENT_TYPE = "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;
static const char* STREAM_BOUNDARY = "\r\n--" PART_BOUNDARY "\r\n";
static const char* STREAM_PART = "Content-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n";

CameraStream::CameraStream()
    : _server(nullptr)
    , _running(false)
    , _port(CAMERA_STREAM_PORT)
    , _overlayEnabled(true)
    , _clientCount(0)
{
    // Default overlay settings
    _overlay.showCrosshairs = true;
    _overlay.showBlobMarker = false;
    _overlay.showPositionText = true;
    _overlay.showGrid = false;
    _overlay.crosshairColor[0] = 0;    // Green
    _overlay.crosshairColor[1] = 255;
    _overlay.crosshairColor[2] = 0;
    _overlay.blobColor[0] = 255;       // Red
    _overlay.blobColor[1] = 0;
    _overlay.blobColor[2] = 0;
}

bool CameraStream::begin(uint16_t port) {
    if (_running) {
        stop();
    }
    
    _port = port;
    
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = _port;
    config.ctrl_port = _port;
    config.max_open_sockets = 4;
    config.stack_size = 8192;
    
    if (httpd_start(&_server, &config) != ESP_OK) {
        DEBUG_PRINTLN("CameraStream: Failed to start server");
        return false;
    }
    
    // Register stream handler
    httpd_uri_t stream_uri = {
        .uri = "/stream",
        .method = HTTP_GET,
        .handler = streamHandler,
        .user_ctx = this
    };
    httpd_register_uri_handler(_server, &stream_uri);
    
    // Register snapshot handler
    httpd_uri_t snapshot_uri = {
        .uri = "/snapshot",
        .method = HTTP_GET,
        .handler = snapshotHandler,
        .user_ctx = this
    };
    httpd_register_uri_handler(_server, &snapshot_uri);
    
    // Register index page
    httpd_uri_t index_uri = {
        .uri = "/",
        .method = HTTP_GET,
        .handler = indexHandler,
        .user_ctx = this
    };
    httpd_register_uri_handler(_server, &index_uri);
    
    _running = true;
    DEBUG_PRINTF("CameraStream: Started on port %d\n", _port);
    
    return true;
}

void CameraStream::stop() {
    if (_server) {
        httpd_stop(_server);
        _server = nullptr;
    }
    _running = false;
    DEBUG_PRINTLN("CameraStream: Stopped");
}

String CameraStream::getStreamUrl() const {
    return "http://" + WiFi.localIP().toString() + ":" + String(_port) + "/stream";
}

esp_err_t CameraStream::streamHandler(httpd_req_t* req) {
    CameraStream* self = (CameraStream*)req->user_ctx;
    esp_err_t res = ESP_OK;
    char partBuf[64];
    
    self->_clientCount++;
    
    res = httpd_resp_set_type(req, STREAM_CONTENT_TYPE);
    if (res != ESP_OK) {
        self->_clientCount--;
        return res;
    }
    
    // Disable buffering
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
    httpd_resp_set_hdr(req, "Cache-Control", "no-cache, no-store, must-revalidate");
    
    while (true) {
        camera_fb_t* fb = cameraAlign.getStreamFrame();
        if (!fb) {
            DEBUG_PRINTLN("CameraStream: Frame capture failed");
            delay(100);
            continue;
        }
        
        // Send boundary
        res = httpd_resp_send_chunk(req, STREAM_BOUNDARY, strlen(STREAM_BOUNDARY));
        if (res != ESP_OK) {
            cameraAlign.releaseFrame(fb);
            break;
        }
        
        // Send header
        size_t hlen = snprintf(partBuf, sizeof(partBuf), STREAM_PART, fb->len);
        res = httpd_resp_send_chunk(req, partBuf, hlen);
        if (res != ESP_OK) {
            cameraAlign.releaseFrame(fb);
            break;
        }
        
        // Send frame
        res = httpd_resp_send_chunk(req, (const char*)fb->buf, fb->len);
        cameraAlign.releaseFrame(fb);
        
        if (res != ESP_OK) {
            break;
        }
        
        // Rate limit
        delay(1000 / CAMERA_STREAM_FPS);
    }
    
    self->_clientCount--;
    return res;
}

esp_err_t CameraStream::snapshotHandler(httpd_req_t* req) {
    camera_fb_t* fb = cameraAlign.getStreamFrame();
    if (!fb) {
        httpd_resp_send_500(req);
        return ESP_FAIL;
    }
    
    httpd_resp_set_type(req, "image/jpeg");
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
    httpd_resp_set_hdr(req, "Content-Disposition", "inline; filename=snapshot.jpg");
    
    esp_err_t res = httpd_resp_send(req, (const char*)fb->buf, fb->len);
    cameraAlign.releaseFrame(fb);
    
    return res;
}

esp_err_t CameraStream::indexHandler(httpd_req_t* req) {
    CameraStream* self = (CameraStream*)req->user_ctx;
    
    // Current position
    float az = stepperControl.getAzimuth();
    float el = stepperControl.getElevation();
    
    // Simple HTML page with embedded stream
    String html = "<!DOCTYPE html><html><head>";
    html += "<title>Satellite Tracker Camera</title>";
    html += "<style>body{font-family:Arial;background:#1a1a2e;color:#fff;text-align:center;margin:20px;}";
    html += ".container{max-width:800px;margin:0 auto;}";
    html += "img{max-width:100%;border:2px solid #4a4a6a;border-radius:8px;}";
    html += ".info{background:#2a2a4e;padding:15px;border-radius:8px;margin:15px 0;}";
    html += ".overlay{position:relative;display:inline-block;}";
    html += ".crosshair{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);";
    html += "width:40px;height:40px;border:2px solid #0f0;border-radius:50%;pointer-events:none;}";
    html += ".crosshair::before,.crosshair::after{content:'';position:absolute;background:#0f0;}";
    html += ".crosshair::before{width:2px;height:100%;left:50%;transform:translateX(-50%);}";
    html += ".crosshair::after{width:100%;height:2px;top:50%;transform:translateY(-50%);}";
    html += "</style></head><body>";
    html += "<div class='container'>";
    html += "<h1>📡 Satellite Tracker Camera</h1>";
    html += "<div class='overlay'>";
    html += "<img src='/stream' alt='Camera Stream'>";
    html += "<div class='crosshair'></div>";
    html += "</div>";
    html += "<div class='info'>";
    html += "<strong>Current Position:</strong> Az: " + String(az, 1) + "° El: " + String(el, 1) + "°";
    
    if (trackingEngine.hasTLE()) {
        html += "<br><strong>Tracking:</strong> " + trackingEngine.getSatelliteName();
        if (trackingEngine.isSatelliteVisible()) {
            SatellitePosition pos = trackingEngine.getPosition();
            html += " (Az: " + String(pos.azimuth, 1) + "° El: " + String(pos.elevation, 1) + "°)";
        }
    }
    
    html += "</div>";
    html += "<p><a href='/snapshot' style='color:#4CAF50;'>📷 Snapshot</a></p>";
    html += "</div></body></html>";
    
    httpd_resp_set_type(req, "text/html");
    return httpd_resp_send(req, html.c_str(), html.length());
}
