/**
 * @file camera_align.cpp
 * @brief Camera-based alignment implementation
 */

#include "camera_align.h"
#include "tracking_engine.h"
#include "stepper_control.h"
#include "gps.h"

// Global instance
CameraAlign cameraAlign;

CameraAlign::CameraAlign()
    : _initialized(false)
    , _lastFrame(nullptr)
    , _sunThreshold(SUN_BRIGHTNESS_THRESHOLD)
    , _moonThreshold(MOON_BRIGHTNESS_THRESHOLD)
    , _minBlobSize(MIN_BLOB_PIXELS)
    , _fovH(CAMERA_FOV_H)
    , _fovV(CAMERA_FOV_V)
    , _frameWidth(640)
    , _frameHeight(480)
{
}

bool CameraAlign::begin() {
    DEBUG_PRINTLN("CameraAlign: Initializing...");
    
    if (!initCamera()) {
        DEBUG_PRINTLN("CameraAlign: Camera initialization failed");
        return false;
    }
    
    _initialized = true;
    DEBUG_PRINTLN("CameraAlign: Initialization complete");
    return true;
}

bool CameraAlign::initCamera() {
    camera_config_t config;
    
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = CAM_PIN_D0;
    config.pin_d1 = CAM_PIN_D1;
    config.pin_d2 = CAM_PIN_D2;
    config.pin_d3 = CAM_PIN_D3;
    config.pin_d4 = CAM_PIN_D4;
    config.pin_d5 = CAM_PIN_D5;
    config.pin_d6 = CAM_PIN_D6;
    config.pin_d7 = CAM_PIN_D7;
    config.pin_xclk = CAM_PIN_XCLK;
    config.pin_pclk = CAM_PIN_PCLK;
    config.pin_vsync = CAM_PIN_VSYNC;
    config.pin_href = CAM_PIN_HREF;
    config.pin_sccb_sda = CAM_PIN_SIOD;
    config.pin_sccb_scl = CAM_PIN_SIOC;
    config.pin_pwdn = CAM_PIN_PWDN;
    config.pin_reset = CAM_PIN_RESET;
    config.xclk_freq_hz = 20000000;
    config.frame_size = CAMERA_FRAME_SIZE;
    config.pixel_format = PIXFORMAT_JPEG;
    config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
    config.fb_location = CAMERA_FB_IN_PSRAM;
    config.jpeg_quality = CAMERA_JPEG_QUALITY;
    config.fb_count = CAMERA_FB_COUNT;
    
    // Initialize camera
    esp_err_t err = esp_camera_init(&config);
    if (err != ESP_OK) {
        DEBUG_PRINTF("CameraAlign: Camera init failed with error 0x%x\n", err);
        return false;
    }
    
    // Get sensor and configure
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_brightness(s, 0);
        s->set_contrast(s, 0);
        s->set_saturation(s, 0);
        s->set_whitebal(s, 1);
        s->set_awb_gain(s, 1);
        s->set_wb_mode(s, 0);
        s->set_exposure_ctrl(s, 1);
        s->set_aec2(s, 1);
        s->set_gain_ctrl(s, 1);
        s->set_agc_gain(s, 0);
        s->set_gainceiling(s, (gainceiling_t)6);
        s->set_bpc(s, 1);
        s->set_wpc(s, 1);
        s->set_raw_gma(s, 1);
        s->set_lenc(s, 1);
        s->set_hmirror(s, 0);
        s->set_vflip(s, 0);
        s->set_dcw(s, 1);
    }
    
    // Update frame dimensions based on actual frame size
    _frameWidth = 640;
    _frameHeight = 480;
    
    return true;
}

AlignmentResult CameraAlign::alignToSun() {
    if (!_initialized) {
        AlignmentResult result;
        result.success = false;
        result.errorMessage = "Camera not initialized";
        return result;
    }
    
    // Get calculated sun position
    float sunAz, sunEl;
    if (!trackingEngine.getSunPosition(sunAz, sunEl)) {
        AlignmentResult result;
        result.success = false;
        result.errorMessage = "Sun below horizon";
        return result;
    }
    
    DEBUG_PRINTF("CameraAlign: Sun position: Az=%.2f, El=%.2f\n", sunAz, sunEl);
    
    // Switch to grayscale for proper image processing
    switchToGrayscale();
    
    // Configure camera for bright sun (low exposure)
    setExposure(10);
    setGain(0);
    delay(500);  // Let camera adjust
    
    AlignmentResult result = performAlignment(sunAz, sunEl, _sunThreshold, "Sun");
    
    // Switch back to JPEG for streaming
    switchToJPEG();
    
    return result;
}

AlignmentResult CameraAlign::alignToMoon() {
    if (!_initialized) {
        AlignmentResult result;
        result.success = false;
        result.errorMessage = "Camera not initialized";
        return result;
    }
    
    // Get calculated moon position
    float moonAz, moonEl;
    if (!trackingEngine.getMoonPosition(moonAz, moonEl)) {
        AlignmentResult result;
        result.success = false;
        result.errorMessage = "Moon below horizon";
        return result;
    }
    
    DEBUG_PRINTF("CameraAlign: Moon position: Az=%.2f, El=%.2f\n", moonAz, moonEl);
    
    // Switch to grayscale for proper image processing
    switchToGrayscale();
    
    // Configure camera for moon (moderate exposure)
    resetAutoExposure();
    delay(1000);  // Let camera auto-adjust
    
    AlignmentResult result = performAlignment(moonAz, moonEl, _moonThreshold, "Moon");
    
    // Switch back to JPEG for streaming
    switchToJPEG();
    
    return result;
}

AlignmentResult CameraAlign::performAlignment(float targetAz, float targetEl,
                                               uint8_t threshold, const char* bodyName) {
    AlignmentResult result;
    result.success = false;
    
    // Move antenna to calculated position
    DEBUG_PRINTF("CameraAlign: Moving to %s position\n", bodyName);
    stepperControl.moveTo(targetAz, targetEl, MAX_SLEW_SPEED_DEG_S);
    
    // Wait for movement to complete
    uint32_t timeout = millis() + 30000;
    while (stepperControl.isMoving() && millis() < timeout) {
        stepperControl.update();
        delay(10);
    }
    
    if (stepperControl.isMoving()) {
        result.errorMessage = "Movement timeout";
        return result;
    }
    
    // Allow camera to stabilize
    delay(500);
    
    // Capture frame (should be in grayscale mode now)
    camera_fb_t* fb = esp_camera_fb_get();
    if (!fb) {
        result.errorMessage = "Frame capture failed";
        return result;
    }
    
    DEBUG_PRINTF("CameraAlign: Captured frame %dx%d, format=%d, %d bytes\n",
                 fb->width, fb->height, fb->format, fb->len);
    
    // Process grayscale image directly
    uint8_t* grayscale;
    bool needsFree = false;
    
    if (fb->format == PIXFORMAT_GRAYSCALE) {
        // Direct grayscale - use buffer directly
        grayscale = fb->buf;
        _frameWidth = fb->width;
        _frameHeight = fb->height;
    } else if (fb->format == PIXFORMAT_RGB565) {
        // RGB565 - convert to grayscale
        size_t graySize = fb->width * fb->height;
        grayscale = (uint8_t*)ps_malloc(graySize);
        if (!grayscale) {
            esp_camera_fb_return(fb);
            result.errorMessage = "Memory allocation failed";
            return result;
        }
        needsFree = true;
        convertToGrayscale(fb, grayscale);
        _frameWidth = fb->width;
        _frameHeight = fb->height;
    } else {
        // JPEG or other format - need conversion
        size_t graySize = fb->width * fb->height;
        grayscale = (uint8_t*)ps_malloc(graySize);
        if (!grayscale) {
            esp_camera_fb_return(fb);
            result.errorMessage = "Memory allocation failed";
            return result;
        }
        needsFree = true;
        convertToGrayscale(fb, grayscale);
        _frameWidth = fb->width;
        _frameHeight = fb->height;
    }
    
    // Detect bright blob
    BlobDetection blob = detectBrightBlob(grayscale, _frameWidth, _frameHeight, threshold);
    
    if (needsFree) {
        free(grayscale);
    }
    
    if (!blob.found) {
        esp_camera_fb_return(fb);
        result.errorMessage = String(bodyName) + " not detected in frame";
        return result;
    }
    
    DEBUG_PRINTF("CameraAlign: Blob detected at (%d, %d), size=%d, brightness=%d\n",
                 blob.centerX, blob.centerY, blob.pixelCount, blob.brightness);
    
    // Calculate pixel offset from frame center
    int centerX = _frameWidth / 2;
    int centerY = _frameHeight / 2;
    int offsetX = blob.centerX - centerX;
    int offsetY = blob.centerY - centerY;
    
    esp_camera_fb_return(fb);
    
    // Convert pixel offset to angular offset
    float azError = pixelToAngleH(offsetX);
    float elError = pixelToAngleV(offsetY);
    
    // Current position error means we need to apply opposite offset
    result.azOffset = -azError;
    result.elOffset = elError;  // Note: Y increases downward in image
    
    result.success = true;
    result.blobX = blob.centerX;
    result.blobY = blob.centerY;
    result.blobSize = blob.pixelCount;
    result.confidence = min(1.0f, (float)blob.pixelCount / 500.0f);
    
    // Apply calibration offset
    float currentAzOffset = stepperControl.getAzimuthOffset();
    float currentElOffset = stepperControl.getElevationOffset();
    
    stepperControl.setCalibrationOffset(
        currentAzOffset + result.azOffset,
        currentElOffset + result.elOffset
    );
    
    DEBUG_PRINTF("CameraAlign: Alignment complete. Offsets: Az=%.3f, El=%.3f\n",
                 result.azOffset, result.elOffset);
    
    return result;
}

BlobDetection CameraAlign::detectBrightBlob(uint8_t* grayscale, int width, int height,
                                             uint8_t threshold) {
    BlobDetection result;
    result.found = false;
    result.centerX = 0;
    result.centerY = 0;
    result.pixelCount = 0;
    result.brightness = 0;
    
    // Simple centroid calculation for bright pixels
    long sumX = 0;
    long sumY = 0;
    long sumBrightness = 0;
    int count = 0;
    
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            uint8_t pixel = grayscale[y * width + x];
            if (pixel >= threshold) {
                sumX += x * pixel;
                sumY += y * pixel;
                sumBrightness += pixel;
                count++;
            }
        }
    }
    
    if (count >= _minBlobSize && sumBrightness > 0) {
        result.found = true;
        result.centerX = sumX / sumBrightness;
        result.centerY = sumY / sumBrightness;
        result.pixelCount = count;
        result.brightness = sumBrightness / count;
    }
    
    return result;
}

void CameraAlign::convertToGrayscale(camera_fb_t* fb, uint8_t* output) {
    // For JPEG format, this is a simplified approximation
    // In production, use PIXFORMAT_GRAYSCALE for direct grayscale capture
    
    if (fb->format == PIXFORMAT_JPEG) {
        // Estimate brightness from JPEG data (very rough)
        // This is a hack - proper implementation would decode JPEG
        size_t graySize = fb->width * fb->height;
        memset(output, 128, graySize);  // Default mid-gray
        
        // Sample JPEG data for brightness hints
        for (size_t i = 0; i < fb->len && i < graySize; i++) {
            output[i % graySize] = fb->buf[i];
        }
    } else if (fb->format == PIXFORMAT_GRAYSCALE) {
        memcpy(output, fb->buf, fb->width * fb->height);
    } else if (fb->format == PIXFORMAT_RGB565) {
        // Convert RGB565 to grayscale
        uint16_t* rgb = (uint16_t*)fb->buf;
        for (int i = 0; i < fb->width * fb->height; i++) {
            uint16_t pixel = rgb[i];
            uint8_t r = (pixel >> 11) & 0x1F;
            uint8_t g = (pixel >> 5) & 0x3F;
            uint8_t b = pixel & 0x1F;
            // Convert to 8-bit and calculate luminance
            r = (r * 255) / 31;
            g = (g * 255) / 63;
            b = (b * 255) / 31;
            output[i] = (r * 77 + g * 150 + b * 29) >> 8;
        }
    }
}

float CameraAlign::pixelToAngleH(int pixelOffset) {
    // Convert horizontal pixel offset to degrees
    // Positive offset = object is right of center = antenna pointing left of target
    return (float)pixelOffset * _fovH / (float)_frameWidth;
}

float CameraAlign::pixelToAngleV(int pixelOffset) {
    // Convert vertical pixel offset to degrees
    // Positive offset = object is below center = antenna pointing above target
    return (float)pixelOffset * _fovV / (float)_frameHeight;
}

size_t CameraAlign::captureFrame(uint8_t* buffer, size_t maxLen) {
    if (!_initialized) return 0;
    
    camera_fb_t* fb = esp_camera_fb_get();
    if (!fb) return 0;
    
    size_t len = min(fb->len, maxLen);
    memcpy(buffer, fb->buf, len);
    
    esp_camera_fb_return(fb);
    return len;
}

const uint8_t* CameraAlign::getLastFrame(size_t& len) {
    if (!_initialized) {
        len = 0;
        return nullptr;
    }
    
    if (_lastFrame) {
        esp_camera_fb_return(_lastFrame);
    }
    
    _lastFrame = esp_camera_fb_get();
    if (!_lastFrame) {
        len = 0;
        return nullptr;
    }
    
    len = _lastFrame->len;
    return _lastFrame->buf;
}

void CameraAlign::setExposure(int exposure) {
    if (!_initialized) return;
    
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_exposure_ctrl(s, 0);  // Disable auto exposure
        s->set_aec_value(s, exposure);
    }
}

void CameraAlign::setGain(int gain) {
    if (!_initialized) return;
    
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_gain_ctrl(s, 0);  // Disable auto gain
        s->set_agc_gain(s, gain);
    }
}

void CameraAlign::resetAutoExposure() {
    if (!_initialized) return;
    
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_exposure_ctrl(s, 1);  // Enable auto exposure
        s->set_gain_ctrl(s, 1);      // Enable auto gain
        s->set_aec2(s, 1);           // Enable AEC DSP
    }
}

// =========================================================================
// Streaming and Overlay Methods
// =========================================================================

camera_fb_t* CameraAlign::getStreamFrame() {
    if (!_initialized) return nullptr;
    return esp_camera_fb_get();
}

void CameraAlign::releaseFrame(camera_fb_t* fb) {
    if (fb) {
        esp_camera_fb_return(fb);
    }
}

void CameraAlign::switchToGrayscale() {
    if (!_initialized) return;
    
    esp_camera_deinit();
    
    camera_config_t config;
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = CAM_PIN_D0;
    config.pin_d1 = CAM_PIN_D1;
    config.pin_d2 = CAM_PIN_D2;
    config.pin_d3 = CAM_PIN_D3;
    config.pin_d4 = CAM_PIN_D4;
    config.pin_d5 = CAM_PIN_D5;
    config.pin_d6 = CAM_PIN_D6;
    config.pin_d7 = CAM_PIN_D7;
    config.pin_xclk = CAM_PIN_XCLK;
    config.pin_pclk = CAM_PIN_PCLK;
    config.pin_vsync = CAM_PIN_VSYNC;
    config.pin_href = CAM_PIN_HREF;
    config.pin_sccb_sda = CAM_PIN_SIOD;
    config.pin_sccb_scl = CAM_PIN_SIOC;
    config.pin_pwdn = CAM_PIN_PWDN;
    config.pin_reset = CAM_PIN_RESET;
    config.xclk_freq_hz = 20000000;
    config.pixel_format = PIXFORMAT_GRAYSCALE;
    config.frame_size = FRAMESIZE_VGA;
    config.jpeg_quality = 12;
    config.fb_count = 1;
    config.fb_location = CAMERA_FB_IN_PSRAM;
    config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
    
    esp_err_t err = esp_camera_init(&config);
    if (err == ESP_OK) {
        _currentFormat = PIXFORMAT_GRAYSCALE;
        _frameWidth = 640;
        _frameHeight = 480;
    }
}

void CameraAlign::switchToJPEG() {
    if (!_initialized) return;
    
    esp_camera_deinit();
    
    camera_config_t config;
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = CAM_PIN_D0;
    config.pin_d1 = CAM_PIN_D1;
    config.pin_d2 = CAM_PIN_D2;
    config.pin_d3 = CAM_PIN_D3;
    config.pin_d4 = CAM_PIN_D4;
    config.pin_d5 = CAM_PIN_D5;
    config.pin_d6 = CAM_PIN_D6;
    config.pin_d7 = CAM_PIN_D7;
    config.pin_xclk = CAM_PIN_XCLK;
    config.pin_pclk = CAM_PIN_PCLK;
    config.pin_vsync = CAM_PIN_VSYNC;
    config.pin_href = CAM_PIN_HREF;
    config.pin_sccb_sda = CAM_PIN_SIOD;
    config.pin_sccb_scl = CAM_PIN_SIOC;
    config.pin_pwdn = CAM_PIN_PWDN;
    config.pin_reset = CAM_PIN_RESET;
    config.xclk_freq_hz = 20000000;
    config.pixel_format = PIXFORMAT_JPEG;
    config.frame_size = FRAMESIZE_VGA;
    config.jpeg_quality = 12;
    config.fb_count = 2;
    config.fb_location = CAMERA_FB_IN_PSRAM;
    config.grab_mode = CAMERA_GRAB_LATEST;
    
    esp_err_t err = esp_camera_init(&config);
    if (err == ESP_OK) {
        _currentFormat = PIXFORMAT_JPEG;
        _frameWidth = 640;
        _frameHeight = 480;
    }
}

void CameraAlign::setFrameSize(framesize_t size) {
    if (!_initialized) return;
    
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_framesize(s, size);
        
        // Update dimensions
        switch (size) {
            case FRAMESIZE_QVGA:
                _frameWidth = 320; _frameHeight = 240;
                break;
            case FRAMESIZE_VGA:
                _frameWidth = 640; _frameHeight = 480;
                break;
            case FRAMESIZE_SVGA:
                _frameWidth = 800; _frameHeight = 600;
                break;
            case FRAMESIZE_XGA:
                _frameWidth = 1024; _frameHeight = 768;
                break;
            default:
                break;
        }
    }
}

void CameraAlign::setQuality(int quality) {
    if (!_initialized) return;
    
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_quality(s, quality);
    }
}

BlobDetection CameraAlign::detectBlob(uint8_t threshold) {
    _lastBlob.found = false;
    
    if (!_initialized) return _lastBlob;
    
    // Capture frame in grayscale temporarily
    camera_fb_t* fb = esp_camera_fb_get();
    if (!fb) return _lastBlob;
    
    // Reuse grayscale buffer to avoid malloc/free on every frame
    size_t graySize = fb->width * fb->height;
    static uint8_t* grayscaleBuffer = nullptr;
    static size_t grayscaleBufferSize = 0;
    
    // Allocate or reallocate if size changed
    if (grayscaleBuffer == nullptr || grayscaleBufferSize != graySize) {
        if (grayscaleBuffer) {
            free(grayscaleBuffer);
        }
        grayscaleBuffer = (uint8_t*)ps_malloc(graySize);
        grayscaleBufferSize = grayscaleBuffer ? graySize : 0;
    }
    
    if (grayscaleBuffer) {
        if (fb->format == PIXFORMAT_GRAYSCALE) {
            memcpy(grayscaleBuffer, fb->buf, graySize);
        } else {
            convertToGrayscale(fb, grayscaleBuffer);
        }
        
        _lastBlob = detectBrightBlob(grayscaleBuffer, fb->width, fb->height, threshold);
    }
    
    esp_camera_fb_return(fb);
    return _lastBlob;
}

uint8_t* CameraAlign::captureFrameWithOverlay(size_t& len, const CameraOverlay& overlay) {
    len = 0;
    if (!_initialized) return nullptr;
    
    // Need RGB565 format for overlay drawing
    esp_camera_deinit();
    
    camera_config_t config;
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = CAM_PIN_D0;
    config.pin_d1 = CAM_PIN_D1;
    config.pin_d2 = CAM_PIN_D2;
    config.pin_d3 = CAM_PIN_D3;
    config.pin_d4 = CAM_PIN_D4;
    config.pin_d5 = CAM_PIN_D5;
    config.pin_d6 = CAM_PIN_D6;
    config.pin_d7 = CAM_PIN_D7;
    config.pin_xclk = CAM_PIN_XCLK;
    config.pin_pclk = CAM_PIN_PCLK;
    config.pin_vsync = CAM_PIN_VSYNC;
    config.pin_href = CAM_PIN_HREF;
    config.pin_sccb_sda = CAM_PIN_SIOD;
    config.pin_sccb_scl = CAM_PIN_SIOC;
    config.pin_pwdn = CAM_PIN_PWDN;
    config.pin_reset = CAM_PIN_RESET;
    config.xclk_freq_hz = 20000000;
    config.pixel_format = PIXFORMAT_RGB565;
    config.frame_size = FRAMESIZE_VGA;
    config.jpeg_quality = 12;
    config.fb_count = 1;
    config.fb_location = CAMERA_FB_IN_PSRAM;
    config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
    
    if (esp_camera_init(&config) != ESP_OK) {
        switchToJPEG();  // Restore normal mode
        return nullptr;
    }
    
    camera_fb_t* fb = esp_camera_fb_get();
    if (!fb) {
        switchToJPEG();
        return nullptr;
    }
    
    uint8_t* rgb565 = fb->buf;
    int width = fb->width;
    int height = fb->height;
    
    // Draw overlays
    uint16_t crosshairColor = rgbToRgb565(overlay.crosshairColor[0], 
                                           overlay.crosshairColor[1], 
                                           overlay.crosshairColor[2]);
    uint16_t blobColor = rgbToRgb565(overlay.blobColor[0], 
                                      overlay.blobColor[1], 
                                      overlay.blobColor[2]);
    
    if (overlay.showGrid) {
        drawGrid(rgb565, width, height, crosshairColor);
    }
    
    if (overlay.showCrosshairs) {
        drawCrosshairs(rgb565, width, height, crosshairColor);
    }
    
    if (overlay.showBlobMarker && _lastBlob.found) {
        drawBlobMarker(rgb565, width, height, _lastBlob.centerX, _lastBlob.centerY, blobColor);
    }
    
    // Convert RGB565 to JPEG
    uint8_t* jpeg = nullptr;
    size_t jpegLen = 0;
    
    bool converted = frame2jpg(fb, 80, &jpeg, &jpegLen);
    
    esp_camera_fb_return(fb);
    switchToJPEG();  // Restore normal mode
    
    if (!converted) {
        return nullptr;
    }
    
    len = jpegLen;
    return jpeg;  // Caller must free()
}

// =========================================================================
// Drawing Primitives
// =========================================================================

uint16_t CameraAlign::rgbToRgb565(uint8_t r, uint8_t g, uint8_t b) {
    return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}

void CameraAlign::drawPixel(uint8_t* rgb565, int width, int x, int y, uint16_t color) {
    if (x < 0 || x >= width || y < 0 || y >= _frameHeight) return;
    uint16_t* pixels = (uint16_t*)rgb565;
    pixels[y * width + x] = color;
}

void CameraAlign::drawLine(uint8_t* rgb565, int width, int height, 
                           int x0, int y0, int x1, int y1, uint16_t color) {
    // Bresenham's line algorithm
    int dx = abs(x1 - x0);
    int dy = abs(y1 - y0);
    int sx = x0 < x1 ? 1 : -1;
    int sy = y0 < y1 ? 1 : -1;
    int err = dx - dy;
    
    while (true) {
        drawPixel(rgb565, width, x0, y0, color);
        
        if (x0 == x1 && y0 == y1) break;
        
        int e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            x0 += sx;
        }
        if (e2 < dx) {
            err += dx;
            y0 += sy;
        }
    }
}

void CameraAlign::drawCircle(uint8_t* rgb565, int width, int height, 
                             int cx, int cy, int r, uint16_t color) {
    // Midpoint circle algorithm
    int x = r;
    int y = 0;
    int err = 0;
    
    while (x >= y) {
        drawPixel(rgb565, width, cx + x, cy + y, color);
        drawPixel(rgb565, width, cx + y, cy + x, color);
        drawPixel(rgb565, width, cx - y, cy + x, color);
        drawPixel(rgb565, width, cx - x, cy + y, color);
        drawPixel(rgb565, width, cx - x, cy - y, color);
        drawPixel(rgb565, width, cx - y, cy - x, color);
        drawPixel(rgb565, width, cx + y, cy - x, color);
        drawPixel(rgb565, width, cx + x, cy - y, color);
        
        y++;
        err += 1 + 2 * y;
        if (2 * (err - x) + 1 > 0) {
            x--;
            err += 1 - 2 * x;
        }
    }
}

void CameraAlign::drawCrosshairs(uint8_t* rgb565, int width, int height, uint16_t color) {
    int cx = width / 2;
    int cy = height / 2;
    int size = ALIGNMENT_CROSSHAIR_SIZE;
    
    // Horizontal line with gap in center
    drawLine(rgb565, width, height, cx - size, cy, cx - 5, cy, color);
    drawLine(rgb565, width, height, cx + 5, cy, cx + size, cy, color);
    
    // Vertical line with gap in center
    drawLine(rgb565, width, height, cx, cy - size, cx, cy - 5, color);
    drawLine(rgb565, width, height, cx, cy + 5, cx, cy + size, color);
    
    // Center dot
    drawPixel(rgb565, width, cx, cy, color);
}

void CameraAlign::drawBlobMarker(uint8_t* rgb565, int width, int height, 
                                  int x, int y, uint16_t color) {
    // Draw circle around detected blob
    drawCircle(rgb565, width, height, x, y, BLOB_MARKER_RADIUS, color);
    
    // Draw crosshairs at blob position
    drawLine(rgb565, width, height, x - 10, y, x - 3, y, color);
    drawLine(rgb565, width, height, x + 3, y, x + 10, y, color);
    drawLine(rgb565, width, height, x, y - 10, x, y - 3, color);
    drawLine(rgb565, width, height, x, y + 3, x, y + 10, color);
}

void CameraAlign::drawGrid(uint8_t* rgb565, int width, int height, uint16_t color) {
    // Draw grid lines every 60 pixels (approximately FOV/10)
    int gridSpacing = 60;
    
    // Vertical lines
    for (int x = gridSpacing; x < width; x += gridSpacing) {
        for (int y = 0; y < height; y += 4) {  // Dashed line
            drawPixel(rgb565, width, x, y, color);
        }
    }
    
    // Horizontal lines
    for (int y = gridSpacing; y < height; y += gridSpacing) {
        for (int x = 0; x < width; x += 4) {  // Dashed line
            drawPixel(rgb565, width, x, y, color);
        }
    }
}

void CameraAlign::convertRGB565ToGrayscale(camera_fb_t* fb, uint8_t* output) {
    uint16_t* rgb = (uint16_t*)fb->buf;
    for (int i = 0; i < fb->width * fb->height; i++) {
        uint16_t pixel = rgb[i];
        uint8_t r = (pixel >> 11) & 0x1F;
        uint8_t g = (pixel >> 5) & 0x3F;
        uint8_t b = pixel & 0x1F;
        // Convert to 8-bit and calculate luminance
        r = (r * 255) / 31;
        g = (g * 255) / 63;
        b = (b * 255) / 31;
        output[i] = (r * 77 + g * 150 + b * 29) >> 8;
    }
}
