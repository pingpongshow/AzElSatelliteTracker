/**
 * @file web_server.cpp
 * @brief Web server implementation
 */

#include "web_server.h"
#include "stepper_control.h"
#include "tracking_engine.h"
#include "tle_manager.h"
#include "wifi_manager.h"
#include "gps.h"
#include "camera_align.h"
#include "nvs_storage.h"
#include "rotctld_server.h"
#include "health_monitor.h"
#include "sd_storage.h"
#include "external_api.h"
#include "udp_broadcast.h"
#include <SPIFFS.h>

// Global instance
WebServer webServer;

WebServer::WebServer()
    : _server(nullptr)
    , _ws(nullptr)
    , _running(false)
    , _lastBroadcast(0)
{
}

WebServer::~WebServer() {
    stop();
}

bool WebServer::begin() {
    DEBUG_PRINTLN("WebServer: Initializing...");
    
    // Initialize SPIFFS for static files
    if (!SPIFFS.begin(true)) {
        DEBUG_PRINTLN("WebServer: SPIFFS mount failed");
        return false;
    }
    
    // Create server
    _server = new AsyncWebServer(WEB_SERVER_PORT);
    _ws = new AsyncWebSocket("/ws");
    
    // Setup routes
    setupRoutes();
    setupAPIRoutes();
    setupCameraRoutes();
    setupAdvancedRoutes();
    setupWebSocketHandler();
    
    // Start server
    _server->begin();
    _running = true;
    _streamActive = false;
    
    DEBUG_PRINTF("WebServer: Started on port %d\n", WEB_SERVER_PORT);
    return true;
}

void WebServer::stop() {
    if (_running) {
        _server->end();
        
        // Delete all JSON handlers to prevent memory leak on restart
        for (auto handler : _jsonHandlers) {
            delete handler;
        }
        _jsonHandlers.clear();
        
        delete _ws;
        delete _server;
        _ws = nullptr;
        _server = nullptr;
        _running = false;
    }
}

void WebServer::update() {
    if (!_running) return;
    
    // Cleanup disconnected WebSocket clients
    _ws->cleanupClients();
    
    // Periodic status broadcast
    uint32_t now = millis();
    if (now - _lastBroadcast >= STATUS_UPDATE_INTERVAL_MS) {
        broadcastStatus();
        _lastBroadcast = now;
    }
}

void WebServer::broadcastStatus() {
    if (_ws->count() == 0) return;
    
    String json = buildStatusJSON();
    _ws->textAll(json);
}

void WebServer::sendEvent(const char* event, const char* data) {
    if (_ws->count() == 0) return;
    
    JsonDocument doc;
    doc["event"] = event;
    doc["data"] = data;
    
    String json;
    serializeJson(doc, json);
    _ws->textAll(json);
}

void WebServer::setupRoutes() {
    // Serve static files from SPIFFS
    _server->serveStatic("/", SPIFFS, "/").setDefaultFile("index.html");
    
    // Root handler (for SPA routing)
    _server->on("/", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleRoot(request);
    });
    
    // 404 handler
    _server->onNotFound([this](AsyncWebServerRequest* request) {
        handleNotFound(request);
    });
}

void WebServer::setupAPIRoutes() {
    // Status endpoints
    _server->on("/api/status", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetStatus(request);
    });
    
    _server->on("/api/position", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetPosition(request);
    });
    
    _server->on("/api/gps", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetGPS(request);
    });
    
    _server->on("/api/config", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetConfig(request);
    });
    
    // Control endpoints
    AsyncCallbackJsonWebHandler* posHandler = new AsyncCallbackJsonWebHandler("/api/position",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleSetPosition(request, json);
        });
    _server->addHandler(posHandler);
    _jsonHandlers.push_back(posHandler);
    
    _server->on("/api/stop", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleStop(request);
    });
    
    _server->on("/api/park", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handlePark(request);
    });
    
    _server->on("/api/home", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleHome(request);
    });
    
    _server->on("/api/sethome", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleSetHome(request);
    });
    
    AsyncCallbackJsonWebHandler* calibHandler = new AsyncCallbackJsonWebHandler("/api/calibrate",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleCalibrate(request, json);
        });
    _server->addHandler(calibHandler);
    _jsonHandlers.push_back(calibHandler);
    
    // Tracking endpoints
    AsyncCallbackJsonWebHandler* trackHandler = new AsyncCallbackJsonWebHandler("/api/track",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleStartTracking(request, json);
        });
    _server->addHandler(trackHandler);
    _jsonHandlers.push_back(trackHandler);
    
    _server->on("/api/track", HTTP_DELETE, [this](AsyncWebServerRequest* request) {
        handleStopTracking(request);
    });
    
    _server->on("/api/nextpass", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetNextPass(request);
    });
    
    // TLE endpoints
    _server->on("/api/tle", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetTLEs(request);
    });
    
    AsyncCallbackJsonWebHandler* tleHandler = new AsyncCallbackJsonWebHandler("/api/tle",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleLoadTLE(request, json);
        });
    _server->addHandler(tleHandler);
    _jsonHandlers.push_back(tleHandler);
    
    AsyncCallbackJsonWebHandler* fetchHandler = new AsyncCallbackJsonWebHandler("/api/tle/fetch",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleFetchTLE(request, json);
        });
    _server->addHandler(fetchHandler);
    _jsonHandlers.push_back(fetchHandler);
    
    // WiFi endpoints
    _server->on("/api/wifi/networks", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetNetworks(request);
    });
    
    AsyncCallbackJsonWebHandler* wifiHandler = new AsyncCallbackJsonWebHandler("/api/wifi/connect",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleConnectWiFi(request, json);
        });
    _server->addHandler(wifiHandler);
    _jsonHandlers.push_back(wifiHandler);
    
    _server->on("/api/wifi/status", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetWiFiStatus(request);
    });
    
    // System endpoints
    _server->on("/api/system/info", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetSystemInfo(request);
    });
    
    _server->on("/api/system/reboot", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleReboot(request);
    });
    
    _server->on("/api/system/reset", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleFactoryReset(request);
    });
    
    // GPS manual position endpoint
    AsyncCallbackJsonWebHandler* gpsManualHandler = new AsyncCallbackJsonWebHandler("/api/gps/manual",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleSetManualGPS(request, json);
        });
    _server->addHandler(gpsManualHandler);
    _jsonHandlers.push_back(gpsManualHandler);
}

void WebServer::setupWebSocketHandler() {
    _ws->onEvent([this](AsyncWebSocket* server, AsyncWebSocketClient* client,
                        AwsEventType type, void* arg, uint8_t* data, size_t len) {
        onWebSocketEvent(server, client, type, arg, data, len);
    });
    
    _server->addHandler(_ws);
}

void WebServer::handleRoot(AsyncWebServerRequest* request) {
    request->send(SPIFFS, "/index.html", "text/html");
}

void WebServer::handleNotFound(AsyncWebServerRequest* request) {
    // For API routes, return JSON error
    if (request->url().startsWith("/api/")) {
        sendError(request, "Endpoint not found", 404);
    } else {
        // For other routes, serve index.html (SPA routing)
        request->send(SPIFFS, "/index.html", "text/html");
    }
}

void WebServer::handleGetStatus(AsyncWebServerRequest* request) {
    JsonDocument doc;
    
    // Position
    doc["azimuth"] = stepperControl.getAzimuth();
    doc["elevation"] = stepperControl.getElevation();
    doc["targetAz"] = stepperControl.getTargetAzimuth();
    doc["targetEl"] = stepperControl.getTargetElevation();
    doc["moving"] = stepperControl.isMoving();
    doc["enabled"] = stepperControl.isEnabled();
    
    // Tracking
    doc["mode"] = (int)trackingEngine.getMode();
    doc["satellite"] = trackingEngine.getSatelliteName();
    doc["satVisible"] = trackingEngine.isSatelliteVisible();
    
    // Satellite position
    if (trackingEngine.hasTLE()) {
        SatellitePosition satPos = trackingEngine.getPosition();
        doc["satAz"] = satPos.azimuth;
        doc["satEl"] = satPos.elevation;
        doc["satRange"] = satPos.range;
    }
    
    // GPS
    doc["gpsValid"] = gps.hasFix();
    doc["gpsSats"] = gps.getSatellites();
    
    // Connection
    doc["wifiConnected"] = wifiManager.isConnected();
    doc["rotctldClients"] = rotctldServer.getClientCount();
    
    sendJSON(request, doc);
}

void WebServer::handleGetPosition(AsyncWebServerRequest* request) {
    JsonDocument doc;
    doc["azimuth"] = stepperControl.getAzimuth();
    doc["elevation"] = stepperControl.getElevation();
    doc["targetAz"] = stepperControl.getTargetAzimuth();
    doc["targetEl"] = stepperControl.getTargetElevation();
    doc["moving"] = stepperControl.isMoving();
    sendJSON(request, doc);
}

void WebServer::handleGetGPS(AsyncWebServerRequest* request) {
    JsonDocument doc;
    GPSData data = gps.getData();
    
    doc["valid"] = data.valid;
    doc["latitude"] = data.latitude;
    doc["longitude"] = data.longitude;
    doc["altitude"] = data.altitude;
    doc["satellites"] = data.satellites;
    doc["hdop"] = data.hdop;
    doc["time"] = data.unixTime;
    doc["manual"] = gps.isUsingManualPosition();
    
    sendJSON(request, doc);
}

void WebServer::handleGetConfig(AsyncWebServerRequest* request) {
    JsonDocument doc;
    
    doc["version"] = FIRMWARE_VERSION;
    doc["model"] = DEVICE_MODEL;
    doc["azMin"] = AZ_MIN_DEG;
    doc["azMax"] = AZ_MAX_DEG;
    doc["elMin"] = EL_MIN_DEG;
    doc["elMax"] = EL_MAX_DEG;
    doc["parkAz"] = PARK_AZ_DEG;
    doc["parkEl"] = PARK_EL_DEG;
    doc["azOffset"] = stepperControl.getAzimuthOffset();
    doc["elOffset"] = stepperControl.getElevationOffset();
    
    sendJSON(request, doc);
}

void WebServer::handleSetPosition(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!json.containsKey("azimuth") || !json.containsKey("elevation")) {
        sendError(request, "Missing azimuth or elevation");
        return;
    }
    
    float az = json["azimuth"].as<float>();
    float el = json["elevation"].as<float>();
    float speed = json["speed"] | TRACKING_SPEED_DEG_S;
    
    stepperControl.moveTo(az, el, speed);
    sendOK(request, "Position set");
}

void WebServer::handleStop(AsyncWebServerRequest* request) {
    stepperControl.stop();
    trackingEngine.stopTracking();
    sendOK(request, "Stopped");
}

void WebServer::handlePark(AsyncWebServerRequest* request) {
    stepperControl.park();
    sendOK(request, "Parking");
}

void WebServer::handleHome(AsyncWebServerRequest* request) {
    if (stepperControl.home()) {
        sendOK(request, "Homing complete");
    } else {
        sendError(request, "Homing failed");
    }
}

void WebServer::handleSetHome(AsyncWebServerRequest* request) {
    stepperControl.setHome();
    sendOK(request, "Home position set");
}

void WebServer::handleCalibrate(AsyncWebServerRequest* request, JsonVariant& json) {
    String method = json["method"] | "sun";
    
    if (method == "sun") {
        AlignmentResult result = cameraAlign.alignToSun();
        if (result.success) {
            char msg[128];
            snprintf(msg, sizeof(msg), "Sun alignment complete. Offsets: Az=%.3f°, El=%.3f°", 
                     result.azOffset, result.elOffset);
            sendOK(request, msg);
        } else {
            sendError(request, result.errorMessage.c_str());
        }
    } else if (method == "moon") {
        AlignmentResult result = cameraAlign.alignToMoon();
        if (result.success) {
            char msg[128];
            snprintf(msg, sizeof(msg), "Moon alignment complete. Offsets: Az=%.3f°, El=%.3f°", 
                     result.azOffset, result.elOffset);
            sendOK(request, msg);
        } else {
            sendError(request, result.errorMessage.c_str());
        }
    } else if (method == "manual") {
        float azOffset = json["azOffset"] | 0.0f;
        float elOffset = json["elOffset"] | 0.0f;
        stepperControl.setCalibrationOffset(azOffset, elOffset);
        sendOK(request, "Manual calibration set");
    } else {
        sendError(request, "Unknown calibration method");
    }
}

void WebServer::handleStartTracking(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!json.containsKey("name")) {
        sendError(request, "Missing satellite name");
        return;
    }
    
    String name = json["name"].as<String>();
    
    // Check if TLE provided or should load from storage
    if (json.containsKey("line1") && json.containsKey("line2")) {
        String line1 = json["line1"].as<String>();
        String line2 = json["line2"].as<String>();
        
        if (!trackingEngine.loadTLE(name.c_str(), line1.c_str(), line2.c_str())) {
            sendError(request, "Invalid TLE data");
            return;
        }
    } else {
        // Try to load from storage
        TLEEntry entry;
        if (!tleManager.findStoredTLE(name.c_str(), entry)) {
            sendError(request, "TLE not found in storage");
            return;
        }
        
        if (!trackingEngine.loadTLE(entry.name, entry.line1, entry.line2)) {
            sendError(request, "Failed to load TLE");
            return;
        }
    }
    
    if (trackingEngine.startTracking()) {
        sendOK(request, "Tracking started");
    } else {
        sendError(request, "Failed to start tracking");
    }
}

void WebServer::handleStopTracking(AsyncWebServerRequest* request) {
    trackingEngine.stopTracking();
    sendOK(request, "Tracking stopped");
}

void WebServer::handleGetNextPass(AsyncWebServerRequest* request) {
    PassInfo pass;
    
    if (!trackingEngine.getNextPass(pass)) {
        sendError(request, "No pass found", 404);
        return;
    }
    
    JsonDocument doc;
    doc["aosTime"] = pass.aosTime;
    doc["losTime"] = pass.losTime;
    doc["maxElTime"] = pass.maxElTime;
    doc["aosAz"] = pass.aosAz;
    doc["losAz"] = pass.losAz;
    doc["maxEl"] = pass.maxEl;
    doc["maxElAz"] = pass.maxElAz;
    doc["duration"] = pass.losTime - pass.aosTime;
    
    sendJSON(request, doc);
}

void WebServer::handleGetTLEs(AsyncWebServerRequest* request) {
    JsonDocument doc;
    JsonArray tles = doc["tles"].to<JsonArray>();
    
    String names[MAX_STORED_TLES];
    int count = tleManager.listStoredTLEs(names, MAX_STORED_TLES);
    
    for (int i = 0; i < count; i++) {
        TLEEntry entry;
        if (tleManager.findStoredTLE(names[i].c_str(), entry)) {
            JsonObject tle = tles.add<JsonObject>();
            tle["name"] = entry.name;
            tle["stale"] = tleManager.isTLEStale(entry);
        }
    }
    
    doc["count"] = count;
    sendJSON(request, doc);
}

void WebServer::handleLoadTLE(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!json.containsKey("name") || !json.containsKey("line1") || !json.containsKey("line2")) {
        sendError(request, "Missing TLE data");
        return;
    }
    
    TLEEntry entry;
    strncpy(entry.name, json["name"].as<const char*>(), sizeof(entry.name) - 1);
    strncpy(entry.line1, json["line1"].as<const char*>(), sizeof(entry.line1) - 1);
    strncpy(entry.line2, json["line2"].as<const char*>(), sizeof(entry.line2) - 1);
    entry.fetchTime = millis() / 1000;
    entry.valid = true;
    
    // Find empty slot or slot with same name
    int slot = -1;
    for (int i = 0; i < MAX_STORED_TLES; i++) {
        TLEEntry existing;
        if (!tleManager.loadTLE(i, existing)) {
            slot = i;
            break;
        }
        if (strcasecmp(existing.name, entry.name) == 0) {
            slot = i;
            break;
        }
    }
    
    if (slot < 0) {
        sendError(request, "No storage space available");
        return;
    }
    
    if (tleManager.saveTLE(entry, slot)) {
        sendOK(request, "TLE saved");
    } else {
        sendError(request, "Failed to save TLE");
    }
}

void WebServer::handleFetchTLE(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!wifiManager.isConnected()) {
        sendError(request, "No network connection");
        return;
    }
    
    TLEEntry entry;
    bool success = false;
    
    if (json.containsKey("noradId")) {
        success = tleManager.fetchByNoradId(json["noradId"].as<uint32_t>(), entry);
    } else if (json.containsKey("name")) {
        success = tleManager.fetchByName(json["name"].as<const char*>(), entry);
    } else {
        sendError(request, "Provide noradId or name");
        return;
    }
    
    if (!success) {
        sendError(request, tleManager.getLastError().c_str());
        return;
    }
    
    // Save to storage
    int slot = 0;  // Find appropriate slot
    tleManager.saveTLE(entry, slot);
    
    JsonDocument doc;
    doc["name"] = entry.name;
    doc["line1"] = entry.line1;
    doc["line2"] = entry.line2;
    sendJSON(request, doc);
}

void WebServer::handleGetNetworks(AsyncWebServerRequest* request) {
    NetworkInfo networks[20];
    int count = wifiManager.scanNetworks(networks, 20);
    
    JsonDocument doc;
    JsonArray arr = doc["networks"].to<JsonArray>();
    
    for (int i = 0; i < count; i++) {
        JsonObject net = arr.add<JsonObject>();
        net["ssid"] = networks[i].ssid;
        net["rssi"] = networks[i].rssi;
        net["open"] = networks[i].open;
    }
    
    doc["count"] = count;
    sendJSON(request, doc);
}

void WebServer::handleConnectWiFi(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!json.containsKey("ssid")) {
        sendError(request, "Missing SSID");
        return;
    }
    
    String ssid = json["ssid"].as<String>();
    String password = json["password"] | "";
    
    wifiManager.connect(ssid.c_str(), password.c_str(), true);
    sendOK(request, "Connecting...");
}

void WebServer::handleGetWiFiStatus(AsyncWebServerRequest* request) {
    JsonDocument doc;
    
    doc["mode"] = (int)wifiManager.getMode();
    doc["connected"] = wifiManager.isConnected();
    doc["ssid"] = wifiManager.getSSID();
    doc["ip"] = wifiManager.getIP().toString();
    doc["rssi"] = wifiManager.getRSSI();
    doc["hostname"] = wifiManager.getHostname();
    doc["mdns"] = wifiManager.isMDNSActive();
    
    sendJSON(request, doc);
}

void WebServer::handleGetSystemInfo(AsyncWebServerRequest* request) {
    JsonDocument doc;
    
    doc["version"] = FIRMWARE_VERSION;
    doc["model"] = DEVICE_MODEL;
    doc["freeHeap"] = ESP.getFreeHeap();
    doc["heapSize"] = ESP.getHeapSize();
    doc["freePsram"] = ESP.getFreePsram();
    doc["uptime"] = millis() / 1000;
    doc["cpuFreq"] = ESP.getCpuFreqMHz();
    doc["flashSize"] = ESP.getFlashChipSize();
    doc["sdkVersion"] = ESP.getSdkVersion();
    
    sendJSON(request, doc);
}

void WebServer::handleReboot(AsyncWebServerRequest* request) {
    sendOK(request, "Rebooting...");
    delay(500);
    ESP.restart();
}

void WebServer::handleFactoryReset(AsyncWebServerRequest* request) {
    nvsStorage.factoryReset();
    sendOK(request, "Factory reset complete. Rebooting...");
    delay(500);
    ESP.restart();
}

void WebServer::handleSetManualGPS(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!json.containsKey("latitude") || !json.containsKey("longitude")) {
        sendError(request, "Missing latitude or longitude");
        return;
    }
    
    double lat = json["latitude"].as<double>();
    double lon = json["longitude"].as<double>();
    double alt = json["altitude"] | 0.0;
    
    // Validate coordinates
    if (lat < -90 || lat > 90) {
        sendError(request, "Invalid latitude");
        return;
    }
    if (lon < -180 || lon > 180) {
        sendError(request, "Invalid longitude");
        return;
    }
    
    // Set manual position
    gps.setManualPosition(lat, lon, alt);
    gps.setUseManualPosition(true);
    
    // Update tracking engine
    trackingEngine.setObserverLocation(lat, lon, alt);
    
    // Save to NVS
    nvsStorage.saveLocation(lat, lon, alt, true);
    
    sendOK(request, "Manual position set");
}

void WebServer::onWebSocketEvent(AsyncWebSocket* server, AsyncWebSocketClient* client,
                                  AwsEventType type, void* arg, uint8_t* data, size_t len) {
    switch (type) {
        case WS_EVT_CONNECT:
            DEBUG_PRINTF("WebSocket client connected: %u\n", client->id());
            // Send initial status
            client->text(buildStatusJSON());
            break;
            
        case WS_EVT_DISCONNECT:
            DEBUG_PRINTF("WebSocket client disconnected: %u\n", client->id());
            break;
            
        case WS_EVT_DATA: {
            // Handle incoming WebSocket messages
            AwsFrameInfo* info = (AwsFrameInfo*)arg;
            if (info->final && info->index == 0 && info->len == len && info->opcode == WS_TEXT) {
                data[len] = 0;
                DEBUG_PRINTF("WebSocket message: %s\n", (char*)data);
                
                // Parse JSON command
                JsonDocument doc;
                DeserializationError error = deserializeJson(doc, (char*)data);
                if (!error) {
                    String cmd = doc["cmd"] | "";
                    // Handle WebSocket commands if needed
                }
            }
            break;
        }
            
        default:
            break;
    }
}

void WebServer::sendJSON(AsyncWebServerRequest* request, JsonDocument& doc, int code) {
    String response;
    serializeJson(doc, response);
    request->send(code, "application/json", response);
}

void WebServer::sendError(AsyncWebServerRequest* request, const char* message, int code) {
    JsonDocument doc;
    doc["error"] = message;
    sendJSON(request, doc, code);
}

void WebServer::sendOK(AsyncWebServerRequest* request, const char* message) {
    JsonDocument doc;
    doc["status"] = "ok";
    doc["message"] = message;
    sendJSON(request, doc);
}

String WebServer::buildStatusJSON() {
    JsonDocument doc;
    
    doc["type"] = "status";
    doc["az"] = stepperControl.getAzimuth();
    doc["el"] = stepperControl.getElevation();
    doc["targetAz"] = stepperControl.getTargetAzimuth();
    doc["targetEl"] = stepperControl.getTargetElevation();
    doc["moving"] = stepperControl.isMoving();
    doc["mode"] = (int)trackingEngine.getMode();
    doc["sat"] = trackingEngine.getSatelliteName();
    doc["visible"] = trackingEngine.isSatelliteVisible();
    doc["gps"] = gps.hasFix();
    doc["time"] = gps.getUnixTime();
    
    if (trackingEngine.hasTLE()) {
        SatellitePosition pos = trackingEngine.getPosition();
        doc["satAz"] = pos.azimuth;
        doc["satEl"] = pos.elevation;
    }
    
    String json;
    serializeJson(doc, json);
    return json;
}

int WebServer::getClientCount() const {
    return _ws ? _ws->count() : 0;
}

String WebServer::buildPassJSON(const PassInfo& pass) {
    JsonDocument doc;
    doc["aosTime"] = pass.aosTime;
    doc["losTime"] = pass.losTime;
    doc["maxElTime"] = pass.maxElTime;
    doc["aosAz"] = pass.aosAz;
    doc["losAz"] = pass.losAz;
    doc["maxEl"] = pass.maxEl;
    doc["maxElAz"] = pass.maxElAz;
    doc["duration"] = pass.losTime - pass.aosTime;
    
    String json;
    serializeJson(doc, json);
    return json;
}

// =========================================================================
// Camera Routes Setup
// =========================================================================

void WebServer::setupCameraRoutes() {
    // Camera snapshot (no overlay)
    _server->on("/api/camera/snapshot", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleCameraSnapshot(request);
    });
    
    // Camera snapshot with overlay
    _server->on("/api/camera/overlay", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleCameraSnapshotWithOverlay(request);
    });
    
    // MJPEG stream
    _server->on("/api/camera/stream", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleCameraStream(request);
    });
    
    // Blob detection
    _server->on("/api/camera/detect", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleCameraDetect(request);
    });
    
    // Camera settings
    AsyncCallbackJsonWebHandler* camSettingsHandler = new AsyncCallbackJsonWebHandler("/api/camera/settings",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleCameraSettings(request, json);
        });
    _server->addHandler(camSettingsHandler);
}

// =========================================================================
// Advanced Routes Setup
// =========================================================================

void WebServer::setupAdvancedRoutes() {
    // Multi-pass prediction
    _server->on("/api/passes", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetPasses(request);
    });
    
    _server->on("/api/schedule", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetSchedule(request);
    });
    
    _server->on("/api/schedule/clear", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleClearSchedule(request);
    });
    
    AsyncCallbackJsonWebHandler* scheduleHandler = new AsyncCallbackJsonWebHandler("/api/schedule",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleSchedulePass(request, json);
        });
    _server->addHandler(scheduleHandler);
    
    // Doppler
    _server->on("/api/doppler", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetDoppler(request);
    });
    
    // Health monitoring
    _server->on("/api/health", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetHealth(request);
    });
    
    _server->on("/api/health/events", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetHealthEvents(request);
    });
    
    // SD Card
    _server->on("/api/sd/status", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleSDStatus(request);
    });
    
    _server->on("/api/sd/tle", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleSDListTLEs(request);
    });
    
    _server->on("/api/sd/backup", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleSDBackupConfig(request);
    });
    
    _server->on("/api/sd/restore", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleSDRestoreConfig(request);
    });
    
    _server->on("/api/passlog", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetPassLog(request);
    });
    
    // External APIs
    AsyncCallbackJsonWebHandler* n2yoKeyHandler = new AsyncCallbackJsonWebHandler("/api/n2yo/key",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleSetN2YOKey(request, json);
        });
    _server->addHandler(n2yoKeyHandler);
    
    _server->on("/api/satnogs/search", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleSearchSatNOGS(request);
    });
    
    _server->on("/api/satnogs/transmitters", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetTransmitters(request);
    });
    
    // UDP Broadcast
    _server->on("/api/udp/status", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleUDPStatus(request);
    });
    
    AsyncCallbackJsonWebHandler* udpHandler = new AsyncCallbackJsonWebHandler("/api/udp/config",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleUDPConfig(request, json);
        });
    _server->addHandler(udpHandler);
    
    // EME Mode
    _server->on("/api/eme/enable", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleEnableEME(request);
    });
    
    _server->on("/api/eme/disable", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleDisableEME(request);
    });
    
    _server->on("/api/moon", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetMoonInfo(request);
    });
    
    _server->on("/api/eme/pathloss", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetEMEPathLoss(request);
    });
    
    // Geo Satellite Mode
    AsyncCallbackJsonWebHandler* geoHandler = new AsyncCallbackJsonWebHandler("/api/geo/point",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handlePointToGeo(request, json);
        });
    _server->addHandler(geoHandler);
    
    AsyncCallbackJsonWebHandler* geoTrackHandler = new AsyncCallbackJsonWebHandler("/api/geo/track",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleEnableGeoTracking(request, json);
        });
    _server->addHandler(geoTrackHandler);
    
    _server->on("/api/geo/disable", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleDisableGeoTracking(request);
    });
    
    // Antenna Pattern
    _server->on("/api/antenna", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetAntennaPattern(request);
    });
    
    AsyncCallbackJsonWebHandler* antennaHandler = new AsyncCallbackJsonWebHandler("/api/antenna",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleSetAntennaPattern(request, json);
        });
    _server->addHandler(antennaHandler);
    
    // Pre-positioning
    AsyncCallbackJsonWebHandler* preposHandler = new AsyncCallbackJsonWebHandler("/api/preposition",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleSetPrePosition(request, json);
        });
    _server->addHandler(preposHandler);
}

// =========================================================================
// Camera Handlers Implementation
// =========================================================================

void WebServer::handleCameraSnapshot(AsyncWebServerRequest* request) {
    if (!cameraAlign.isInitialized()) {
        sendError(request, "Camera not initialized", 503);
        return;
    }
    
    camera_fb_t* fb = cameraAlign.getStreamFrame();
    if (!fb) {
        sendError(request, "Failed to capture frame", 500);
        return;
    }
    
    AsyncWebServerResponse* response = request->beginResponse_P(200, "image/jpeg", fb->buf, fb->len);
    response->addHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    request->send(response);
    
    cameraAlign.releaseFrame(fb);
}

void WebServer::handleCameraSnapshotWithOverlay(AsyncWebServerRequest* request) {
    if (!cameraAlign.isInitialized()) {
        sendError(request, "Camera not initialized", 503);
        return;
    }
    
    // Configure overlay based on query params
    CameraOverlay overlay;
    overlay.showCrosshairs = request->hasParam("crosshairs") ? 
                              request->getParam("crosshairs")->value() == "1" : true;
    overlay.showBlobMarker = request->hasParam("blob") ?
                              request->getParam("blob")->value() == "1" : true;
    overlay.showGrid = request->hasParam("grid") ?
                        request->getParam("grid")->value() == "1" : false;
    overlay.showPositionText = false;
    
    // Default colors: green crosshairs, red blob marker
    overlay.crosshairColor[0] = 0;
    overlay.crosshairColor[1] = 255;
    overlay.crosshairColor[2] = 0;
    overlay.blobColor[0] = 255;
    overlay.blobColor[1] = 0;
    overlay.blobColor[2] = 0;
    
    // Detect blob first
    uint8_t threshold = request->hasParam("threshold") ?
                         request->getParam("threshold")->value().toInt() : 180;
    cameraAlign.detectBlob(threshold);
    
    size_t len;
    uint8_t* jpeg = cameraAlign.captureFrameWithOverlay(len, overlay);
    
    if (!jpeg) {
        sendError(request, "Failed to capture frame with overlay", 500);
        return;
    }
    
    AsyncWebServerResponse* response = request->beginResponse_P(200, "image/jpeg", jpeg, len);
    response->addHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    request->send(response);
    
    free(jpeg);
}

void WebServer::handleCameraStream(AsyncWebServerRequest* request) {
    // MJPEG streaming - use chunked response
    if (!cameraAlign.isInitialized()) {
        sendError(request, "Camera not initialized", 503);
        return;
    }
    
    // For MJPEG streaming, we use a special response type
    // Note: This is a simplified implementation. A proper MJPEG stream
    // would need a dedicated streaming task.
    
    AsyncWebServerResponse* response = request->beginChunkedResponse("multipart/x-mixed-replace; boundary=frame",
        [](uint8_t* buffer, size_t maxLen, size_t index) -> size_t {
            camera_fb_t* fb = cameraAlign.getStreamFrame();
            if (!fb) return 0;
            
            // Build MJPEG frame header
            String header = "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ";
            header += String(fb->len);
            header += "\r\n\r\n";
            
            size_t totalLen = header.length() + fb->len + 2;  // +2 for trailing \r\n
            
            if (totalLen > maxLen) {
                cameraAlign.releaseFrame(fb);
                return 0;
            }
            
            // Copy header
            memcpy(buffer, header.c_str(), header.length());
            
            // Copy JPEG data
            memcpy(buffer + header.length(), fb->buf, fb->len);
            
            // Trailing newline
            buffer[header.length() + fb->len] = '\r';
            buffer[header.length() + fb->len + 1] = '\n';
            
            cameraAlign.releaseFrame(fb);
            
            return totalLen;
        }
    );
    
    response->addHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    response->addHeader("Access-Control-Allow-Origin", "*");
    request->send(response);
}

void WebServer::handleCameraSettings(AsyncWebServerRequest* request, JsonVariant& json) {
    if (json.containsKey("exposure")) {
        cameraAlign.setExposure(json["exposure"].as<int>());
    }
    if (json.containsKey("gain")) {
        cameraAlign.setGain(json["gain"].as<int>());
    }
    if (json.containsKey("quality")) {
        cameraAlign.setQuality(json["quality"].as<int>());
    }
    if (json.containsKey("autoExposure") && json["autoExposure"].as<bool>()) {
        cameraAlign.resetAutoExposure();
    }
    
    sendOK(request, "Camera settings updated");
}

void WebServer::handleCameraDetect(AsyncWebServerRequest* request) {
    if (!cameraAlign.isInitialized()) {
        sendError(request, "Camera not initialized", 503);
        return;
    }
    
    uint8_t threshold = request->hasParam("threshold") ?
                         request->getParam("threshold")->value().toInt() : 180;
    
    BlobDetection blob = cameraAlign.detectBlob(threshold);
    
    JsonDocument doc;
    doc["found"] = blob.found;
    doc["centerX"] = blob.centerX;
    doc["centerY"] = blob.centerY;
    doc["pixelCount"] = blob.pixelCount;
    doc["brightness"] = blob.brightness;
    doc["frameWidth"] = cameraAlign.getFrameWidth();
    doc["frameHeight"] = cameraAlign.getFrameHeight();
    
    sendJSON(request, doc);
}

// =========================================================================
// Multi-Pass Handlers Implementation
// =========================================================================

void WebServer::handleGetPasses(AsyncWebServerRequest* request) {
    if (!trackingEngine.hasTLE()) {
        sendError(request, "No TLE loaded", 400);
        return;
    }
    
    int hours = request->hasParam("hours") ?
                 request->getParam("hours")->value().toInt() : PASS_SEARCH_HOURS;
    float minEl = request->hasParam("minEl") ?
                   request->getParam("minEl")->value().toFloat() : PASS_MIN_ELEVATION;
    
    PassInfo passes[MAX_PREDICTED_PASSES];
    int count = trackingEngine.getPasses(passes, MAX_PREDICTED_PASSES, hours, minEl);
    
    JsonDocument doc;
    JsonArray passArray = doc["passes"].to<JsonArray>();
    
    for (int i = 0; i < count; i++) {
        JsonObject p = passArray.add<JsonObject>();
        p["aosTime"] = passes[i].aosTime;
        p["losTime"] = passes[i].losTime;
        p["maxElTime"] = passes[i].maxElTime;
        p["aosAz"] = passes[i].aosAz;
        p["losAz"] = passes[i].losAz;
        p["maxEl"] = passes[i].maxEl;
        p["maxElAz"] = passes[i].maxElAz;
        p["duration"] = passes[i].losTime - passes[i].aosTime;
    }
    
    doc["count"] = count;
    doc["satellite"] = trackingEngine.getSatelliteName();
    
    sendJSON(request, doc);
}

void WebServer::handleSchedulePass(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!json.containsKey("satellite") || !json.containsKey("aosTime")) {
        sendError(request, "Missing satellite or aosTime", 400);
        return;
    }
    
    PassInfo pass;
    pass.aosTime = json["aosTime"].as<uint32_t>();
    pass.losTime = json["losTime"] | (pass.aosTime + 600);
    pass.maxElTime = json["maxElTime"] | (pass.aosTime + 300);
    pass.aosAz = json["aosAz"] | 0;
    pass.losAz = json["losAz"] | 0;
    pass.maxEl = json["maxEl"] | 45;
    pass.maxElAz = json["maxElAz"] | 180;
    
    bool prePosition = json["prePosition"] | true;
    
    if (trackingEngine.schedulePass(json["satellite"].as<const char*>(), pass, prePosition)) {
        sendOK(request, "Pass scheduled");
    } else {
        sendError(request, "Failed to schedule pass - schedule full", 400);
    }
}

void WebServer::handleCancelPass(AsyncWebServerRequest* request, JsonVariant& json) {
    int index = json["index"] | -1;
    if (index < 0) {
        sendError(request, "Missing index", 400);
        return;
    }
    
    trackingEngine.cancelScheduledPass(index);
    sendOK(request, "Pass cancelled");
}

void WebServer::handleGetSchedule(AsyncWebServerRequest* request) {
    ScheduledPass passes[MAX_SCHEDULED_PASSES];
    int count = trackingEngine.getScheduledPasses(passes, MAX_SCHEDULED_PASSES);
    
    JsonDocument doc;
    JsonArray passArray = doc["schedule"].to<JsonArray>();
    
    for (int i = 0; i < count; i++) {
        JsonObject p = passArray.add<JsonObject>();
        p["satellite"] = passes[i].satellite;
        p["aosTime"] = passes[i].pass.aosTime;
        p["losTime"] = passes[i].pass.losTime;
        p["maxEl"] = passes[i].pass.maxEl;
        p["autoTrack"] = passes[i].autoTrack;
        p["prePosition"] = passes[i].prePosition;
        p["active"] = passes[i].active;
    }
    
    doc["count"] = count;
    
    sendJSON(request, doc);
}

void WebServer::handleClearSchedule(AsyncWebServerRequest* request) {
    trackingEngine.clearSchedule();
    sendOK(request, "Schedule cleared");
}

// =========================================================================
// Doppler Handler Implementation
// =========================================================================

void WebServer::handleGetDoppler(AsyncWebServerRequest* request) {
    if (!trackingEngine.hasTLE()) {
        sendError(request, "No TLE loaded", 400);
        return;
    }
    
    float uplink = request->hasParam("uplink") ?
                    request->getParam("uplink")->value().toFloat() : 0;
    float downlink = request->hasParam("downlink") ?
                      request->getParam("downlink")->value().toFloat() : 0;
    
    DopplerInfo doppler = trackingEngine.getDoppler(uplink, downlink);
    
    JsonDocument doc;
    doc["rangeRate"] = doppler.rangeRateKmS;
    doc["rxShift"] = doppler.rxShiftHz;
    doc["txShift"] = doppler.txShiftHz;
    doc["correctedRx"] = doppler.correctedRxMHz;
    doc["correctedTx"] = doppler.correctedTxMHz;
    
    sendJSON(request, doc);
}

// =========================================================================
// Health Monitoring Handlers Implementation
// =========================================================================

void WebServer::handleGetHealth(AsyncWebServerRequest* request) {
    HealthStatus health = healthMonitor.getStatus();
    
    JsonDocument doc;
    doc["status"] = health.overallHealthy ? 0 : 1;
    doc["gpsValid"] = health.gpsHealthy;
    doc["gpsAge"] = health.gpsAge;
    doc["gpsSats"] = 0;  // Not tracked in current implementation
    doc["motorsEnabled"] = true;
    doc["azMotorOk"] = health.motorAzHealthy;
    doc["elMotorOk"] = health.motorElHealthy;
    doc["wifiConnected"] = health.wifiHealthy;
    doc["wifiRSSI"] = health.wifiRSSI;
    doc["freeHeap"] = health.freeHeap;
    doc["minFreeHeap"] = health.minFreeHeap;
    doc["freePsram"] = health.freePsram;
    doc["heapFrag"] = 0;  // Calculated separately if needed
    doc["cameraOk"] = health.cameraHealthy;
    doc["sdMounted"] = sdStorage.isAvailable();
    doc["uptime"] = health.uptime;
    doc["wsClients"] = getClientCount();
    doc["rotctldClients"] = rotctldServer.getClientCount();
    
    sendJSON(request, doc);
}

void WebServer::handleGetHealthEvents(AsyncWebServerRequest* request) {
    HealthEvent events[32];
    int count = healthMonitor.getEventLog(events, 32);
    
    JsonDocument doc;
    JsonArray eventArray = doc["events"].to<JsonArray>();
    
    for (int i = 0; i < count; i++) {
        JsonObject e = eventArray.add<JsonObject>();
        e["time"] = events[i].timestamp;
        e["issue"] = (int)events[i].issue;
        e["resolved"] = events[i].resolved;
        e["message"] = events[i].description;
    }
    
    doc["count"] = count;
    
    sendJSON(request, doc);
}

void WebServer::handleClearHealthEvents(AsyncWebServerRequest* request) {
    healthMonitor.clearEventLog();
    sendOK(request, "Health events cleared");
}

// =========================================================================
// SD Card Handlers Implementation
// =========================================================================

void WebServer::handleSDStatus(AsyncWebServerRequest* request) {
    JsonDocument doc;
    doc["available"] = sdStorage.isAvailable();
    
    if (sdStorage.isAvailable()) {
        uint32_t totalMB, usedMB;
        sdStorage.getCardInfo(totalMB, usedMB);
        doc["totalMB"] = totalMB;
        doc["usedMB"] = usedMB;
        doc["freeMB"] = totalMB - usedMB;
        doc["hasBackup"] = sdStorage.hasConfigBackup();
    }
    
    sendJSON(request, doc);
}

void WebServer::handleSDListTLEs(AsyncWebServerRequest* request) {
    if (!sdStorage.isAvailable()) {
        sendError(request, "SD card not available", 503);
        return;
    }
    
    String names[50];
    int count = sdStorage.listTLEs(names, 50);
    
    JsonDocument doc;
    JsonArray tleArray = doc["tles"].to<JsonArray>();
    
    for (int i = 0; i < count; i++) {
        tleArray.add(names[i]);
    }
    
    doc["count"] = count;
    
    sendJSON(request, doc);
}

void WebServer::handleSDImportTLE(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!sdStorage.isAvailable()) {
        sendError(request, "SD card not available", 503);
        return;
    }
    
    const char* filename = json["filename"] | "/tle_import.txt";
    int count = sdStorage.importTLEFile(filename);
    
    JsonDocument doc;
    doc["imported"] = count;
    sendJSON(request, doc);
}

void WebServer::handleSDExportTLEs(AsyncWebServerRequest* request) {
    if (!sdStorage.isAvailable()) {
        sendError(request, "SD card not available", 503);
        return;
    }
    
    int count = sdStorage.exportTLEFile("/tle_export.txt");
    
    JsonDocument doc;
    doc["exported"] = count;
    doc["filename"] = "/tle_export.txt";
    sendJSON(request, doc);
}

void WebServer::handleSDBackupConfig(AsyncWebServerRequest* request) {
    if (!sdStorage.isAvailable()) {
        sendError(request, "SD card not available", 503);
        return;
    }
    
    if (sdStorage.backupConfig()) {
        sendOK(request, "Configuration backed up to SD");
    } else {
        sendError(request, "Backup failed", 500);
    }
}

void WebServer::handleSDRestoreConfig(AsyncWebServerRequest* request) {
    if (!sdStorage.isAvailable()) {
        sendError(request, "SD card not available", 503);
        return;
    }
    
    if (sdStorage.restoreConfig()) {
        sendOK(request, "Configuration restored from SD");
    } else {
        sendError(request, "Restore failed - no backup found", 404);
    }
}

void WebServer::handleGetPassLog(AsyncWebServerRequest* request) {
    if (!sdStorage.isAvailable()) {
        sendError(request, "SD card not available", 503);
        return;
    }
    
    PassLogEntry entries[20];
    int count = sdStorage.getPassHistory(entries, 20);
    
    JsonDocument doc;
    JsonArray logArray = doc["passes"].to<JsonArray>();
    
    for (int i = 0; i < count; i++) {
        JsonObject e = logArray.add<JsonObject>();
        e["timestamp"] = entries[i].timestamp;
        e["satellite"] = entries[i].satellite;
        e["duration"] = entries[i].duration;
        e["maxEl"] = entries[i].maxElevation;
        e["success"] = entries[i].trackingSuccess;
        e["signal"] = entries[i].signalQuality;
    }
    
    doc["count"] = count;
    
    // Get stats
    int totalPasses, successfulPasses;
    float avgMaxEl;
    sdStorage.getPassStats(totalPasses, successfulPasses, avgMaxEl);
    doc["totalPasses"] = totalPasses;
    doc["successfulPasses"] = successfulPasses;
    doc["avgMaxEl"] = avgMaxEl;
    
    sendJSON(request, doc);
}

void WebServer::handleExportPassLog(AsyncWebServerRequest* request) {
    if (!sdStorage.isAvailable()) {
        sendError(request, "SD card not available", 503);
        return;
    }
    
    if (sdStorage.exportPassLogCSV("/passlog.csv")) {
        sendOK(request, "Pass log exported to /passlog.csv");
    } else {
        sendError(request, "Export failed", 500);
    }
}

// =========================================================================
// External API Handlers Implementation
// =========================================================================

void WebServer::handleSetN2YOKey(AsyncWebServerRequest* request, JsonVariant& json) {
    const char* key = json["key"];
    if (!key || strlen(key) == 0) {
        sendError(request, "Missing API key", 400);
        return;
    }
    
    externalAPI.setN2YOApiKey(key);
    sendOK(request, "N2YO API key set");
}

void WebServer::handleFetchN2YOTLE(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!externalAPI.hasN2YOApiKey()) {
        sendError(request, "N2YO API key not set", 400);
        return;
    }
    
    uint32_t noradId = json["noradId"] | 0;
    if (noradId == 0) {
        sendError(request, "Missing NORAD ID", 400);
        return;
    }
    
    TLEEntry entry;
    if (externalAPI.fetchTLEFromN2YO(noradId, entry)) {
        JsonDocument doc;
        doc["name"] = entry.name;
        doc["line1"] = entry.line1;
        doc["line2"] = entry.line2;
        sendJSON(request, doc);
    } else {
        sendError(request, externalAPI.getLastError().c_str(), 500);
    }
}

void WebServer::handleGetVisualPasses(AsyncWebServerRequest* request) {
    if (!externalAPI.hasN2YOApiKey()) {
        sendError(request, "N2YO API key not set", 400);
        return;
    }
    
    if (!request->hasParam("noradId")) {
        sendError(request, "Missing noradId parameter", 400);
        return;
    }
    
    uint32_t noradId = request->getParam("noradId")->value().toInt();
    int days = request->hasParam("days") ? request->getParam("days")->value().toInt() : 7;
    int minVis = request->hasParam("minVis") ? request->getParam("minVis")->value().toInt() : 60;
    
    // Get observer location
    GPSData gpsData = gps.getData();
    float lat = gpsData.latitude;
    float lon = gpsData.longitude;
    float alt = gpsData.altitude;
    
    VisualPass passes[10];
    int count = externalAPI.getVisualPasses(noradId, lat, lon, alt, days, minVis, passes, 10);
    
    JsonDocument doc;
    JsonArray passArray = doc["passes"].to<JsonArray>();
    
    for (int i = 0; i < count; i++) {
        JsonObject p = passArray.add<JsonObject>();
        p["startTime"] = passes[i].startTime;
        p["maxTime"] = passes[i].maxTime;
        p["endTime"] = passes[i].endTime;
        p["startAz"] = passes[i].startAz;
        p["startEl"] = passes[i].startEl;
        p["maxAz"] = passes[i].maxAz;
        p["maxEl"] = passes[i].maxEl;
        p["endAz"] = passes[i].endAz;
        p["endEl"] = passes[i].endEl;
        p["magnitude"] = passes[i].magnitude;
        p["duration"] = passes[i].duration;
    }
    
    doc["count"] = count;
    sendJSON(request, doc);
}

void WebServer::handleSearchSatNOGS(AsyncWebServerRequest* request) {
    if (!request->hasParam("query")) {
        sendError(request, "Missing query parameter", 400);
        return;
    }
    
    String query = request->getParam("query")->value();
    
    SatNOGSSatellite results[10];
    int count = externalAPI.searchSatNOGS(query.c_str(), results, 10);
    
    JsonDocument doc;
    JsonArray satArray = doc["satellites"].to<JsonArray>();
    
    for (int i = 0; i < count; i++) {
        JsonObject s = satArray.add<JsonObject>();
        s["noradId"] = results[i].noradId;
        s["name"] = results[i].name;
        s["status"] = results[i].status;
    }
    
    doc["count"] = count;
    
    sendJSON(request, doc);
}

void WebServer::handleGetTransmitters(AsyncWebServerRequest* request) {
    if (!request->hasParam("noradId")) {
        sendError(request, "Missing noradId parameter", 400);
        return;
    }
    
    uint32_t noradId = request->getParam("noradId")->value().toInt();
    
    SatNOGSTransmitter transmitters[20];
    int count = externalAPI.getTransmitters(noradId, transmitters, 20);
    
    JsonDocument doc;
    JsonArray txArray = doc["transmitters"].to<JsonArray>();
    
    for (int i = 0; i < count; i++) {
        JsonObject t = txArray.add<JsonObject>();
        t["description"] = transmitters[i].description;
        t["downlinkLow"] = transmitters[i].downlinkLow;
        t["downlinkHigh"] = transmitters[i].downlinkHigh;
        t["uplinkLow"] = transmitters[i].uplinkLow;
        t["uplinkHigh"] = transmitters[i].uplinkHigh;
        t["mode"] = transmitters[i].mode;
        t["alive"] = transmitters[i].alive;
        t["baud"] = transmitters[i].baud;
    }
    
    doc["count"] = count;
    
    sendJSON(request, doc);
}

void WebServer::handleFetchTLEGroup(AsyncWebServerRequest* request, JsonVariant& json) {
    const char* group = json["group"];
    if (!group) {
        sendError(request, "Missing group parameter", 400);
        return;
    }
    
    int count = externalAPI.fetchTLEGroup(group, nullptr);
    
    JsonDocument doc;
    doc["fetched"] = count;
    doc["group"] = group;
    sendJSON(request, doc);
}

// =========================================================================
// UDP Broadcast Handlers Implementation
// =========================================================================

void WebServer::handleUDPConfig(AsyncWebServerRequest* request, JsonVariant& json) {
    if (json.containsKey("enabled")) {
        udpBroadcast.setEnabled(json["enabled"].as<bool>());
    }
    if (json.containsKey("interval")) {
        udpBroadcast.setInterval(json["interval"].as<uint32_t>());
    }
    if (json.containsKey("format")) {
        udpBroadcast.setFormat((UDPFormat)json["format"].as<int>());
    }
    
    sendOK(request, "UDP config updated");
}

void WebServer::handleUDPStatus(AsyncWebServerRequest* request) {
    JsonDocument doc;
    doc["enabled"] = udpBroadcast.isEnabled();
    doc["port"] = udpBroadcast.getPort();
    doc["broadcasts"] = udpBroadcast.getBroadcastCount();
    
    sendJSON(request, doc);
}

// =========================================================================
// EME Mode Handlers Implementation
// =========================================================================

void WebServer::handleEnableEME(AsyncWebServerRequest* request) {
    if (trackingEngine.enableEMEMode()) {
        sendOK(request, "EME mode enabled");
    } else {
        sendError(request, "Cannot enable EME - moon below horizon", 400);
    }
}

void WebServer::handleDisableEME(AsyncWebServerRequest* request) {
    trackingEngine.disableEMEMode();
    sendOK(request, "EME mode disabled");
}

void WebServer::handleGetMoonInfo(AsyncWebServerRequest* request) {
    float moonAz, moonEl;
    trackingEngine.getMoonPosition(moonAz, moonEl);
    
    JsonDocument doc;
    doc["azimuth"] = moonAz;
    doc["elevation"] = moonEl;
    doc["visible"] = moonEl > 0;
    doc["distance"] = trackingEngine.getMoonDistance();
    doc["emeMode"] = trackingEngine.isEMEMode();
    
    sendJSON(request, doc);
}

void WebServer::handleGetEMEPathLoss(AsyncWebServerRequest* request) {
    float freq = request->hasParam("freq") ?
                  request->getParam("freq")->value().toFloat() : 144.0;
    
    JsonDocument doc;
    doc["frequency"] = freq;
    doc["pathLoss"] = trackingEngine.getEMEPathLoss(freq);
    doc["distance"] = trackingEngine.getMoonDistance();
    
    sendJSON(request, doc);
}

// =========================================================================
// Geo Satellite Handlers Implementation
// =========================================================================

void WebServer::handlePointToGeo(AsyncWebServerRequest* request, JsonVariant& json) {
    float longitude = json["longitude"] | 0;
    const char* name = json["name"] | "Geo Satellite";
    
    if (trackingEngine.pointToGeo(longitude, name)) {
        sendOK(request, "Pointing to geostationary position");
    } else {
        sendError(request, "Geostationary position not visible", 400);
    }
}

void WebServer::handleEnableGeoTracking(AsyncWebServerRequest* request, JsonVariant& json) {
    GeoSatConfig config;
    config.longitude = json["longitude"] | 0;
    config.noradId = json["noradId"] | 0;
    strncpy(config.name, json["name"] | "Geo Sat", sizeof(config.name) - 1);
    
    if (trackingEngine.enableGeoTracking(config)) {
        sendOK(request, "Geo tracking enabled");
    } else {
        sendError(request, "Cannot enable geo tracking - position not visible", 400);
    }
}

void WebServer::handleDisableGeoTracking(AsyncWebServerRequest* request) {
    trackingEngine.disableGeoTracking();
    sendOK(request, "Geo tracking disabled");
}

// =========================================================================
// Antenna Pattern Handlers Implementation
// =========================================================================

void WebServer::handleGetAntennaPattern(AsyncWebServerRequest* request) {
    AntennaPattern pattern = trackingEngine.getAntennaPattern();
    
    JsonDocument doc;
    doc["azOffset"] = pattern.azBeamOffset;
    doc["elOffset"] = pattern.elBeamOffset;
    doc["beamwidth"] = pattern.beamwidth;
    doc["enabled"] = pattern.enabled;
    
    sendJSON(request, doc);
}

void WebServer::handleSetAntennaPattern(AsyncWebServerRequest* request, JsonVariant& json) {
    AntennaPattern pattern = trackingEngine.getAntennaPattern();
    
    if (json.containsKey("azOffset")) {
        pattern.azBeamOffset = json["azOffset"].as<float>();
    }
    if (json.containsKey("elOffset")) {
        pattern.elBeamOffset = json["elOffset"].as<float>();
    }
    if (json.containsKey("beamwidth")) {
        pattern.beamwidth = json["beamwidth"].as<float>();
    }
    if (json.containsKey("enabled")) {
        pattern.enabled = json["enabled"].as<bool>();
    }
    
    trackingEngine.setAntennaPattern(pattern);
    sendOK(request, "Antenna pattern updated");
}

// =========================================================================
// Pre-Positioning Handler Implementation
// =========================================================================

void WebServer::handleSetPrePosition(AsyncWebServerRequest* request, JsonVariant& json) {
    bool enabled = json["enabled"] | true;
    uint32_t seconds = json["seconds"] | PRE_POSITION_SECONDS;
    
    trackingEngine.setPrePositioning(enabled, seconds);
    sendOK(request, "Pre-positioning settings updated");
}
