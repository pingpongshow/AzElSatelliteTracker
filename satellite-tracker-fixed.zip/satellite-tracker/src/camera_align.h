/**
 * @file camera_align.h
 * @brief Camera-based sun/moon alignment system with live streaming
 * 
 * Uses the OV2640 camera to detect the sun or moon position
 * and calculate calibration offsets for accurate pointing.
 * Also provides MJPEG streaming with optional overlay.
 * 
 * IMPORTANT: Use appropriate solar filter when aligning to sun!
 */

#ifndef CAMERA_ALIGN_H
#define CAMERA_ALIGN_H

#include <Arduino.h>
#include "esp_camera.h"
#include "config.h"

// Alignment result structure
struct AlignmentResult {
    bool success;           // Alignment succeeded
    float azOffset;         // Calculated azimuth offset (degrees)
    float elOffset;         // Calculated elevation offset (degrees)
    int blobX;              // Detected blob center X pixel
    int blobY;              // Detected blob center Y pixel
    int blobSize;           // Blob size in pixels
    float confidence;       // Detection confidence (0-1)
    String errorMessage;    // Error description if failed
};

// Blob detection result
struct BlobDetection {
    bool found;
    int centerX;
    int centerY;
    int pixelCount;
    int brightness;
};

// Overlay configuration
struct CameraOverlay {
    bool showCrosshairs;        // Show center crosshairs
    bool showBlobMarker;        // Show detected blob position
    bool showPositionText;      // Show Az/El text
    bool showGrid;              // Show alignment grid
    uint8_t crosshairColor[3]; // RGB color for crosshairs
    uint8_t blobColor[3];      // RGB color for blob marker
};

/**
 * @class CameraAlign
 * @brief Camera-based celestial body alignment with streaming
 */
class CameraAlign {
public:
    CameraAlign();
    
    /**
     * @brief Initialize camera
     * @return true if camera initialized successfully
     */
    bool begin();
    
    /**
     * @brief Perform sun alignment
     * @return Alignment result with offsets
     */
    AlignmentResult alignToSun();
    
    /**
     * @brief Perform moon alignment
     * @return Alignment result with offsets
     */
    AlignmentResult alignToMoon();
    
    /**
     * @brief Capture single frame for preview
     * @param buffer Output buffer for JPEG data
     * @param maxLen Maximum buffer size
     * @return Actual JPEG size, 0 if failed
     */
    size_t captureFrame(uint8_t* buffer, size_t maxLen);
    
    /**
     * @brief Capture frame with overlay (crosshairs, markers)
     * @param len Output data length
     * @param overlay Overlay configuration
     * @return Pointer to JPEG data (caller must free with free())
     */
    uint8_t* captureFrameWithOverlay(size_t& len, const CameraOverlay& overlay);
    
    /**
     * @brief Get last captured frame as JPEG
     * @param len Output parameter for data length
     * @return Pointer to JPEG data (valid until next capture)
     */
    const uint8_t* getLastFrame(size_t& len);
    
    /**
     * @brief Get frame for streaming (returns frame buffer directly)
     * @return Camera frame buffer (must call releaseFrame after use)
     */
    camera_fb_t* getStreamFrame();
    
    /**
     * @brief Release frame buffer after streaming
     * @param fb Frame buffer to release
     */
    void releaseFrame(camera_fb_t* fb);
    
    /**
     * @brief Check if camera is initialized
     */
    bool isInitialized() const { return _initialized; }
    
    /**
     * @brief Set brightness threshold for sun detection
     */
    void setSunThreshold(uint8_t threshold) { _sunThreshold = threshold; }
    
    /**
     * @brief Set brightness threshold for moon detection
     */
    void setMoonThreshold(uint8_t threshold) { _moonThreshold = threshold; }
    
    /**
     * @brief Set minimum blob size for valid detection
     */
    void setMinBlobSize(int pixels) { _minBlobSize = pixels; }
    
    /**
     * @brief Get camera horizontal field of view
     */
    float getFovH() const { return _fovH; }
    
    /**
     * @brief Get camera vertical field of view
     */
    float getFovV() const { return _fovV; }
    
    /**
     * @brief Set camera exposure (for sun alignment)
     * @param exposure Exposure value (0-1200)
     */
    void setExposure(int exposure);
    
    /**
     * @brief Set camera gain
     * @param gain Gain value (0-30)
     */
    void setGain(int gain);
    
    /**
     * @brief Reset camera to auto settings
     */
    void resetAutoExposure();
    
    /**
     * @brief Switch camera to grayscale mode for processing
     */
    void switchToGrayscale();
    
    /**
     * @brief Switch camera back to JPEG mode for streaming
     */
    void switchToJPEG();
    
    /**
     * @brief Set frame size
     * @param size Frame size (FRAMESIZE_VGA, FRAMESIZE_SVGA, etc.)
     */
    void setFrameSize(framesize_t size);
    
    /**
     * @brief Set JPEG quality
     * @param quality Quality (0-63, lower = better quality)
     */
    void setQuality(int quality);
    
    /**
     * @brief Get current frame width
     */
    int getFrameWidth() const { return _frameWidth; }
    
    /**
     * @brief Get current frame height
     */
    int getFrameHeight() const { return _frameHeight; }
    
    /**
     * @brief Get last detected blob info
     */
    BlobDetection getLastBlob() const { return _lastBlob; }
    
    /**
     * @brief Perform blob detection on current view
     * @param threshold Brightness threshold
     * @return Blob detection result
     */
    BlobDetection detectBlob(uint8_t threshold);

private:
    bool _initialized;
    camera_fb_t* _lastFrame;
    BlobDetection _lastBlob;
    
    // Detection thresholds
    uint8_t _sunThreshold;
    uint8_t _moonThreshold;
    int _minBlobSize;
    
    // Camera field of view (degrees)
    float _fovH;
    float _fovV;
    
    // Frame dimensions
    int _frameWidth;
    int _frameHeight;
    
    // Current pixel format
    pixformat_t _currentFormat;
    
    // Internal methods
    bool initCamera();
    BlobDetection detectBrightBlob(uint8_t* grayscale, int width, int height, 
                                    uint8_t threshold);
    AlignmentResult performAlignment(float targetAz, float targetEl, 
                                      uint8_t threshold, const char* bodyName);
    void convertToGrayscale(camera_fb_t* fb, uint8_t* output);
    void convertRGB565ToGrayscale(camera_fb_t* fb, uint8_t* output);
    float pixelToAngleH(int pixelOffset);
    float pixelToAngleV(int pixelOffset);
    
    // Overlay drawing (on RGB565 buffer)
    void drawCrosshairs(uint8_t* rgb565, int width, int height, uint16_t color);
    void drawBlobMarker(uint8_t* rgb565, int width, int height, int x, int y, uint16_t color);
    void drawGrid(uint8_t* rgb565, int width, int height, uint16_t color);
    void drawPixel(uint8_t* rgb565, int width, int x, int y, uint16_t color);
    void drawLine(uint8_t* rgb565, int width, int height, int x0, int y0, int x1, int y1, uint16_t color);
    void drawCircle(uint8_t* rgb565, int width, int height, int cx, int cy, int r, uint16_t color);
    uint16_t rgbToRgb565(uint8_t r, uint8_t g, uint8_t b);
};

// Global instance
extern CameraAlign cameraAlign;

#endif // CAMERA_ALIGN_H
