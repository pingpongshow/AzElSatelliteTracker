/**
 * @file main.cpp
 * @brief Main entry point for Az/El Satellite Tracker
 * 
 * ESP32-S3-CAM based satellite antenna tracker with:
 * - TMC2209 stepper drivers for azimuth and elevation
 * - GPS for location and time
 * - SGP4 orbit propagation for satellite tracking
 * - rotctld protocol for GPredict compatibility
 * - Web interface for configuration and manual control
 * - Camera-based sun/moon alignment
 * 
 * @author Your Name
 * @version 1.0.0
 * @date 2024
 * 
 * Hardware:
 * - ESP32-S3-CAM (with OV2640)
 * - TMC2209 stepper drivers (x2)
 * - NEMA 17 5.18:1 geared steppers (x2)
 * - GPS module (NMEA)
 */

#include <Arduino.h>
#include "config.h"
#include "wifi_manager.h"
#include "web_server.h"
#include "rotctld_server.h"
#include "gps.h"
#include "stepper_control.h"
#include "tracking_engine.h"
#include "tle_manager.h"
#include "camera_align.h"
#include "nvs_storage.h"
#include "health_monitor.h"
#include "sd_storage.h"
#include "udp_broadcast.h"
#include "camera_stream.h"
#include "external_api.h"

// Task handles for FreeRTOS
TaskHandle_t stepperTaskHandle = NULL;
TaskHandle_t networkTaskHandle = NULL;

// Timing variables
uint32_t lastStatusPrint = 0;
uint32_t lastPositionSave = 0;
uint32_t lastMainLoop = 0;

// Forward declarations
void stepperTask(void* parameter);
void networkTask(void* parameter);
void printStatus();
void loadSavedState();
void setupOTA();

/**
 * @brief Arduino setup function
 */
void setup() {
    // Initialize serial for debugging
    Serial.begin(DEBUG_BAUD);
    delay(1000);
    
    Serial.println();
    Serial.println("==========================================");
    Serial.println("  Az/El Satellite Tracker");
    Serial.printf("  Version: %s\n", FIRMWARE_VERSION);
    Serial.printf("  Model: %s %s\n", DEVICE_NAME, DEVICE_MODEL);
    Serial.println("==========================================");
    Serial.println();
    
    // Initialize NVS storage first
    Serial.println("[INIT] NVS Storage...");
    if (!nvsStorage.begin()) {
        Serial.println("[ERROR] NVS initialization failed!");
    }
    
    // Initialize GPS
    Serial.println("[INIT] GPS...");
    if (!gps.begin()) {
        Serial.println("[ERROR] GPS initialization failed!");
    }
    
    // Initialize stepper control
    Serial.println("[INIT] Stepper Control...");
    if (!stepperControl.begin()) {
        Serial.println("[ERROR] Stepper initialization failed!");
        Serial.println("[ERROR] Check TMC2209 UART connections!");
    }
    
    // Initialize tracking engine
    Serial.println("[INIT] Tracking Engine...");
    if (!trackingEngine.begin()) {
        Serial.println("[ERROR] Tracking engine initialization failed!");
    }
    
    // Initialize TLE manager
    Serial.println("[INIT] TLE Manager...");
    if (!tleManager.begin()) {
        Serial.println("[ERROR] TLE manager initialization failed!");
    }
    
    // Initialize camera
    Serial.println("[INIT] Camera...");
    if (!cameraAlign.begin()) {
        Serial.println("[WARN] Camera initialization failed - alignment disabled");
    }
    
    // Initialize health monitor
    Serial.println("[INIT] Health Monitor...");
    if (!healthMonitor.begin(true)) {  // Enable watchdog
        Serial.println("[WARN] Health monitor initialization failed");
    }
    
    // Initialize SD card storage (optional)
    Serial.println("[INIT] SD Card...");
    if (SD_CS_PIN >= 0) {
        if (!sdStorage.begin(SD_CS_PIN)) {
            Serial.println("[WARN] SD card not available - SD features disabled");
        }
    } else {
        Serial.println("[INFO] SD card not configured");
    }
    
    // Initialize WiFi
    Serial.println("[INIT] WiFi...");
    if (!wifiManager.begin()) {
        Serial.println("[ERROR] WiFi initialization failed!");
    }
    
    // Wait for WiFi connection or AP mode
    Serial.println("[INIT] Waiting for network...");
    uint32_t wifiTimeout = millis() + WIFI_CONNECT_TIMEOUT_MS;
    while (!wifiManager.isConnected() && !wifiManager.isAPMode() && millis() < wifiTimeout) {
        wifiManager.update();
        delay(100);
    }
    
    // Initialize web server
    Serial.println("[INIT] Web Server...");
    if (!webServer.begin()) {
        Serial.println("[ERROR] Web server initialization failed!");
    }
    
    // Initialize rotctld server
    Serial.println("[INIT] rotctld Server...");
    if (!rotctldServer.begin()) {
        Serial.println("[ERROR] rotctld server initialization failed!");
    }
    
    // Initialize UDP broadcast
    Serial.println("[INIT] UDP Broadcast...");
    if (!udpBroadcast.begin(UDP_BROADCAST_PORT, UDPFormat::JSON)) {
        Serial.println("[WARN] UDP broadcast initialization failed");
    }
    
    // Initialize camera stream server
    Serial.println("[INIT] Camera Stream Server...");
    if (cameraAlign.isInitialized()) {
        if (!cameraStream.begin(CAMERA_STREAM_PORT)) {
            Serial.println("[WARN] Camera stream server initialization failed");
        }
    }
    
    // Load saved state
    loadSavedState();
    
    // Create stepper control task on Core 1 (high priority)
    xTaskCreatePinnedToCore(
        stepperTask,
        "StepperTask",
        TASK_STACK_STEPPER,
        NULL,
        TASK_PRIORITY_STEPPER,
        &stepperTaskHandle,
        1  // Core 1
    );
    
    // Create network task on Core 0
    xTaskCreatePinnedToCore(
        networkTask,
        "NetworkTask",
        TASK_STACK_NETWORK,
        NULL,
        TASK_PRIORITY_NETWORK,
        &networkTaskHandle,
        0  // Core 0
    );
    
    Serial.println();
    Serial.println("==========================================");
    Serial.println("  Initialization Complete!");
    Serial.println("==========================================");
    Serial.printf("  IP Address: %s\n", wifiManager.getIP().toString().c_str());
    Serial.printf("  Hostname: %s.local\n", MDNS_HOSTNAME);
    Serial.printf("  Web UI: http://%s/\n", wifiManager.getIP().toString().c_str());
    Serial.printf("  rotctld: %s:%d\n", wifiManager.getIP().toString().c_str(), ROTCTLD_PORT);
    if (cameraAlign.isInitialized()) {
        Serial.printf("  Camera Stream: http://%s:%d/stream\n", 
                     wifiManager.getIP().toString().c_str(), CAMERA_STREAM_PORT);
    }
    Serial.printf("  UDP Broadcast: Port %d\n", UDP_BROADCAST_PORT);
    if (sdStorage.isAvailable()) {
        uint32_t totalMB, usedMB;
        sdStorage.getCardInfo(totalMB, usedMB);
        Serial.printf("  SD Card: %lu MB total, %lu MB used\n", totalMB, usedMB);
    }
    Serial.println("==========================================");
    Serial.println();
}

/**
 * @brief Arduino main loop
 */
void loop() {
    uint32_t now = millis();
    
    // Update GPS
    gps.update();
    
    // Update tracking engine
    trackingEngine.update();
    
    // Update health monitor
    healthMonitor.update();
    
    // Update UDP broadcast
    udpBroadcast.update();
    
    // Periodic position save
    if (now - lastPositionSave >= POSITION_SAVE_INTERVAL_MS) {
        nvsStorage.savePosition(
            stepperControl.getAzimuth(),
            stepperControl.getElevation()
        );
        lastPositionSave = now;
    }
    
    // Periodic status print
    if (now - lastStatusPrint >= 5000) {
        printStatus();
        lastStatusPrint = now;
    }
    
    // Maintain loop timing
    uint32_t elapsed = millis() - now;
    if (elapsed < MAIN_LOOP_INTERVAL_MS) {
        delay(MAIN_LOOP_INTERVAL_MS - elapsed);
    }
}

/**
 * @brief Stepper control task (runs on Core 1)
 * 
 * High-priority task for smooth motor control
 */
void stepperTask(void* parameter) {
    TickType_t lastWakeTime = xTaskGetTickCount();
    const TickType_t interval = pdMS_TO_TICKS(1);  // 1ms update rate
    
    for (;;) {
        stepperControl.update();
        vTaskDelayUntil(&lastWakeTime, interval);
    }
}

/**
 * @brief Network task (runs on Core 0)
 * 
 * Handles WiFi, web server, and rotctld
 */
void networkTask(void* parameter) {
    TickType_t lastWakeTime = xTaskGetTickCount();
    const TickType_t interval = pdMS_TO_TICKS(10);  // 10ms update rate
    
    for (;;) {
        wifiManager.update();
        webServer.update();
        rotctldServer.update();
        vTaskDelayUntil(&lastWakeTime, interval);
    }
}

/**
 * @brief Print current system status to serial
 */
void printStatus() {
    Serial.println("--- Status ---");
    
    // Position
    Serial.printf("Position: Az=%.2f° El=%.2f° %s\n",
                  stepperControl.getAzimuth(),
                  stepperControl.getElevation(),
                  stepperControl.isMoving() ? "[MOVING]" : "[IDLE]");
    
    // GPS
    if (gps.hasFix()) {
        Serial.printf("GPS: %.6f, %.6f, %.1fm (%d sats)\n",
                      gps.getLatitude(),
                      gps.getLongitude(),
                      gps.getAltitude(),
                      gps.getSatellites());
    } else {
        Serial.println("GPS: No fix");
    }
    
    // Tracking
    if (trackingEngine.hasTLE()) {
        Serial.printf("Tracking: %s ", trackingEngine.getSatelliteName().c_str());
        if (trackingEngine.isSatelliteVisible()) {
            SatellitePosition pos = trackingEngine.getPosition();
            Serial.printf("[VISIBLE Az=%.1f° El=%.1f°]\n", pos.azimuth, pos.elevation);
        } else {
            Serial.println("[Below horizon]");
        }
    }
    
    // Network
    Serial.printf("WiFi: %s | rotctld clients: %d\n",
                  wifiManager.getStatusString().c_str(),
                  rotctldServer.getClientCount());
    
    // Memory
    Serial.printf("Free heap: %d bytes | PSRAM: %d bytes\n",
                  ESP.getFreeHeap(),
                  ESP.getFreePsram());
    
    Serial.println();
}

/**
 * @brief Load saved state from NVS
 */
void loadSavedState() {
    TrackerConfig config;
    
    if (nvsStorage.loadConfig(config)) {
        // Restore calibration
        stepperControl.setCalibrationOffset(config.azimuthOffset, config.elevationOffset);
        
        // Restore position if valid
        if (config.positionValid) {
            Serial.printf("[RESTORE] Position: Az=%.2f° El=%.2f°\n",
                          config.lastAzimuth, config.lastElevation);
            stepperControl.setPosition(config.lastAzimuth, config.lastElevation);
        } else {
            Serial.println("[RESTORE] No saved position - homing required");
        }
        
        // Restore observer location if manual
        if (config.useManualLocation) {
            gps.setManualPosition(config.latitude, config.longitude, config.altitude);
            gps.setUseManualPosition(true);
            trackingEngine.setObserverLocation(config.latitude, config.longitude, 
                                                config.altitude);
        }
        
        // Restore motor settings
        stepperControl.setMotorCurrent(config.motorRunCurrent, config.motorHoldCurrent);
        
        Serial.println("[RESTORE] Configuration loaded from NVS");
    }
}

/**
 * @brief Setup Over-The-Air updates
 */
void setupOTA() {
    // OTA setup can be added here if needed
    // Using ArduinoOTA library
}
