/**
 * @file external_api.cpp
 * @brief External API integrations implementation
 */

#include "external_api.h"
#include <WiFi.h>

// Global instance
ExternalAPI externalAPI;

// Known TLE groups on Celestrak
static const char* TLE_GROUPS[] = {
    "amateur", "stations", "weather", "noaa", "goes", 
    "resource", "sarsat", "dmc", "tdrss", "argos",
    "geo", "intelsat", "ses", "iridium", "iridium-NEXT",
    "starlink", "oneweb", "globalstar", "orbcomm",
    "gps-ops", "glonass", "galileo", "beidou",
    "sbas", "nnss", "musson", "science", "geodetic",
    "engineering", "education", "military", "radar",
    "cubesat", "other-comm", "satnogs", "spire"
};
static const int NUM_TLE_GROUPS = sizeof(TLE_GROUPS) / sizeof(TLE_GROUPS[0]);

ExternalAPI::ExternalAPI() {
}

void ExternalAPI::setN2YOApiKey(const char* apiKey) {
    _n2yoApiKey = apiKey;
    DEBUG_PRINTLN("ExternalAPI: N2YO API key set");
}

bool ExternalAPI::httpGet(const char* url, String& response) {
    if (WiFi.status() != WL_CONNECTED) {
        _lastError = "No network connection";
        return false;
    }
    
    _http.setTimeout(N2YO_API_TIMEOUT_MS);
    
    if (!_http.begin(url)) {
        _lastError = "HTTP begin failed";
        return false;
    }
    
    int httpCode = _http.GET();
    
    if (httpCode != HTTP_CODE_OK) {
        _lastError = "HTTP error: " + String(httpCode);
        _http.end();
        return false;
    }
    
    response = _http.getString();
    _http.end();
    
    return true;
}

String ExternalAPI::urlEncode(const char* str) {
    String encoded = "";
    for (int i = 0; str[i]; i++) {
        char c = str[i];
        if (isalnum(c) || c == '-' || c == '_' || c == '.') {
            encoded += c;
        } else if (c == ' ') {
            encoded += "%20";
        } else {
            char hex[4];
            snprintf(hex, sizeof(hex), "%%%02X", (unsigned char)c);
            encoded += hex;
        }
    }
    return encoded;
}

// N2YO Implementation

bool ExternalAPI::fetchTLEFromN2YO(uint32_t noradId, TLEEntry& entry) {
    if (!hasN2YOApiKey()) {
        _lastError = "N2YO API key not set";
        return false;
    }
    
    char url[256];
    snprintf(url, sizeof(url), 
             "%s/tle/%lu&apiKey=%s",
             N2YO_API_URL, noradId, _n2yoApiKey.c_str());
    
    String response;
    if (!httpGet(url, response)) {
        return false;
    }
    
    JsonDocument doc;
    DeserializationError error = deserializeJson(doc, response);
    if (error) {
        _lastError = "JSON parse error";
        return false;
    }
    
    if (doc.containsKey("error")) {
        _lastError = doc["error"].as<String>();
        return false;
    }
    
    const char* name = doc["info"]["satname"] | "";
    const char* tle = doc["tle"] | "";
    
    strncpy(entry.name, name, sizeof(entry.name) - 1);
    
    // Parse TLE lines from combined string
    String tleStr = String(tle);
    int nlPos = tleStr.indexOf('\n');
    if (nlPos < 0) nlPos = tleStr.indexOf('\r');
    
    if (nlPos > 0) {
        strncpy(entry.line1, tleStr.substring(0, nlPos).c_str(), sizeof(entry.line1) - 1);
        strncpy(entry.line2, tleStr.substring(nlPos + 1).c_str(), sizeof(entry.line2) - 1);
    }
    
    entry.fetchTime = millis() / 1000;
    entry.valid = true;
    
    return true;
}

int ExternalAPI::getVisualPasses(uint32_t noradId, float lat, float lon, float alt,
                                  int days, int minVisibility,
                                  VisualPass* passes, int maxPasses) {
    if (!hasN2YOApiKey()) {
        _lastError = "N2YO API key not set";
        return 0;
    }
    
    char url[512];
    snprintf(url, sizeof(url),
             "%s/visualpasses/%lu/%.4f/%.4f/%.0f/%d/%d&apiKey=%s",
             N2YO_API_URL, noradId, lat, lon, alt, days, minVisibility, 
             _n2yoApiKey.c_str());
    
    String response;
    if (!httpGet(url, response)) {
        return 0;
    }
    
    JsonDocument doc;
    if (deserializeJson(doc, response)) {
        _lastError = "JSON parse error";
        return 0;
    }
    
    JsonArray passArray = doc["passes"].as<JsonArray>();
    int count = 0;
    
    for (JsonObject p : passArray) {
        if (count >= maxPasses) break;
        
        passes[count].startTime = p["startUTC"] | 0;
        passes[count].maxTime = p["maxUTC"] | 0;
        passes[count].endTime = p["endUTC"] | 0;
        passes[count].startAz = p["startAz"] | 0;
        passes[count].startEl = p["startEl"] | 0;
        passes[count].maxAz = p["maxAz"] | 0;
        passes[count].maxEl = p["maxEl"] | 0;
        passes[count].endAz = p["endAz"] | 0;
        passes[count].endEl = p["endEl"] | 0;
        passes[count].magnitude = p["mag"] | 99;
        passes[count].duration = p["duration"] | 0;
        
        count++;
    }
    
    return count;
}

int ExternalAPI::getRadioPasses(uint32_t noradId, float lat, float lon, float alt,
                                 int days, float minEl,
                                 PassInfo* passes, int maxPasses) {
    if (!hasN2YOApiKey()) {
        _lastError = "N2YO API key not set";
        return 0;
    }
    
    char url[512];
    snprintf(url, sizeof(url),
             "%s/radiopasses/%lu/%.4f/%.4f/%.0f/%d/%.0f&apiKey=%s",
             N2YO_API_URL, noradId, lat, lon, alt, days, minEl,
             _n2yoApiKey.c_str());
    
    String response;
    if (!httpGet(url, response)) {
        return 0;
    }
    
    JsonDocument doc;
    if (deserializeJson(doc, response)) {
        _lastError = "JSON parse error";
        return 0;
    }
    
    JsonArray passArray = doc["passes"].as<JsonArray>();
    int count = 0;
    
    for (JsonObject p : passArray) {
        if (count >= maxPasses) break;
        
        passes[count].aosTime = p["startUTC"] | 0;
        passes[count].maxElTime = p["maxUTC"] | 0;
        passes[count].losTime = p["endUTC"] | 0;
        passes[count].aosAz = p["startAz"] | 0;
        passes[count].maxElAz = p["maxAz"] | 0;
        passes[count].losAz = p["endAz"] | 0;
        passes[count].maxEl = p["maxEl"] | 0;
        
        count++;
    }
    
    return count;
}

int ExternalAPI::searchSatellites(const char* name, uint32_t* results, int maxResults) {
    // Use Celestrak GP search endpoint
    char url[256];
    snprintf(url, sizeof(url), "%s?NAME=%s&FORMAT=JSON", 
             CELESTRAK_API_URL, urlEncode(name).c_str());
    
    String response;
    if (!httpGet(url, response)) {
        return 0;
    }
    
    JsonDocument doc;
    if (deserializeJson(doc, response)) {
        _lastError = "JSON parse error";
        return 0;
    }
    
    // Celestrak returns array of objects with NORAD_CAT_ID
    JsonArray satArray = doc.as<JsonArray>();
    int count = 0;
    
    for (JsonObject sat : satArray) {
        if (count >= maxResults) break;
        results[count++] = sat["NORAD_CAT_ID"] | 0;
    }
    
    return count;
}

// SatNOGS Implementation

bool ExternalAPI::getSatelliteInfo(uint32_t noradId, SatNOGSSatellite& info) {
    char url[256];
    snprintf(url, sizeof(url), "%s/satellites/%lu/", SATNOGS_API_URL, noradId);
    
    String response;
    if (!httpGet(url, response)) {
        return false;
    }
    
    JsonDocument doc;
    if (deserializeJson(doc, response)) {
        _lastError = "JSON parse error";
        return false;
    }
    
    info.noradId = doc["norad_cat_id"] | noradId;
    strncpy(info.name, doc["name"] | "", sizeof(info.name) - 1);
    strncpy(info.altName, doc["names"] | "", sizeof(info.altName) - 1);
    strncpy(info.status, doc["status"] | "unknown", sizeof(info.status) - 1);
    
    // Check for transmitters
    info.hasTransmitter = false;
    info.downlinkMHz = 0;
    info.uplinkMHz = 0;
    
    return true;
}

int ExternalAPI::getTransmitters(uint32_t noradId, SatNOGSTransmitter* transmitters, int maxTx) {
    char url[256];
    snprintf(url, sizeof(url), "%s/transmitters/?satellite__norad_cat_id=%lu", 
             SATNOGS_API_URL, noradId);
    
    String response;
    if (!httpGet(url, response)) {
        return 0;
    }
    
    JsonDocument doc;
    if (deserializeJson(doc, response)) {
        _lastError = "JSON parse error";
        return 0;
    }
    
    JsonArray txArray = doc.as<JsonArray>();
    int count = 0;
    
    for (JsonObject tx : txArray) {
        if (count >= maxTx) break;
        
        transmitters[count].noradId = noradId;
        strncpy(transmitters[count].description, tx["description"] | "", 
                sizeof(transmitters[count].description) - 1);
        transmitters[count].downlinkLow = (tx["downlink_low"] | 0) / 1e6;
        transmitters[count].downlinkHigh = (tx["downlink_high"] | 0) / 1e6;
        transmitters[count].uplinkLow = (tx["uplink_low"] | 0) / 1e6;
        transmitters[count].uplinkHigh = (tx["uplink_high"] | 0) / 1e6;
        strncpy(transmitters[count].mode, tx["mode"] | "", sizeof(transmitters[count].mode) - 1);
        transmitters[count].alive = tx["alive"] | false;
        transmitters[count].baud = tx["baud"] | 0;
        
        count++;
    }
    
    return count;
}

int ExternalAPI::searchSatNOGS(const char* query, SatNOGSSatellite* results, int maxResults) {
    char url[256];
    snprintf(url, sizeof(url), "%s/satellites/?search=%s", 
             SATNOGS_API_URL, urlEncode(query).c_str());
    
    String response;
    if (!httpGet(url, response)) {
        return 0;
    }
    
    JsonDocument doc;
    if (deserializeJson(doc, response)) {
        _lastError = "JSON parse error";
        return 0;
    }
    
    JsonArray satArray = doc.as<JsonArray>();
    int count = 0;
    
    for (JsonObject sat : satArray) {
        if (count >= maxResults) break;
        
        results[count].noradId = sat["norad_cat_id"] | 0;
        strncpy(results[count].name, sat["name"] | "", sizeof(results[count].name) - 1);
        strncpy(results[count].status, sat["status"] | "", sizeof(results[count].status) - 1);
        
        count++;
    }
    
    return count;
}

// Celestrak Implementation

bool ExternalAPI::fetchTLEFromCelestrak(uint32_t noradId, TLEEntry& entry) {
    char url[256];
    snprintf(url, sizeof(url), "%s?CATNR=%lu&FORMAT=TLE", CELESTRAK_API_URL, noradId);
    
    String response;
    if (!httpGet(url, response)) {
        return false;
    }
    
    // Parse 3-line TLE format
    int lineCount = 0;
    int pos = 0;
    String lines[3];
    
    while (pos < response.length() && lineCount < 3) {
        int nlPos = response.indexOf('\n', pos);
        if (nlPos < 0) nlPos = response.length();
        
        String line = response.substring(pos, nlPos);
        line.trim();
        
        if (line.length() > 0) {
            lines[lineCount++] = line;
        }
        
        pos = nlPos + 1;
    }
    
    if (lineCount < 3) {
        _lastError = "Invalid TLE response";
        return false;
    }
    
    strncpy(entry.name, lines[0].c_str(), sizeof(entry.name) - 1);
    strncpy(entry.line1, lines[1].c_str(), sizeof(entry.line1) - 1);
    strncpy(entry.line2, lines[2].c_str(), sizeof(entry.line2) - 1);
    entry.fetchTime = millis() / 1000;
    entry.valid = true;
    
    return true;
}

bool ExternalAPI::fetchTLEByName(const char* name, TLEEntry& entry) {
    char url[256];
    snprintf(url, sizeof(url), "%s?NAME=%s&FORMAT=TLE", 
             CELESTRAK_API_URL, urlEncode(name).c_str());
    
    String response;
    if (!httpGet(url, response)) {
        return false;
    }
    
    // Parse response same as by ID
    int lineCount = 0;
    int pos = 0;
    String lines[3];
    
    while (pos < response.length() && lineCount < 3) {
        int nlPos = response.indexOf('\n', pos);
        if (nlPos < 0) nlPos = response.length();
        
        String line = response.substring(pos, nlPos);
        line.trim();
        
        if (line.length() > 0) {
            lines[lineCount++] = line;
        }
        
        pos = nlPos + 1;
    }
    
    if (lineCount < 3) {
        _lastError = "Satellite not found";
        return false;
    }
    
    strncpy(entry.name, lines[0].c_str(), sizeof(entry.name) - 1);
    strncpy(entry.line1, lines[1].c_str(), sizeof(entry.line1) - 1);
    strncpy(entry.line2, lines[2].c_str(), sizeof(entry.line2) - 1);
    entry.fetchTime = millis() / 1000;
    entry.valid = true;
    
    return true;
}

int ExternalAPI::fetchTLEGroup(const char* group, void (*callback)(const TLEEntry&)) {
    char url[256];
    snprintf(url, sizeof(url), "%s?GROUP=%s&FORMAT=TLE", CELESTRAK_API_URL, group);
    
    String response;
    if (!httpGet(url, response)) {
        return 0;
    }
    
    int count = 0;
    int pos = 0;
    
    while (pos < response.length()) {
        TLEEntry entry;
        String lines[3];
        int lineCount = 0;
        
        // Read 3 lines
        while (pos < response.length() && lineCount < 3) {
            int nlPos = response.indexOf('\n', pos);
            if (nlPos < 0) nlPos = response.length();
            
            String line = response.substring(pos, nlPos);
            line.trim();
            
            if (line.length() > 0) {
                lines[lineCount++] = line;
            }
            
            pos = nlPos + 1;
        }
        
        if (lineCount < 3) break;
        
        // Validate and store
        if (lines[1][0] == '1' && lines[2][0] == '2') {
            strncpy(entry.name, lines[0].c_str(), sizeof(entry.name) - 1);
            strncpy(entry.line1, lines[1].c_str(), sizeof(entry.line1) - 1);
            strncpy(entry.line2, lines[2].c_str(), sizeof(entry.line2) - 1);
            entry.fetchTime = millis() / 1000;
            entry.valid = true;
            
            if (callback) {
                callback(entry);
            }
            
            count++;
        }
    }
    
    return count;
}

int ExternalAPI::getTLEGroups(String* groups, int maxGroups) {
    int count = min(maxGroups, NUM_TLE_GROUPS);
    for (int i = 0; i < count; i++) {
        groups[i] = TLE_GROUPS[i];
    }
    return count;
}
