# Satellite Tracker API Documentation

## Overview

The satellite tracker provides a REST API for programmatic control and monitoring.
All endpoints are relative to the tracker's IP address (e.g., `http://192.168.1.100/api/`).

## Authentication

No authentication is required. The tracker is designed for use on trusted local networks.

## Response Format

All responses are JSON. Successful responses include appropriate data.
Error responses include an `error` field:

```json
{
  "error": "Error description"
}
```

## Endpoints

### Status

#### GET /api/status

Returns full system status.

**Response:**
```json
{
  "azimuth": 180.5,
  "elevation": 45.2,
  "targetAz": 185.0,
  "targetEl": 50.0,
  "moving": true,
  "enabled": true,
  "mode": 2,
  "satellite": "ISS (ZARYA)",
  "satVisible": true,
  "satAz": 185.3,
  "satEl": 48.7,
  "satRange": 423.5,
  "gpsValid": true,
  "gpsSats": 8,
  "wifiConnected": true,
  "rotctldClients": 1
}
```

**Mode Values:**
| Value | Description |
|-------|-------------|
| 0 | Idle |
| 1 | Manual |
| 2 | Auto Tracking |
| 3 | External (rotctld) |

---

#### GET /api/position

Returns current antenna position.

**Response:**
```json
{
  "azimuth": 180.5,
  "elevation": 45.2,
  "targetAz": 185.0,
  "targetEl": 50.0,
  "moving": false
}
```

---

#### GET /api/gps

Returns GPS status and position.

**Response:**
```json
{
  "valid": true,
  "latitude": 40.712800,
  "longitude": -74.006000,
  "altitude": 10.5,
  "satellites": 8,
  "hdop": 1.2,
  "time": 1700000000,
  "manual": false
}
```

---

#### GET /api/config

Returns system configuration.

**Response:**
```json
{
  "version": "1.0.0",
  "model": "AzEl-S3",
  "azMin": -180,
  "azMax": 540,
  "elMin": 0,
  "elMax": 90,
  "parkAz": 0,
  "parkEl": 45,
  "azOffset": 0.5,
  "elOffset": -0.2
}
```

---

### Control

#### POST /api/position

Move antenna to specified position.

**Request:**
```json
{
  "azimuth": 180.0,
  "elevation": 45.0,
  "speed": 10.0
}
```

- `speed` is optional (degrees/second), defaults to tracking speed

**Response:**
```json
{
  "status": "ok",
  "message": "Position set"
}
```

---

#### POST /api/stop

Stop all motion immediately.

**Response:**
```json
{
  "status": "ok",
  "message": "Stopped"
}
```

---

#### POST /api/park

Move antenna to park position.

**Response:**
```json
{
  "status": "ok",
  "message": "Parking"
}
```

---

#### POST /api/home

Run sensorless homing sequence.

**Response:**
```json
{
  "status": "ok",
  "message": "Homing complete"
}
```

---

#### POST /api/sethome

Set current position as home (0°, 0°).

**Response:**
```json
{
  "status": "ok",
  "message": "Home position set"
}
```

---

### Tracking

#### POST /api/track

Start satellite tracking.

**Request (with stored TLE):**
```json
{
  "name": "ISS (ZARYA)"
}
```

**Request (with provided TLE):**
```json
{
  "name": "ISS (ZARYA)",
  "line1": "1 25544U 98067A   24001.50000000 ...",
  "line2": "2 25544  51.6400 ..."
}
```

**Response:**
```json
{
  "status": "ok",
  "message": "Tracking started"
}
```

---

#### DELETE /api/track

Stop satellite tracking.

**Response:**
```json
{
  "status": "ok",
  "message": "Tracking stopped"
}
```

---

#### GET /api/nextpass

Get next pass prediction for current satellite.

**Response:**
```json
{
  "aosTime": 1700001000,
  "losTime": 1700001600,
  "maxElTime": 1700001300,
  "aosAz": 315.2,
  "losAz": 45.8,
  "maxEl": 62.5,
  "maxElAz": 180.0,
  "duration": 600
}
```

---

### TLE Management

#### GET /api/tle

List stored TLEs.

**Response:**
```json
{
  "tles": [
    { "name": "ISS (ZARYA)", "stale": false },
    { "name": "SO-50", "stale": true }
  ],
  "count": 2
}
```

---

#### POST /api/tle

Add or update TLE.

**Request:**
```json
{
  "name": "ISS (ZARYA)",
  "line1": "1 25544U 98067A   24001.50000000 ...",
  "line2": "2 25544  51.6400 ..."
}
```

**Response:**
```json
{
  "status": "ok",
  "message": "TLE saved"
}
```

---

#### POST /api/tle/fetch

Fetch TLE from Celestrak.

**Request (by name):**
```json
{
  "name": "ISS"
}
```

**Request (by NORAD ID):**
```json
{
  "noradId": 25544
}
```

**Response:**
```json
{
  "name": "ISS (ZARYA)",
  "line1": "1 25544U 98067A   24001.50000000 ...",
  "line2": "2 25544  51.6400 ..."
}
```

---

### Calibration

#### POST /api/calibrate

Perform calibration.

**Request (sun alignment):**
```json
{
  "method": "sun"
}
```

**Request (moon alignment):**
```json
{
  "method": "moon"
}
```

**Request (manual offset):**
```json
{
  "method": "manual",
  "azOffset": 1.5,
  "elOffset": -0.5
}
```

**Response:**
```json
{
  "status": "ok",
  "message": "Sun alignment complete"
}
```

---

### WiFi

#### GET /api/wifi/status

Get WiFi connection status.

**Response:**
```json
{
  "mode": 2,
  "connected": true,
  "ssid": "MyNetwork",
  "ip": "192.168.1.100",
  "rssi": -45,
  "hostname": "satellite-tracker",
  "mdns": true
}
```

**Mode Values:**
| Value | Description |
|-------|-------------|
| 0 | Disconnected |
| 1 | Connecting |
| 2 | Connected |
| 3 | AP Mode |

---

#### GET /api/wifi/networks

Scan for available networks.

**Response:**
```json
{
  "networks": [
    { "ssid": "MyNetwork", "rssi": -45, "open": false },
    { "ssid": "GuestNet", "rssi": -70, "open": true }
  ],
  "count": 2
}
```

---

#### POST /api/wifi/connect

Connect to a WiFi network.

**Request:**
```json
{
  "ssid": "MyNetwork",
  "password": "mypassword"
}
```

**Response:**
```json
{
  "status": "ok",
  "message": "Connecting..."
}
```

---

### System

#### GET /api/system/info

Get system information.

**Response:**
```json
{
  "version": "1.0.0",
  "model": "AzEl-S3",
  "freeHeap": 180000,
  "heapSize": 320000,
  "freePsram": 4000000,
  "uptime": 3600,
  "cpuFreq": 240,
  "flashSize": 16777216,
  "sdkVersion": "v4.4.4"
}
```

---

#### POST /api/system/reboot

Reboot the device.

**Response:**
```json
{
  "status": "ok",
  "message": "Rebooting..."
}
```

---

## WebSocket

Real-time status updates are available via WebSocket at `ws://[host]/ws`

### Connection

```javascript
const ws = new WebSocket('ws://192.168.1.100/ws');
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log(data);
};
```

### Status Messages

Status updates are sent every 500ms:

```json
{
  "type": "status",
  "az": 180.5,
  "el": 45.2,
  "targetAz": 185.0,
  "targetEl": 50.0,
  "moving": true,
  "mode": 2,
  "sat": "ISS (ZARYA)",
  "visible": true,
  "satAz": 185.3,
  "satEl": 48.7,
  "gps": true,
  "time": 1700000000
}
```

### Event Messages

Events are sent for significant state changes:

```json
{
  "event": "tracking_started",
  "data": "ISS (ZARYA)"
}
```

```json
{
  "event": "error",
  "data": "GPS fix lost"
}
```

---

## rotctld Protocol

The tracker implements the Hamlib rotctld protocol on TCP port 4533.

### Commands

| Command | Description | Response |
|---------|-------------|----------|
| `p` | Get position | `180.5\n45.2\n` |
| `P 180 45` | Set position | `RPRT 0\n` |
| `S` | Stop | `RPRT 0\n` |
| `K` | Park | `RPRT 0\n` |
| `q` | Quit | (disconnects) |
| `_` | Get info | Info string |

### Extended Commands

| Command | Description |
|---------|-------------|
| `\get_pos` | Get position |
| `\set_pos 180 45` | Set position |
| `\stop` | Stop motion |
| `\park` | Move to park |
| `\get_info` | Get rotator info |
| `\dump_caps` | Get capabilities |

### Example Session

```
$ nc 192.168.1.100 4533
p
180.500000
45.200000
P 200 60
RPRT 0
S
RPRT 0
q
```

---

## Error Codes

| HTTP Code | Meaning |
|-----------|---------|
| 200 | Success |
| 400 | Bad Request (invalid parameters) |
| 404 | Not Found (endpoint or resource) |
| 500 | Internal Server Error |

---

## Rate Limits

The API has no explicit rate limits. However, for optimal performance:

- Position commands: Max 10/second
- TLE fetch: Max 1/minute
- Network scan: Max 1/10 seconds

---

## Examples

### Python - Move Antenna

```python
import requests

tracker = "http://192.168.1.100"

# Move to position
requests.post(f"{tracker}/api/position", json={
    "azimuth": 180,
    "elevation": 45
})

# Get status
status = requests.get(f"{tracker}/api/status").json()
print(f"Position: Az={status['azimuth']}, El={status['elevation']}")
```

### Bash - Track Satellite

```bash
TRACKER="http://192.168.1.100"

# Fetch TLE
curl -X POST "$TRACKER/api/tle/fetch" \
  -H "Content-Type: application/json" \
  -d '{"name": "ISS"}'

# Start tracking
curl -X POST "$TRACKER/api/track" \
  -H "Content-Type: application/json" \
  -d '{"name": "ISS (ZARYA)"}'

# Stop tracking
curl -X DELETE "$TRACKER/api/track"
```
