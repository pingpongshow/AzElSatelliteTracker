# Hardware Setup Guide

## Bill of Materials

### Electronics

| Qty | Component | Specification | Notes |
|-----|-----------|---------------|-------|
| 1 | ESP32-S3-CAM | With OV2640 camera | Freenove or similar |
| 2 | TMC2209 | Stepper driver module | UART mode |
| 2 | NEMA 17 Geared Stepper | 5.18:1 planetary gearbox | 17HS15-1684S-PG5 or similar |
| 1 | GPS Module | NMEA output, 9600 baud | NEO-6M, BN-220, etc. |
| 1 | Power Supply | 12V 3A minimum | For motors |
| 1 | Buck Converter | 12V to 5V 2A | For ESP32 |
| 1 | Logic Level Shifter | 3.3V ↔ 5V | If GPS is 5V |
| - | Connectors | JST-XH, Dupont, etc. | As needed |

### Mechanical

| Qty | Component | Notes |
|-----|-----------|-------|
| 1 | Az/El Mount | 3D printed or commercial |
| 2 | Motor Mounting Brackets | Match motor NEMA size |
| 2 | Shaft Couplers | Motor to mount |
| 1 | Antenna Boom Mount | Application specific |
| - | Hardware | M3/M4 screws, nuts, standoffs |

---

## TMC2209 Configuration

### UART Addressing

The TMC2209 supports addressing multiple drivers on a single UART bus using the MS1/MS2 pins:

| Driver | MS1 | MS2 | Address |
|--------|-----|-----|---------|
| Azimuth | GND | GND | 0b00 |
| Elevation | 3.3V | GND | 0b01 |

### Wiring Diagram

```
                          TMC2209 Module (Azimuth)
                    ┌─────────────────────────────────┐
                    │  EN   MS1  MS2  RX   TX  CLK   │
                    │   │    │    │    │    │    │   │
      GPIO1 ────────┤───┘    │    │    │    │    │   │
      GND ──────────┤────────┴────┴────│────│────│   │
      GPIO43 ───────┤──────────────────┘    │    │   │
      GPIO44 ───────┤───────────────────────┘    │   │
      NC ───────────┤────────────────────────────┘   │
                    │                                 │
                    │  STEP  DIR  DIAG VREF  VM  GND │
                    │   │     │    │    │    │    │  │
      GPIO38 ───────┤───┘     │    │    │    │    │  │
      GPIO39 ───────┤─────────┘    │    │    │    │  │
      GPIO40 ───────┤──────────────┘    │    │    │  │
      POT ──────────┤───────────────────┘    │    │  │
      12V ──────────┤────────────────────────┘    │  │
      GND ──────────┤─────────────────────────────┘  │
                    │                                 │
                    │  A1   A2   B1   B2             │
                    │   │    │    │    │             │
                    │  Motor Coil A  Motor Coil B   │
                    └─────────────────────────────────┘


                          TMC2209 Module (Elevation)
                    ┌─────────────────────────────────┐
                    │  EN   MS1  MS2  RX   TX  CLK   │
                    │   │    │    │    │    │    │   │
      GPIO1 ────────┤───┘    │    │    │    │    │   │
      3.3V ─────────┤────────┘    │    │    │    │   │
      GND ──────────┤─────────────┴────│────│────│   │
      GPIO43 ───────┤──────────────────┘    │    │   │
      GPIO44 ───────┤───────────────────────┘    │   │
      NC ───────────┤────────────────────────────┘   │
                    │                                 │
                    │  STEP  DIR  DIAG VREF  VM  GND │
                    │   │     │    │    │    │    │  │
      GPIO41 ───────┤───┘     │    │    │    │    │  │
      GPIO42 ───────┤─────────┘    │    │    │    │  │
      GPIO2 ────────┤──────────────┘    │    │    │  │
      POT ──────────┤───────────────────┘    │    │  │
      12V ──────────┤────────────────────────┘    │  │
      GND ──────────┤─────────────────────────────┘  │
                    │                                 │
                    │  A1   A2   B1   B2             │
                    │   │    │    │    │             │
                    │  Motor Coil A  Motor Coil B   │
                    └─────────────────────────────────┘
```

### UART Connection

Both TMC2209 modules share the same UART bus:

```
ESP32-S3               TMC2209 (Az)        TMC2209 (El)
┌────────┐            ┌───────────┐       ┌───────────┐
│ GPIO43 ├────────────┤ RX        │───────┤ RX        │
│ (TX)   │            │           │       │           │
│        │            │           │       │           │
│ GPIO44 ├────────────┤ TX        │───────┤ TX        │
│ (RX)   │            │           │       │           │
└────────┘            └───────────┘       └───────────┘
```

Note: Add a 1kΩ resistor in series with the TX line if experiencing communication issues.

---

## GPS Module Connection

### Standard GPS Module (3.3V)

```
GPS Module              ESP32-S3
┌──────────────┐       ┌─────────┐
│ TX      VCC  ├───────┤ 3.3V    │
│              │       │         │
│ RX      GND  ├───────┤ GND     │
│              │       │         │
│ PPS (opt)    │       │ GPIO14  ├──── GPS TX
│              │       │         │
└──────────────┘       │ GPIO21  ├──── GPS RX
                       └─────────┘
```

### 5V GPS Module

Use a level shifter or voltage divider on the GPS TX line:

```
GPS TX (5V) ──────┬───── 1kΩ ────┬───── GPIO14
                  │               │
                  └─── 2kΩ ───────┴───── GND
```

---

## Power Distribution

### Recommended Approach

```
                  ┌────────────────────────────────┐
                  │         12V Power Supply       │
                  │             3A+                │
                  └───────────────┬────────────────┘
                                  │
                    ┌─────────────┼─────────────┐
                    │             │             │
                    ▼             ▼             ▼
              ┌─────────┐   ┌─────────┐   ┌─────────┐
              │TMC2209  │   │TMC2209  │   │ Buck    │
              │Azimuth  │   │Elevation│   │Converter│
              │VM = 12V │   │VM = 12V │   │12V→5V   │
              └─────────┘   └─────────┘   └────┬────┘
                                               │
                                               ▼
                                         ┌─────────┐
                                         │ ESP32   │
                                         │ 5V/3.3V │
                                         └─────────┘
```

### Current Requirements

| Component | Typical | Peak |
|-----------|---------|------|
| ESP32-S3-CAM | 180mA | 500mA |
| TMC2209 (x2) | 50mA | 100mA |
| NEMA 17 Motor (x2) | - | 1.68A each |
| GPS Module | 25mA | 50mA |
| **Total** | **~300mA** | **~4A** |

Use at least a 3A 12V supply; 5A recommended for margin.

---

## Motor Connections

### Identifying Motor Coils

NEMA 17 motors typically have 4 wires (2 coils):

1. Use a multimeter in continuity mode
2. Find wire pairs that show continuity
3. Label as Coil A (A1, A2) and Coil B (B1, B2)

Common color codes:
| Coil A | Coil B |
|--------|--------|
| Black, Green | Red, Blue |
| Red, Yellow | Black, Orange |

### Connection Order

If motor runs backward, swap A1↔A2 or B1↔B2 (not both).

```
Motor          TMC2209
┌────────┐    ┌────────┐
│ Coil A ├────┤ A1     │
│ (wire1)│    │        │
│        │    │        │
│ Coil A ├────┤ A2     │
│ (wire2)│    │        │
│        │    │        │
│ Coil B ├────┤ B1     │
│ (wire3)│    │        │
│        │    │        │
│ Coil B ├────┤ B2     │
│ (wire4)│    │        │
└────────┘    └────────┘
```

---

## Assembly Steps

### 1. Prepare the ESP32-S3-CAM

1. Test the board by uploading a simple sketch
2. Verify camera functionality
3. Note which pins are available (avoid camera DVP pins)

### 2. Wire the TMC2209 Drivers

1. Connect power (12V to VM, GND to GND)
2. Connect STEP, DIR, DIAG pins to ESP32
3. Connect UART (TX/RX) to ESP32
4. Set MS1/MS2 for addressing
5. Connect EN to ESP32 (shared)

### 3. Connect Motors

1. Identify coil pairs
2. Connect to A1/A2 and B1/B2
3. Verify correct rotation direction

### 4. Connect GPS

1. Connect power (3.3V or 5V depending on module)
2. Connect TX → GPIO14, RX → GPIO21
3. Verify NMEA output at 9600 baud

### 5. Test Electronics

1. Upload firmware
2. Check serial output for errors
3. Verify motor movement via web interface
4. Verify GPS fix

### 6. Mount Hardware

1. Secure motors to az/el mount
2. Attach antenna boom
3. Ensure cable routing allows full rotation
4. Verify no mechanical binding

---

## Troubleshooting

### Motors Don't Move

1. Check 12V power to TMC2209
2. Verify EN pin is LOW when motors should be on
3. Check UART communication (serial monitor)
4. Test STEP/DIR with manual pulses
5. Verify motor coil connections

### No UART Communication

```
StepperControl: Driver connection test - Az:FAIL, El:FAIL
```

1. Check TX/RX wiring (may need swap)
2. Verify MS1/MS2 addressing
3. Add 1kΩ series resistor on TX
4. Check for loose connections

### Motor Runs Backward

Swap A1↔A2 OR B1↔B2 (not both)

### Motor Vibrates but Doesn't Turn

1. Wrong coil wiring (check pairs)
2. Loose motor connection
3. Mechanical binding

### StallGuard Triggers Early

Increase stall threshold in config.h:
```cpp
#define TMC_STALL_THRESHOLD 100  // Higher = less sensitive
```

### No GPS Fix

1. Ensure clear sky view
2. Check antenna connection
3. Verify baud rate (9600 default)
4. Wait 1-2 minutes for cold start

### WiFi Won't Connect

1. Check SSID/password
2. Ensure 2.4GHz network (ESP32 doesn't support 5GHz)
3. Reset to AP mode (hold button during boot if implemented)

---

## Reference Pinout

### ESP32-S3-CAM (Freenove)

Available pins after camera:
- GPIO1, GPIO2 (shared with UART)
- GPIO38, GPIO39, GPIO40, GPIO41, GPIO42
- GPIO43, GPIO44 (UART0)
- GPIO14, GPIO21

Avoid (camera DVP):
- GPIO4, GPIO5 (I2C)
- GPIO6, GPIO7, GPIO8, GPIO9, GPIO10, GPIO11, GPIO12, GPIO13
- GPIO15, GPIO16, GPIO17, GPIO18

---

## Safety Notes

⚠️ **Camera Alignment**
- NEVER point camera at sun without proper solar filter
- Use ND filter (ND1000+) or dedicated solar filter
- Moon alignment is safe without filter

⚠️ **Electrical**
- Disconnect power before wiring changes
- Use proper gauge wire for motor current
- Add fuses for protection

⚠️ **Mechanical**
- Ensure cable routing allows full rotation
- Add limit switches for backup if needed
- Balance antenna to reduce motor load
