/**
 * @file tracking_engine.h
 * @brief Satellite tracking engine with SGP4 orbit propagation
 * 
 * Handles TLE parsing, orbit calculation, and pass prediction
 * for satellite tracking.
 */

#ifndef TRACKING_ENGINE_H
#define TRACKING_ENGINE_H

#include <Arduino.h>
#include <Sgp4.h>
#include "config.h"
#include "gps.h"

// Tracking mode enumeration
enum class TrackingMode {
    IDLE,       // Not tracking
    MANUAL,     // Manual position control
    AUTO,       // Automatic satellite tracking
    EXTERNAL    // External control via rotctld
};

// Satellite position data
struct SatellitePosition {
    float azimuth;          // Degrees from North
    float elevation;        // Degrees above horizon
    float range;            // Distance in km
    float rangeRate;        // Velocity in km/s (+ = receding)
    float latitude;         // Sub-satellite point latitude
    float longitude;        // Sub-satellite point longitude
    float altitude;         // Satellite altitude in km
    bool visible;           // Above horizon
    bool illuminated;       // In sunlight
};

// Pass information
struct PassInfo {
    uint32_t aosTime;       // Acquisition of signal (Unix time)
    uint32_t losTime;       // Loss of signal (Unix time)
    uint32_t maxElTime;     // Maximum elevation time
    float aosAz;            // AOS azimuth
    float losAz;            // LOS azimuth
    float maxEl;            // Maximum elevation
    float maxElAz;          // Azimuth at max elevation
};

// TLE data structure
struct TLEData {
    char name[25];          // Satellite name
    char line1[70];         // TLE line 1
    char line2[70];         // TLE line 2
    uint32_t epoch;         // TLE epoch (Unix time)
    bool valid;             // TLE validity flag
};

/**
 * @class TrackingEngine
 * @brief Main satellite tracking engine
 */
class TrackingEngine {
public:
    TrackingEngine();
    
    /**
     * @brief Initialize tracking engine
     * @return true if successful
     */
    bool begin();
    
    /**
     * @brief Update tracking calculations (call frequently)
     */
    void update();
    
    /**
     * @brief Load TLE data for a satellite
     * @param name Satellite name
     * @param line1 TLE line 1
     * @param line2 TLE line 2
     * @return true if TLE is valid
     */
    bool loadTLE(const char* name, const char* line1, const char* line2);
    
    /**
     * @brief Get current satellite position
     * @return Satellite position structure
     */
    SatellitePosition getPosition() const { return _satPos; }
    
    /**
     * @brief Get next pass information
     * @param pass Output pass information
     * @return true if pass found within search window
     */
    bool getNextPass(PassInfo& pass);
    
    /**
     * @brief Calculate satellite position at a specific time
     * @param unixTime Unix timestamp
     * @param pos Output position
     * @return true if calculation successful
     */
    bool calculatePosition(uint32_t unixTime, SatellitePosition& pos);
    
    /**
     * @brief Start automatic tracking
     * @return true if tracking started
     */
    bool startTracking();
    
    /**
     * @brief Stop tracking
     */
    void stopTracking();
    
    /**
     * @brief Get current tracking mode
     */
    TrackingMode getMode() const { return _mode; }
    
    /**
     * @brief Set tracking mode
     */
    void setMode(TrackingMode mode) { _mode = mode; }
    
    /**
     * @brief Check if satellite is currently visible
     */
    bool isSatelliteVisible() const { return _satPos.visible; }
    
    /**
     * @brief Get loaded satellite name
     */
    String getSatelliteName() const { return String(_tle.name); }
    
    /**
     * @brief Check if TLE is loaded
     */
    bool hasTLE() const { return _tle.valid; }
    
    /**
     * @brief Get observer location
     */
    void getObserverLocation(double& lat, double& lon, double& alt) const;
    
    /**
     * @brief Set observer location manually
     */
    void setObserverLocation(double lat, double lon, double alt);
    
    /**
     * @brief Use GPS for observer location
     */
    void useGPSLocation() { _useGPSLocation = true; }
    
    /**
     * @brief Calculate sun position for camera alignment
     * @param az Output azimuth
     * @param el Output elevation
     * @return true if sun is above horizon
     */
    bool getSunPosition(float& az, float& el);
    
    /**
     * @brief Calculate moon position for camera alignment
     * @param az Output azimuth
     * @param el Output elevation
     * @return true if moon is above horizon
     */
    bool getMoonPosition(float& az, float& el);
    
    /**
     * @brief Check if currently tracking through zenith
     * @return true if zenith handling is active
     */
    bool isZenithPass() const { return _zenithFlipActive; }
    
    /**
     * @brief Get target azimuth (with zenith flip handling)
     */
    float getTargetAzimuth() const;
    
    /**
     * @brief Get target elevation (with zenith flip handling)
     */
    float getTargetElevation() const;

private:
    Sgp4 _sgp4;
    TLEData _tle;
    SatellitePosition _satPos;
    TrackingMode _mode;
    
    // Observer location
    bool _useGPSLocation;
    double _observerLat;
    double _observerLon;
    double _observerAlt;
    
    // Zenith flip handling
    bool _zenithFlipActive;
    bool _zenithFlipDirection;  // true = flipped
    float _lastAzimuth;
    
    // Timing
    uint32_t _lastUpdateMs;
    uint32_t _lastCalculationMs;
    
    // Internal methods
    void updateObserverLocation();
    void handleZenithFlip();
    double julianDateFromUnix(uint32_t unixTime);
    void calculateSunPosition(double jd, double lat, double lon, float& az, float& el);
    void calculateMoonPosition(double jd, double lat, double lon, float& az, float& el);
};

// Global instance
extern TrackingEngine trackingEngine;

#endif // TRACKING_ENGINE_H
