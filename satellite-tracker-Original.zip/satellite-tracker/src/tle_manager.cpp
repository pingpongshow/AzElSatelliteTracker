/**
 * @file tle_manager.cpp
 * @brief TLE fetching and storage implementation
 */

#include "tle_manager.h"
#include <WiFi.h>

// Global instance
TLEManager tleManager;

TLEManager::TLEManager() {
}

bool TLEManager::begin() {
    DEBUG_PRINTLN("TLEManager: Initializing...");
    
    // Open preferences namespace
    if (!_prefs.begin("tle_storage", false)) {
        DEBUG_PRINTLN("TLEManager: Failed to open preferences");
        return false;
    }
    
    DEBUG_PRINTF("TLEManager: %d TLEs in storage\n", getStoredCount());
    return true;
}

bool TLEManager::fetchByNoradId(uint32_t noradId, TLEEntry& entry) {
    if (!isNetworkAvailable()) {
        _lastError = "No network connection";
        return false;
    }
    
    // Build Celestrak GP URL for single satellite
    char url[128];
    snprintf(url, sizeof(url), 
             "https://celestrak.org/NORAD/elements/gp.php?CATNR=%lu&FORMAT=TLE",
             noradId);
    
    DEBUG_PRINTF("TLEManager: Fetching TLE for NORAD %lu\n", noradId);
    
    String response;
    if (!httpFetch(url, response)) {
        return false;
    }
    
    // Parse the response
    if (!parseTLE(response.c_str(), entry)) {
        _lastError = "Failed to parse TLE response";
        return false;
    }
    
    entry.fetchTime = millis() / 1000;
    entry.valid = true;
    
    DEBUG_PRINTF("TLEManager: Fetched TLE for %s\n", entry.name);
    return true;
}

bool TLEManager::fetchByName(const char* name, TLEEntry& entry) {
    if (!isNetworkAvailable()) {
        _lastError = "No network connection";
        return false;
    }
    
    // URL encode the name
    String encodedName = "";
    for (size_t i = 0; name[i]; i++) {
        char c = name[i];
        if (isalnum(c) || c == '-' || c == '_' || c == '.') {
            encodedName += c;
        } else if (c == ' ') {
            encodedName += "%20";
        } else {
            char hex[4];
            snprintf(hex, sizeof(hex), "%%%02X", (unsigned char)c);
            encodedName += hex;
        }
    }
    
    // Build URL
    String url = String(TLE_SOURCE_CELESTRAK) + "?NAME=" + encodedName + "&FORMAT=TLE";
    
    DEBUG_PRINTF("TLEManager: Fetching TLE for '%s'\n", name);
    
    String response;
    if (!httpFetch(url.c_str(), response)) {
        return false;
    }
    
    // Parse the response
    if (!parseTLE(response.c_str(), entry)) {
        _lastError = "Satellite not found or parse error";
        return false;
    }
    
    entry.fetchTime = millis() / 1000;
    entry.valid = true;
    
    DEBUG_PRINTF("TLEManager: Fetched TLE for %s\n", entry.name);
    return true;
}

int TLEManager::fetchAmateurSatellites(void (*callback)(const TLEEntry& entry)) {
    if (!isNetworkAvailable()) {
        _lastError = "No network connection";
        return 0;
    }
    
    DEBUG_PRINTLN("TLEManager: Fetching amateur satellite TLEs...");
    
    String response;
    if (!httpFetch(TLE_SOURCE_AMATEUR, response)) {
        return 0;
    }
    
    int count = 0;
    const char* ptr = response.c_str();
    
    while (*ptr) {
        TLEEntry entry;
        
        // Find next TLE (3 lines)
        const char* nameStart = ptr;
        const char* line1Start = strchr(nameStart, '\n');
        if (!line1Start) break;
        line1Start++;
        
        const char* line2Start = strchr(line1Start, '\n');
        if (!line2Start) break;
        line2Start++;
        
        const char* nextEntry = strchr(line2Start, '\n');
        
        // Extract name
        int nameLen = line1Start - nameStart - 1;
        if (nameLen > 0 && nameLen < (int)sizeof(entry.name)) {
            strncpy(entry.name, nameStart, nameLen);
            entry.name[nameLen] = '\0';
            
            // Trim trailing whitespace
            while (nameLen > 0 && entry.name[nameLen-1] == ' ') {
                entry.name[--nameLen] = '\0';
            }
        }
        
        // Extract line 1
        int line1Len = line2Start - line1Start - 1;
        if (line1Len >= 69) {
            strncpy(entry.line1, line1Start, 69);
            entry.line1[69] = '\0';
        }
        
        // Extract line 2
        int line2Len = nextEntry ? (nextEntry - line2Start) : strlen(line2Start);
        if (line2Len >= 69) {
            strncpy(entry.line2, line2Start, 69);
            entry.line2[69] = '\0';
        }
        
        // Validate and callback
        if (validateTLE(entry.line1, entry.line2)) {
            entry.fetchTime = millis() / 1000;
            entry.valid = true;
            callback(entry);
            count++;
        }
        
        // Move to next entry
        if (nextEntry) {
            ptr = nextEntry + 1;
        } else {
            break;
        }
    }
    
    DEBUG_PRINTF("TLEManager: Fetched %d amateur satellite TLEs\n", count);
    return count;
}

bool TLEManager::saveTLE(const TLEEntry& entry, int slot) {
    if (slot < 0 || slot >= MAX_STORED_TLES) {
        return false;
    }
    
    char key[16];
    
    snprintf(key, sizeof(key), "tle_%d_name", slot);
    _prefs.putString(key, entry.name);
    
    snprintf(key, sizeof(key), "tle_%d_l1", slot);
    _prefs.putString(key, entry.line1);
    
    snprintf(key, sizeof(key), "tle_%d_l2", slot);
    _prefs.putString(key, entry.line2);
    
    snprintf(key, sizeof(key), "tle_%d_time", slot);
    _prefs.putUInt(key, entry.fetchTime);
    
    snprintf(key, sizeof(key), "tle_%d_valid", slot);
    _prefs.putBool(key, true);
    
    DEBUG_PRINTF("TLEManager: Saved TLE '%s' to slot %d\n", entry.name, slot);
    return true;
}

bool TLEManager::loadTLE(int slot, TLEEntry& entry) {
    if (slot < 0 || slot >= MAX_STORED_TLES) {
        return false;
    }
    
    char key[16];
    
    snprintf(key, sizeof(key), "tle_%d_valid", slot);
    if (!_prefs.getBool(key, false)) {
        return false;
    }
    
    snprintf(key, sizeof(key), "tle_%d_name", slot);
    String name = _prefs.getString(key, "");
    strncpy(entry.name, name.c_str(), sizeof(entry.name) - 1);
    
    snprintf(key, sizeof(key), "tle_%d_l1", slot);
    String line1 = _prefs.getString(key, "");
    strncpy(entry.line1, line1.c_str(), sizeof(entry.line1) - 1);
    
    snprintf(key, sizeof(key), "tle_%d_l2", slot);
    String line2 = _prefs.getString(key, "");
    strncpy(entry.line2, line2.c_str(), sizeof(entry.line2) - 1);
    
    snprintf(key, sizeof(key), "tle_%d_time", slot);
    entry.fetchTime = _prefs.getUInt(key, 0);
    
    entry.valid = validateTLE(entry.line1, entry.line2);
    
    return entry.valid;
}

void TLEManager::deleteTLE(int slot) {
    if (slot < 0 || slot >= MAX_STORED_TLES) {
        return;
    }
    
    char key[16];
    snprintf(key, sizeof(key), "tle_%d_valid", slot);
    _prefs.putBool(key, false);
    
    DEBUG_PRINTF("TLEManager: Deleted TLE from slot %d\n", slot);
}

int TLEManager::getStoredCount() {
    int count = 0;
    char key[16];
    
    for (int i = 0; i < MAX_STORED_TLES; i++) {
        snprintf(key, sizeof(key), "tle_%d_valid", i);
        if (_prefs.getBool(key, false)) {
            count++;
        }
    }
    
    return count;
}

int TLEManager::listStoredTLEs(String* names, int maxCount) {
    int count = 0;
    char key[16];
    
    for (int i = 0; i < MAX_STORED_TLES && count < maxCount; i++) {
        snprintf(key, sizeof(key), "tle_%d_valid", i);
        if (_prefs.getBool(key, false)) {
            snprintf(key, sizeof(key), "tle_%d_name", i);
            names[count++] = _prefs.getString(key, "");
        }
    }
    
    return count;
}

bool TLEManager::findStoredTLE(const char* name, TLEEntry& entry) {
    char key[16];
    
    for (int i = 0; i < MAX_STORED_TLES; i++) {
        snprintf(key, sizeof(key), "tle_%d_valid", i);
        if (!_prefs.getBool(key, false)) continue;
        
        snprintf(key, sizeof(key), "tle_%d_name", i);
        String storedName = _prefs.getString(key, "");
        
        if (storedName.equalsIgnoreCase(name)) {
            return loadTLE(i, entry);
        }
    }
    
    return false;
}

bool TLEManager::parseTLE(const char* text, TLEEntry& entry) {
    // Find the three lines
    const char* lines[3] = {nullptr, nullptr, nullptr};
    int lineCount = 0;
    
    const char* ptr = text;
    while (*ptr && lineCount < 3) {
        // Skip whitespace
        while (*ptr == ' ' || *ptr == '\t') ptr++;
        
        if (*ptr && *ptr != '\r' && *ptr != '\n') {
            lines[lineCount++] = ptr;
        }
        
        // Find end of line
        while (*ptr && *ptr != '\r' && *ptr != '\n') ptr++;
        
        // Skip line endings
        while (*ptr == '\r' || *ptr == '\n') ptr++;
    }
    
    if (lineCount < 3) {
        return false;
    }
    
    // Extract satellite name (line 0)
    const char* nameEnd = lines[0];
    while (*nameEnd && *nameEnd != '\r' && *nameEnd != '\n') nameEnd++;
    int nameLen = nameEnd - lines[0];
    if (nameLen >= (int)sizeof(entry.name)) {
        nameLen = sizeof(entry.name) - 1;
    }
    strncpy(entry.name, lines[0], nameLen);
    entry.name[nameLen] = '\0';
    
    // Trim trailing whitespace from name
    while (nameLen > 0 && entry.name[nameLen-1] == ' ') {
        entry.name[--nameLen] = '\0';
    }
    
    // Extract line 1
    const char* line1End = lines[1];
    while (*line1End && *line1End != '\r' && *line1End != '\n') line1End++;
    int line1Len = line1End - lines[1];
    if (line1Len > 69) line1Len = 69;
    strncpy(entry.line1, lines[1], line1Len);
    entry.line1[line1Len] = '\0';
    
    // Extract line 2
    const char* line2End = lines[2];
    while (*line2End && *line2End != '\r' && *line2End != '\n') line2End++;
    int line2Len = line2End - lines[2];
    if (line2Len > 69) line2Len = 69;
    strncpy(entry.line2, lines[2], line2Len);
    entry.line2[line2Len] = '\0';
    
    // Validate
    return validateTLE(entry.line1, entry.line2);
}

bool TLEManager::isTLEStale(const TLEEntry& entry) {
    // TLE is stale if older than 7 days
    uint32_t now = millis() / 1000;
    return (now - entry.fetchTime) > (7 * 24 * 3600);
}

bool TLEManager::isNetworkAvailable() {
    return WiFi.status() == WL_CONNECTED;
}

bool TLEManager::httpFetch(const char* url, String& response) {
    HTTPClient http;
    
    http.setTimeout(TLE_FETCH_TIMEOUT_MS);
    
    DEBUG_PRINTF("TLEManager: HTTP GET %s\n", url);
    
    if (!http.begin(url)) {
        _lastError = "Failed to begin HTTP connection";
        return false;
    }
    
    int httpCode = http.GET();
    
    if (httpCode != HTTP_CODE_OK) {
        _lastError = "HTTP error: " + String(httpCode);
        http.end();
        return false;
    }
    
    response = http.getString();
    http.end();
    
    if (response.length() == 0) {
        _lastError = "Empty response";
        return false;
    }
    
    return true;
}

bool TLEManager::validateTLE(const char* line1, const char* line2) {
    // Basic validation
    if (strlen(line1) < 69 || strlen(line2) < 69) {
        return false;
    }
    
    if (line1[0] != '1' || line2[0] != '2') {
        return false;
    }
    
    // Verify checksums
    int check1 = checksumTLELine(line1);
    int check2 = checksumTLELine(line2);
    
    int expected1 = line1[68] - '0';
    int expected2 = line2[68] - '0';
    
    if (check1 != expected1 || check2 != expected2) {
        DEBUG_PRINTF("TLEManager: Checksum mismatch (L1: %d!=%d, L2: %d!=%d)\n",
                     check1, expected1, check2, expected2);
        // Some TLEs have bad checksums, so just warn but don't fail
    }
    
    return true;
}

int TLEManager::checksumTLELine(const char* line) {
    int sum = 0;
    
    for (int i = 0; i < 68; i++) {
        char c = line[i];
        if (c >= '0' && c <= '9') {
            sum += c - '0';
        } else if (c == '-') {
            sum += 1;
        }
    }
    
    return sum % 10;
}
