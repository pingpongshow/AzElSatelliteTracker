/**
 * @file web_server.cpp
 * @brief Web server implementation
 */

#include "web_server.h"
#include "stepper_control.h"
#include "tracking_engine.h"
#include "tle_manager.h"
#include "wifi_manager.h"
#include "gps.h"
#include "camera_align.h"
#include "nvs_storage.h"
#include "rotctld_server.h"
#include <SPIFFS.h>

// Global instance
WebServer webServer;

WebServer::WebServer()
    : _server(nullptr)
    , _ws(nullptr)
    , _running(false)
    , _lastBroadcast(0)
{
}

WebServer::~WebServer() {
    stop();
}

bool WebServer::begin() {
    DEBUG_PRINTLN("WebServer: Initializing...");
    
    // Initialize SPIFFS for static files
    if (!SPIFFS.begin(true)) {
        DEBUG_PRINTLN("WebServer: SPIFFS mount failed");
        return false;
    }
    
    // Create server
    _server = new AsyncWebServer(WEB_SERVER_PORT);
    _ws = new AsyncWebSocket("/ws");
    
    // Setup routes
    setupRoutes();
    setupAPIRoutes();
    setupWebSocketHandler();
    
    // Start server
    _server->begin();
    _running = true;
    
    DEBUG_PRINTF("WebServer: Started on port %d\n", WEB_SERVER_PORT);
    return true;
}

void WebServer::stop() {
    if (_running) {
        _server->end();
        delete _ws;
        delete _server;
        _ws = nullptr;
        _server = nullptr;
        _running = false;
    }
}

void WebServer::update() {
    if (!_running) return;
    
    // Cleanup disconnected WebSocket clients
    _ws->cleanupClients();
    
    // Periodic status broadcast
    uint32_t now = millis();
    if (now - _lastBroadcast >= STATUS_UPDATE_INTERVAL_MS) {
        broadcastStatus();
        _lastBroadcast = now;
    }
}

void WebServer::broadcastStatus() {
    if (_ws->count() == 0) return;
    
    String json = buildStatusJSON();
    _ws->textAll(json);
}

void WebServer::sendEvent(const char* event, const char* data) {
    if (_ws->count() == 0) return;
    
    JsonDocument doc;
    doc["event"] = event;
    doc["data"] = data;
    
    String json;
    serializeJson(doc, json);
    _ws->textAll(json);
}

void WebServer::setupRoutes() {
    // Serve static files from SPIFFS
    _server->serveStatic("/", SPIFFS, "/").setDefaultFile("index.html");
    
    // Root handler (for SPA routing)
    _server->on("/", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleRoot(request);
    });
    
    // 404 handler
    _server->onNotFound([this](AsyncWebServerRequest* request) {
        handleNotFound(request);
    });
}

void WebServer::setupAPIRoutes() {
    // Status endpoints
    _server->on("/api/status", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetStatus(request);
    });
    
    _server->on("/api/position", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetPosition(request);
    });
    
    _server->on("/api/gps", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetGPS(request);
    });
    
    _server->on("/api/config", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetConfig(request);
    });
    
    // Control endpoints
    AsyncCallbackJsonWebHandler* posHandler = new AsyncCallbackJsonWebHandler("/api/position",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleSetPosition(request, json);
        });
    _server->addHandler(posHandler);
    
    _server->on("/api/stop", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleStop(request);
    });
    
    _server->on("/api/park", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handlePark(request);
    });
    
    _server->on("/api/home", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleHome(request);
    });
    
    _server->on("/api/sethome", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleSetHome(request);
    });
    
    AsyncCallbackJsonWebHandler* calibHandler = new AsyncCallbackJsonWebHandler("/api/calibrate",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleCalibrate(request, json);
        });
    _server->addHandler(calibHandler);
    
    // Tracking endpoints
    AsyncCallbackJsonWebHandler* trackHandler = new AsyncCallbackJsonWebHandler("/api/track",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleStartTracking(request, json);
        });
    _server->addHandler(trackHandler);
    
    _server->on("/api/track", HTTP_DELETE, [this](AsyncWebServerRequest* request) {
        handleStopTracking(request);
    });
    
    _server->on("/api/nextpass", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetNextPass(request);
    });
    
    // TLE endpoints
    _server->on("/api/tle", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetTLEs(request);
    });
    
    AsyncCallbackJsonWebHandler* tleHandler = new AsyncCallbackJsonWebHandler("/api/tle",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleLoadTLE(request, json);
        });
    _server->addHandler(tleHandler);
    
    AsyncCallbackJsonWebHandler* fetchHandler = new AsyncCallbackJsonWebHandler("/api/tle/fetch",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleFetchTLE(request, json);
        });
    _server->addHandler(fetchHandler);
    
    // WiFi endpoints
    _server->on("/api/wifi/networks", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetNetworks(request);
    });
    
    AsyncCallbackJsonWebHandler* wifiHandler = new AsyncCallbackJsonWebHandler("/api/wifi/connect",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleConnectWiFi(request, json);
        });
    _server->addHandler(wifiHandler);
    
    _server->on("/api/wifi/status", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetWiFiStatus(request);
    });
    
    // System endpoints
    _server->on("/api/system/info", HTTP_GET, [this](AsyncWebServerRequest* request) {
        handleGetSystemInfo(request);
    });
    
    _server->on("/api/system/reboot", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleReboot(request);
    });
    
    _server->on("/api/system/reset", HTTP_POST, [this](AsyncWebServerRequest* request) {
        handleFactoryReset(request);
    });
    
    // GPS manual position endpoint
    AsyncCallbackJsonWebHandler* gpsManualHandler = new AsyncCallbackJsonWebHandler("/api/gps/manual",
        [this](AsyncWebServerRequest* request, JsonVariant& json) {
            handleSetManualGPS(request, json);
        });
    _server->addHandler(gpsManualHandler);
}

void WebServer::setupWebSocketHandler() {
    _ws->onEvent([this](AsyncWebSocket* server, AsyncWebSocketClient* client,
                        AwsEventType type, void* arg, uint8_t* data, size_t len) {
        onWebSocketEvent(server, client, type, arg, data, len);
    });
    
    _server->addHandler(_ws);
}

void WebServer::handleRoot(AsyncWebServerRequest* request) {
    request->send(SPIFFS, "/index.html", "text/html");
}

void WebServer::handleNotFound(AsyncWebServerRequest* request) {
    // For API routes, return JSON error
    if (request->url().startsWith("/api/")) {
        sendError(request, "Endpoint not found", 404);
    } else {
        // For other routes, serve index.html (SPA routing)
        request->send(SPIFFS, "/index.html", "text/html");
    }
}

void WebServer::handleGetStatus(AsyncWebServerRequest* request) {
    JsonDocument doc;
    
    // Position
    doc["azimuth"] = stepperControl.getAzimuth();
    doc["elevation"] = stepperControl.getElevation();
    doc["targetAz"] = stepperControl.getTargetAzimuth();
    doc["targetEl"] = stepperControl.getTargetElevation();
    doc["moving"] = stepperControl.isMoving();
    doc["enabled"] = stepperControl.isEnabled();
    
    // Tracking
    doc["mode"] = (int)trackingEngine.getMode();
    doc["satellite"] = trackingEngine.getSatelliteName();
    doc["satVisible"] = trackingEngine.isSatelliteVisible();
    
    // Satellite position
    if (trackingEngine.hasTLE()) {
        SatellitePosition satPos = trackingEngine.getPosition();
        doc["satAz"] = satPos.azimuth;
        doc["satEl"] = satPos.elevation;
        doc["satRange"] = satPos.range;
    }
    
    // GPS
    doc["gpsValid"] = gps.hasFix();
    doc["gpsSats"] = gps.getSatellites();
    
    // Connection
    doc["wifiConnected"] = wifiManager.isConnected();
    doc["rotctldClients"] = rotctldServer.getClientCount();
    
    sendJSON(request, doc);
}

void WebServer::handleGetPosition(AsyncWebServerRequest* request) {
    JsonDocument doc;
    doc["azimuth"] = stepperControl.getAzimuth();
    doc["elevation"] = stepperControl.getElevation();
    doc["targetAz"] = stepperControl.getTargetAzimuth();
    doc["targetEl"] = stepperControl.getTargetElevation();
    doc["moving"] = stepperControl.isMoving();
    sendJSON(request, doc);
}

void WebServer::handleGetGPS(AsyncWebServerRequest* request) {
    JsonDocument doc;
    GPSData data = gps.getData();
    
    doc["valid"] = data.valid;
    doc["latitude"] = data.latitude;
    doc["longitude"] = data.longitude;
    doc["altitude"] = data.altitude;
    doc["satellites"] = data.satellites;
    doc["hdop"] = data.hdop;
    doc["time"] = data.unixTime;
    doc["manual"] = gps.isUsingManualPosition();
    
    sendJSON(request, doc);
}

void WebServer::handleGetConfig(AsyncWebServerRequest* request) {
    JsonDocument doc;
    
    doc["version"] = FIRMWARE_VERSION;
    doc["model"] = DEVICE_MODEL;
    doc["azMin"] = AZ_MIN_DEG;
    doc["azMax"] = AZ_MAX_DEG;
    doc["elMin"] = EL_MIN_DEG;
    doc["elMax"] = EL_MAX_DEG;
    doc["parkAz"] = PARK_AZ_DEG;
    doc["parkEl"] = PARK_EL_DEG;
    doc["azOffset"] = stepperControl.getAzimuthOffset();
    doc["elOffset"] = stepperControl.getElevationOffset();
    
    sendJSON(request, doc);
}

void WebServer::handleSetPosition(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!json.containsKey("azimuth") || !json.containsKey("elevation")) {
        sendError(request, "Missing azimuth or elevation");
        return;
    }
    
    float az = json["azimuth"].as<float>();
    float el = json["elevation"].as<float>();
    float speed = json["speed"] | TRACKING_SPEED_DEG_S;
    
    stepperControl.moveTo(az, el, speed);
    sendOK(request, "Position set");
}

void WebServer::handleStop(AsyncWebServerRequest* request) {
    stepperControl.stop();
    trackingEngine.stopTracking();
    sendOK(request, "Stopped");
}

void WebServer::handlePark(AsyncWebServerRequest* request) {
    stepperControl.park();
    sendOK(request, "Parking");
}

void WebServer::handleHome(AsyncWebServerRequest* request) {
    if (stepperControl.home()) {
        sendOK(request, "Homing complete");
    } else {
        sendError(request, "Homing failed");
    }
}

void WebServer::handleSetHome(AsyncWebServerRequest* request) {
    stepperControl.setHome();
    sendOK(request, "Home position set");
}

void WebServer::handleCalibrate(AsyncWebServerRequest* request, JsonVariant& json) {
    String method = json["method"] | "sun";
    
    if (method == "sun") {
        AlignmentResult result = cameraAlign.alignToSun();
        if (result.success) {
            char msg[128];
            snprintf(msg, sizeof(msg), "Sun alignment complete. Offsets: Az=%.3f°, El=%.3f°", 
                     result.azOffset, result.elOffset);
            sendOK(request, msg);
        } else {
            sendError(request, result.errorMessage.c_str());
        }
    } else if (method == "moon") {
        AlignmentResult result = cameraAlign.alignToMoon();
        if (result.success) {
            char msg[128];
            snprintf(msg, sizeof(msg), "Moon alignment complete. Offsets: Az=%.3f°, El=%.3f°", 
                     result.azOffset, result.elOffset);
            sendOK(request, msg);
        } else {
            sendError(request, result.errorMessage.c_str());
        }
    } else if (method == "manual") {
        float azOffset = json["azOffset"] | 0.0f;
        float elOffset = json["elOffset"] | 0.0f;
        stepperControl.setCalibrationOffset(azOffset, elOffset);
        sendOK(request, "Manual calibration set");
    } else {
        sendError(request, "Unknown calibration method");
    }
}

void WebServer::handleStartTracking(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!json.containsKey("name")) {
        sendError(request, "Missing satellite name");
        return;
    }
    
    String name = json["name"].as<String>();
    
    // Check if TLE provided or should load from storage
    if (json.containsKey("line1") && json.containsKey("line2")) {
        String line1 = json["line1"].as<String>();
        String line2 = json["line2"].as<String>();
        
        if (!trackingEngine.loadTLE(name.c_str(), line1.c_str(), line2.c_str())) {
            sendError(request, "Invalid TLE data");
            return;
        }
    } else {
        // Try to load from storage
        TLEEntry entry;
        if (!tleManager.findStoredTLE(name.c_str(), entry)) {
            sendError(request, "TLE not found in storage");
            return;
        }
        
        if (!trackingEngine.loadTLE(entry.name, entry.line1, entry.line2)) {
            sendError(request, "Failed to load TLE");
            return;
        }
    }
    
    if (trackingEngine.startTracking()) {
        sendOK(request, "Tracking started");
    } else {
        sendError(request, "Failed to start tracking");
    }
}

void WebServer::handleStopTracking(AsyncWebServerRequest* request) {
    trackingEngine.stopTracking();
    sendOK(request, "Tracking stopped");
}

void WebServer::handleGetNextPass(AsyncWebServerRequest* request) {
    PassInfo pass;
    
    if (!trackingEngine.getNextPass(pass)) {
        sendError(request, "No pass found", 404);
        return;
    }
    
    JsonDocument doc;
    doc["aosTime"] = pass.aosTime;
    doc["losTime"] = pass.losTime;
    doc["maxElTime"] = pass.maxElTime;
    doc["aosAz"] = pass.aosAz;
    doc["losAz"] = pass.losAz;
    doc["maxEl"] = pass.maxEl;
    doc["maxElAz"] = pass.maxElAz;
    doc["duration"] = pass.losTime - pass.aosTime;
    
    sendJSON(request, doc);
}

void WebServer::handleGetTLEs(AsyncWebServerRequest* request) {
    JsonDocument doc;
    JsonArray tles = doc["tles"].to<JsonArray>();
    
    String names[MAX_STORED_TLES];
    int count = tleManager.listStoredTLEs(names, MAX_STORED_TLES);
    
    for (int i = 0; i < count; i++) {
        TLEEntry entry;
        if (tleManager.findStoredTLE(names[i].c_str(), entry)) {
            JsonObject tle = tles.add<JsonObject>();
            tle["name"] = entry.name;
            tle["stale"] = tleManager.isTLEStale(entry);
        }
    }
    
    doc["count"] = count;
    sendJSON(request, doc);
}

void WebServer::handleLoadTLE(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!json.containsKey("name") || !json.containsKey("line1") || !json.containsKey("line2")) {
        sendError(request, "Missing TLE data");
        return;
    }
    
    TLEEntry entry;
    strncpy(entry.name, json["name"].as<const char*>(), sizeof(entry.name) - 1);
    strncpy(entry.line1, json["line1"].as<const char*>(), sizeof(entry.line1) - 1);
    strncpy(entry.line2, json["line2"].as<const char*>(), sizeof(entry.line2) - 1);
    entry.fetchTime = millis() / 1000;
    entry.valid = true;
    
    // Find empty slot or slot with same name
    int slot = -1;
    for (int i = 0; i < MAX_STORED_TLES; i++) {
        TLEEntry existing;
        if (!tleManager.loadTLE(i, existing)) {
            slot = i;
            break;
        }
        if (strcasecmp(existing.name, entry.name) == 0) {
            slot = i;
            break;
        }
    }
    
    if (slot < 0) {
        sendError(request, "No storage space available");
        return;
    }
    
    if (tleManager.saveTLE(entry, slot)) {
        sendOK(request, "TLE saved");
    } else {
        sendError(request, "Failed to save TLE");
    }
}

void WebServer::handleFetchTLE(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!wifiManager.isConnected()) {
        sendError(request, "No network connection");
        return;
    }
    
    TLEEntry entry;
    bool success = false;
    
    if (json.containsKey("noradId")) {
        success = tleManager.fetchByNoradId(json["noradId"].as<uint32_t>(), entry);
    } else if (json.containsKey("name")) {
        success = tleManager.fetchByName(json["name"].as<const char*>(), entry);
    } else {
        sendError(request, "Provide noradId or name");
        return;
    }
    
    if (!success) {
        sendError(request, tleManager.getLastError().c_str());
        return;
    }
    
    // Save to storage
    int slot = 0;  // Find appropriate slot
    tleManager.saveTLE(entry, slot);
    
    JsonDocument doc;
    doc["name"] = entry.name;
    doc["line1"] = entry.line1;
    doc["line2"] = entry.line2;
    sendJSON(request, doc);
}

void WebServer::handleGetNetworks(AsyncWebServerRequest* request) {
    NetworkInfo networks[20];
    int count = wifiManager.scanNetworks(networks, 20);
    
    JsonDocument doc;
    JsonArray arr = doc["networks"].to<JsonArray>();
    
    for (int i = 0; i < count; i++) {
        JsonObject net = arr.add<JsonObject>();
        net["ssid"] = networks[i].ssid;
        net["rssi"] = networks[i].rssi;
        net["open"] = networks[i].open;
    }
    
    doc["count"] = count;
    sendJSON(request, doc);
}

void WebServer::handleConnectWiFi(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!json.containsKey("ssid")) {
        sendError(request, "Missing SSID");
        return;
    }
    
    String ssid = json["ssid"].as<String>();
    String password = json["password"] | "";
    
    wifiManager.connect(ssid.c_str(), password.c_str(), true);
    sendOK(request, "Connecting...");
}

void WebServer::handleGetWiFiStatus(AsyncWebServerRequest* request) {
    JsonDocument doc;
    
    doc["mode"] = (int)wifiManager.getMode();
    doc["connected"] = wifiManager.isConnected();
    doc["ssid"] = wifiManager.getSSID();
    doc["ip"] = wifiManager.getIP().toString();
    doc["rssi"] = wifiManager.getRSSI();
    doc["hostname"] = wifiManager.getHostname();
    doc["mdns"] = wifiManager.isMDNSActive();
    
    sendJSON(request, doc);
}

void WebServer::handleGetSystemInfo(AsyncWebServerRequest* request) {
    JsonDocument doc;
    
    doc["version"] = FIRMWARE_VERSION;
    doc["model"] = DEVICE_MODEL;
    doc["freeHeap"] = ESP.getFreeHeap();
    doc["heapSize"] = ESP.getHeapSize();
    doc["freePsram"] = ESP.getFreePsram();
    doc["uptime"] = millis() / 1000;
    doc["cpuFreq"] = ESP.getCpuFreqMHz();
    doc["flashSize"] = ESP.getFlashChipSize();
    doc["sdkVersion"] = ESP.getSdkVersion();
    
    sendJSON(request, doc);
}

void WebServer::handleReboot(AsyncWebServerRequest* request) {
    sendOK(request, "Rebooting...");
    delay(500);
    ESP.restart();
}

void WebServer::handleFactoryReset(AsyncWebServerRequest* request) {
    nvsStorage.factoryReset();
    sendOK(request, "Factory reset complete. Rebooting...");
    delay(500);
    ESP.restart();
}

void WebServer::handleSetManualGPS(AsyncWebServerRequest* request, JsonVariant& json) {
    if (!json.containsKey("latitude") || !json.containsKey("longitude")) {
        sendError(request, "Missing latitude or longitude");
        return;
    }
    
    double lat = json["latitude"].as<double>();
    double lon = json["longitude"].as<double>();
    double alt = json["altitude"] | 0.0;
    
    // Validate coordinates
    if (lat < -90 || lat > 90) {
        sendError(request, "Invalid latitude");
        return;
    }
    if (lon < -180 || lon > 180) {
        sendError(request, "Invalid longitude");
        return;
    }
    
    // Set manual position
    gps.setManualPosition(lat, lon, alt);
    gps.setUseManualPosition(true);
    
    // Update tracking engine
    trackingEngine.setObserverLocation(lat, lon, alt);
    
    // Save to NVS
    nvsStorage.saveLocation(lat, lon, alt, true);
    
    sendOK(request, "Manual position set");
}

void WebServer::onWebSocketEvent(AsyncWebSocket* server, AsyncWebSocketClient* client,
                                  AwsEventType type, void* arg, uint8_t* data, size_t len) {
    switch (type) {
        case WS_EVT_CONNECT:
            DEBUG_PRINTF("WebSocket client connected: %u\n", client->id());
            // Send initial status
            client->text(buildStatusJSON());
            break;
            
        case WS_EVT_DISCONNECT:
            DEBUG_PRINTF("WebSocket client disconnected: %u\n", client->id());
            break;
            
        case WS_EVT_DATA: {
            // Handle incoming WebSocket messages
            AwsFrameInfo* info = (AwsFrameInfo*)arg;
            if (info->final && info->index == 0 && info->len == len && info->opcode == WS_TEXT) {
                data[len] = 0;
                DEBUG_PRINTF("WebSocket message: %s\n", (char*)data);
                
                // Parse JSON command
                JsonDocument doc;
                DeserializationError error = deserializeJson(doc, (char*)data);
                if (!error) {
                    String cmd = doc["cmd"] | "";
                    // Handle WebSocket commands if needed
                }
            }
            break;
        }
            
        default:
            break;
    }
}

void WebServer::sendJSON(AsyncWebServerRequest* request, JsonDocument& doc, int code) {
    String response;
    serializeJson(doc, response);
    request->send(code, "application/json", response);
}

void WebServer::sendError(AsyncWebServerRequest* request, const char* message, int code) {
    JsonDocument doc;
    doc["error"] = message;
    sendJSON(request, doc, code);
}

void WebServer::sendOK(AsyncWebServerRequest* request, const char* message) {
    JsonDocument doc;
    doc["status"] = "ok";
    doc["message"] = message;
    sendJSON(request, doc);
}

String WebServer::buildStatusJSON() {
    JsonDocument doc;
    
    doc["type"] = "status";
    doc["az"] = stepperControl.getAzimuth();
    doc["el"] = stepperControl.getElevation();
    doc["targetAz"] = stepperControl.getTargetAzimuth();
    doc["targetEl"] = stepperControl.getTargetElevation();
    doc["moving"] = stepperControl.isMoving();
    doc["mode"] = (int)trackingEngine.getMode();
    doc["sat"] = trackingEngine.getSatelliteName();
    doc["visible"] = trackingEngine.isSatelliteVisible();
    doc["gps"] = gps.hasFix();
    doc["time"] = gps.getUnixTime();
    
    if (trackingEngine.hasTLE()) {
        SatellitePosition pos = trackingEngine.getPosition();
        doc["satAz"] = pos.azimuth;
        doc["satEl"] = pos.elevation;
    }
    
    String json;
    serializeJson(doc, json);
    return json;
}
