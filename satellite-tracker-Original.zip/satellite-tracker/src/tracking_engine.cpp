/**
 * @file tracking_engine.cpp
 * @brief Satellite tracking engine implementation
 */

#include "tracking_engine.h"
#include "stepper_control.h"
#include <math.h>

// Global instance
TrackingEngine trackingEngine;

// Constants for astronomical calculations
const double DEG_TO_RAD = PI / 180.0;
const double RAD_TO_DEG = 180.0 / PI;
const double UNIX_TO_JD_OFFSET = 2440587.5;  // Unix epoch in Julian Date
const double SECONDS_PER_DAY = 86400.0;

TrackingEngine::TrackingEngine()
    : _mode(TrackingMode::IDLE)
    , _useGPSLocation(true)
    , _observerLat(DEFAULT_LATITUDE)
    , _observerLon(DEFAULT_LONGITUDE)
    , _observerAlt(DEFAULT_ALTITUDE)
    , _zenithFlipActive(false)
    , _zenithFlipDirection(false)
    , _lastAzimuth(0)
    , _lastUpdateMs(0)
    , _lastCalculationMs(0)
{
    memset(&_tle, 0, sizeof(TLEData));
    memset(&_satPos, 0, sizeof(SatellitePosition));
}

bool TrackingEngine::begin() {
    DEBUG_PRINTLN("TrackingEngine: Initializing...");
    
    // Set initial observer location from GPS or defaults
    updateObserverLocation();
    
    _lastUpdateMs = millis();
    
    DEBUG_PRINTLN("TrackingEngine: Initialization complete");
    return true;
}

void TrackingEngine::update() {
    uint32_t now = millis();
    
    // Update observer location from GPS if enabled
    if (_useGPSLocation && gps.hasFix()) {
        updateObserverLocation();
    }
    
    // Only calculate position if we have a valid TLE
    if (!_tle.valid) return;
    
    // Rate-limit calculations
    if (now - _lastCalculationMs < TRACKING_UPDATE_INTERVAL_MS) return;
    
    // Get current time
    uint32_t currentTime = gps.getUnixTime();
    if (currentTime == 0) {
        // Use system time as fallback
        currentTime = now / 1000 + 1700000000;  // Approximate
    }
    
    // Calculate current satellite position
    SatellitePosition pos;
    if (calculatePosition(currentTime, pos)) {
        _satPos = pos;
        
        // Handle zenith passes during tracking
        if (_mode == TrackingMode::AUTO) {
            handleZenithFlip();
            
            // Update stepper targets if satellite is visible
            if (_satPos.visible) {
                float targetAz = getTargetAzimuth();
                float targetEl = getTargetElevation();
                stepperControl.moveTo(targetAz, targetEl, TRACKING_SPEED_DEG_S);
            }
        }
    }
    
    _lastCalculationMs = now;
}

bool TrackingEngine::loadTLE(const char* name, const char* line1, const char* line2) {
    DEBUG_PRINTF("TrackingEngine: Loading TLE for %s\n", name);
    
    // Validate TLE format
    if (strlen(line1) < 69 || strlen(line2) < 69) {
        DEBUG_PRINTLN("TrackingEngine: Invalid TLE line length");
        return false;
    }
    
    if (line1[0] != '1' || line2[0] != '2') {
        DEBUG_PRINTLN("TrackingEngine: Invalid TLE line numbers");
        return false;
    }
    
    // Store TLE data
    strncpy(_tle.name, name, sizeof(_tle.name) - 1);
    strncpy(_tle.line1, line1, sizeof(_tle.line1) - 1);
    strncpy(_tle.line2, line2, sizeof(_tle.line2) - 1);
    
    // Initialize SGP4 with TLE
    _sgp4.site(_observerLat, _observerLon, _observerAlt / 1000.0);  // Alt in km
    
    if (!_sgp4.init(_tle.name, _tle.line1, _tle.line2)) {
        DEBUG_PRINTLN("TrackingEngine: SGP4 initialization failed");
        _tle.valid = false;
        return false;
    }
    
    _tle.valid = true;
    
    // Reset zenith flip state
    _zenithFlipActive = false;
    _zenithFlipDirection = false;
    
    DEBUG_PRINTF("TrackingEngine: TLE loaded successfully for %s\n", name);
    return true;
}

bool TrackingEngine::calculatePosition(uint32_t unixTime, SatellitePosition& pos) {
    if (!_tle.valid) return false;
    
    // Convert Unix time to Julian Date
    double jd = julianDateFromUnix(unixTime);
    
    // Update observer location in SGP4
    _sgp4.site(_observerLat, _observerLon, _observerAlt / 1000.0);
    
    // Calculate satellite position
    _sgp4.findsat(jd);
    
    // Get topocentric coordinates (relative to observer)
    pos.azimuth = _sgp4.satAz;
    pos.elevation = _sgp4.satEl;
    pos.range = _sgp4.satDist;
    
    // Get satellite geodetic coordinates
    pos.latitude = _sgp4.satLat;
    pos.longitude = _sgp4.satLon;
    pos.altitude = _sgp4.satAlt;
    
    // Determine visibility
    pos.visible = (pos.elevation > 0);
    
    // Check if satellite is illuminated (simplified)
    // A more accurate calculation would check Earth's shadow
    float sunAz, sunEl;
    getSunPosition(sunAz, sunEl);
    pos.illuminated = (sunEl > -6);  // Astronomical twilight
    
    return true;
}

bool TrackingEngine::getNextPass(PassInfo& pass) {
    if (!_tle.valid) return false;
    
    uint32_t now = gps.getUnixTime();
    if (now == 0) return false;
    
    // Search for next pass (up to 24 hours ahead)
    uint32_t searchEnd = now + 86400;
    uint32_t step = 60;  // 1 minute steps
    
    bool inPass = false;
    SatellitePosition pos;
    
    for (uint32_t t = now; t < searchEnd; t += step) {
        if (!calculatePosition(t, pos)) continue;
        
        if (!inPass && pos.elevation > 0) {
            // Found AOS
            inPass = true;
            pass.aosTime = t;
            pass.aosAz = pos.azimuth;
            pass.maxEl = pos.elevation;
            pass.maxElTime = t;
            pass.maxElAz = pos.azimuth;
            
            // Refine AOS time with smaller steps
            for (uint32_t t2 = t - step; t2 < t; t2 += 5) {
                if (calculatePosition(t2, pos) && pos.elevation > 0) {
                    pass.aosTime = t2;
                    pass.aosAz = pos.azimuth;
                    break;
                }
            }
        } else if (inPass) {
            // Track maximum elevation
            if (pos.elevation > pass.maxEl) {
                pass.maxEl = pos.elevation;
                pass.maxElTime = t;
                pass.maxElAz = pos.azimuth;
            }
            
            if (pos.elevation <= 0) {
                // Found LOS
                pass.losTime = t;
                pass.losAz = pos.azimuth;
                
                // Refine LOS time
                for (uint32_t t2 = t - step; t2 < t; t2 += 5) {
                    if (calculatePosition(t2, pos) && pos.elevation <= 0) {
                        pass.losTime = t2;
                        pass.losAz = pos.azimuth;
                        break;
                    }
                }
                
                return true;
            }
        }
    }
    
    return false;
}

bool TrackingEngine::startTracking() {
    if (!_tle.valid) {
        DEBUG_PRINTLN("TrackingEngine: Cannot start tracking - no TLE loaded");
        return false;
    }
    
    if (!gps.hasFix() && !gps.isUsingManualPosition()) {
        DEBUG_PRINTLN("TrackingEngine: Cannot start tracking - no GPS fix");
        return false;
    }
    
    _mode = TrackingMode::AUTO;
    _zenithFlipActive = false;
    _zenithFlipDirection = false;
    
    DEBUG_PRINTF("TrackingEngine: Started tracking %s\n", _tle.name);
    return true;
}

void TrackingEngine::stopTracking() {
    _mode = TrackingMode::IDLE;
    _zenithFlipActive = false;
    stepperControl.stop();
    
    DEBUG_PRINTLN("TrackingEngine: Tracking stopped");
}

void TrackingEngine::getObserverLocation(double& lat, double& lon, double& alt) const {
    lat = _observerLat;
    lon = _observerLon;
    alt = _observerAlt;
}

void TrackingEngine::setObserverLocation(double lat, double lon, double alt) {
    _observerLat = lat;
    _observerLon = lon;
    _observerAlt = alt;
    _useGPSLocation = false;
    
    // Update SGP4 site
    _sgp4.site(lat, lon, alt / 1000.0);
    
    DEBUG_PRINTF("TrackingEngine: Observer location set: %.6f, %.6f, %.1fm\n",
                 lat, lon, alt);
}

void TrackingEngine::updateObserverLocation() {
    if (_useGPSLocation && gps.hasFix()) {
        _observerLat = gps.getLatitude();
        _observerLon = gps.getLongitude();
        _observerAlt = gps.getAltitude();
    }
}

void TrackingEngine::handleZenithFlip() {
    // Look ahead to predict if we need to flip
    uint32_t futureTime = gps.getUnixTime() + ZENITH_LOOKAHEAD_SEC;
    SatellitePosition futurePos;
    
    if (!calculatePosition(futureTime, futurePos)) return;
    
    // Check if approaching zenith
    if (futurePos.elevation > ZENITH_THRESHOLD_DEG && !_zenithFlipActive) {
        // Calculate azimuth change
        float azChange = futurePos.azimuth - _satPos.azimuth;
        if (azChange > 180) azChange -= 360;
        if (azChange < -180) azChange += 360;
        
        // If large azimuth change expected, activate flip
        if (abs(azChange) > 90) {
            _zenithFlipActive = true;
            _zenithFlipDirection = (azChange > 0);  // Direction of flip
            
            DEBUG_PRINTLN("TrackingEngine: Zenith flip activated");
        }
    }
    
    // Deactivate flip when elevation drops
    if (_zenithFlipActive && _satPos.elevation < ZENITH_THRESHOLD_DEG - 5) {
        _zenithFlipActive = false;
        DEBUG_PRINTLN("TrackingEngine: Zenith flip deactivated");
    }
    
    _lastAzimuth = _satPos.azimuth;
}

float TrackingEngine::getTargetAzimuth() const {
    if (_zenithFlipActive) {
        // Flip azimuth by 180 degrees
        float flippedAz = _satPos.azimuth + 180.0f;
        if (flippedAz >= 360.0f) flippedAz -= 360.0f;
        return flippedAz;
    }
    return _satPos.azimuth;
}

float TrackingEngine::getTargetElevation() const {
    if (_zenithFlipActive) {
        // Invert elevation direction
        return 180.0f - _satPos.elevation;
    }
    return _satPos.elevation;
}

bool TrackingEngine::getSunPosition(float& az, float& el) {
    uint32_t now = gps.getUnixTime();
    if (now == 0) return false;
    
    double jd = julianDateFromUnix(now);
    calculateSunPosition(jd, _observerLat, _observerLon, az, el);
    
    return (el > 0);
}

bool TrackingEngine::getMoonPosition(float& az, float& el) {
    uint32_t now = gps.getUnixTime();
    if (now == 0) return false;
    
    double jd = julianDateFromUnix(now);
    calculateMoonPosition(jd, _observerLat, _observerLon, az, el);
    
    return (el > 0);
}

double TrackingEngine::julianDateFromUnix(uint32_t unixTime) {
    return UNIX_TO_JD_OFFSET + (double)unixTime / SECONDS_PER_DAY;
}

void TrackingEngine::calculateSunPosition(double jd, double lat, double lon, 
                                          float& az, float& el) {
    // Simplified solar position algorithm
    // Based on NOAA Solar Position Calculator
    
    double n = jd - 2451545.0;  // Days since J2000.0
    
    // Mean longitude (degrees)
    double L = fmod(280.46 + 0.9856474 * n, 360.0);
    
    // Mean anomaly (degrees)
    double g = fmod(357.528 + 0.9856003 * n, 360.0);
    double gRad = g * DEG_TO_RAD;
    
    // Ecliptic longitude (degrees)
    double lambda = L + 1.915 * sin(gRad) + 0.020 * sin(2 * gRad);
    double lambdaRad = lambda * DEG_TO_RAD;
    
    // Obliquity of ecliptic (degrees)
    double epsilon = 23.439 - 0.0000004 * n;
    double epsilonRad = epsilon * DEG_TO_RAD;
    
    // Right ascension and declination
    double sinLambda = sin(lambdaRad);
    double cosLambda = cos(lambdaRad);
    double sinEpsilon = sin(epsilonRad);
    double cosEpsilon = cos(epsilonRad);
    
    double ra = atan2(cosEpsilon * sinLambda, cosLambda);
    double dec = asin(sinEpsilon * sinLambda);
    
    // Greenwich Mean Sidereal Time
    double gmst = fmod(280.46061837 + 360.98564736629 * n, 360.0);
    double gmstRad = gmst * DEG_TO_RAD;
    
    // Local hour angle
    double ha = gmstRad + lon * DEG_TO_RAD - ra;
    
    // Convert to azimuth and elevation
    double latRad = lat * DEG_TO_RAD;
    double sinLat = sin(latRad);
    double cosLat = cos(latRad);
    double sinDec = sin(dec);
    double cosDec = cos(dec);
    double cosHa = cos(ha);
    double sinHa = sin(ha);
    
    // Elevation
    double sinEl = sinLat * sinDec + cosLat * cosDec * cosHa;
    el = asin(sinEl) * RAD_TO_DEG;
    
    // Azimuth
    double y = -cosDec * sinHa;
    double x = cosLat * sinDec - sinLat * cosDec * cosHa;
    az = atan2(y, x) * RAD_TO_DEG;
    if (az < 0) az += 360.0;
}

void TrackingEngine::calculateMoonPosition(double jd, double lat, double lon,
                                           float& az, float& el) {
    // Simplified lunar position algorithm
    // Less accurate than sun, but sufficient for alignment
    
    double n = jd - 2451545.0;  // Days since J2000.0
    
    // Moon's mean longitude (degrees)
    double L = fmod(218.316 + 13.176396 * n, 360.0);
    
    // Moon's mean anomaly (degrees)
    double M = fmod(134.963 + 13.064993 * n, 360.0);
    double MRad = M * DEG_TO_RAD;
    
    // Moon's mean distance from ascending node (degrees)
    double F = fmod(93.272 + 13.229350 * n, 360.0);
    double FRad = F * DEG_TO_RAD;
    
    // Ecliptic longitude
    double lambda = L + 6.289 * sin(MRad);
    double lambdaRad = lambda * DEG_TO_RAD;
    
    // Ecliptic latitude
    double beta = 5.128 * sin(FRad);
    double betaRad = beta * DEG_TO_RAD;
    
    // Obliquity
    double epsilon = 23.439 * DEG_TO_RAD;
    
    // Convert to equatorial coordinates
    double sinLambda = sin(lambdaRad);
    double cosLambda = cos(lambdaRad);
    double sinBeta = sin(betaRad);
    double cosBeta = cos(betaRad);
    double sinEpsilon = sin(epsilon);
    double cosEpsilon = cos(epsilon);
    
    double ra = atan2(sinLambda * cosEpsilon - tan(betaRad) * sinEpsilon, cosLambda);
    double dec = asin(sinBeta * cosEpsilon + cosBeta * sinEpsilon * sinLambda);
    
    // Greenwich Mean Sidereal Time
    double gmst = fmod(280.46061837 + 360.98564736629 * n, 360.0);
    double gmstRad = gmst * DEG_TO_RAD;
    
    // Local hour angle
    double ha = gmstRad + lon * DEG_TO_RAD - ra;
    
    // Convert to azimuth and elevation
    double latRad = lat * DEG_TO_RAD;
    double sinLat = sin(latRad);
    double cosLat = cos(latRad);
    double sinDec = sin(dec);
    double cosDec = cos(dec);
    double cosHa = cos(ha);
    double sinHa = sin(ha);
    
    double sinEl = sinLat * sinDec + cosLat * cosDec * cosHa;
    el = asin(sinEl) * RAD_TO_DEG;
    
    double y = -cosDec * sinHa;
    double x = cosLat * sinDec - sinLat * cosDec * cosHa;
    az = atan2(y, x) * RAD_TO_DEG;
    if (az < 0) az += 360.0;
}
