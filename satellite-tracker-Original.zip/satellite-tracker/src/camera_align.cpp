/**
 * @file camera_align.cpp
 * @brief Camera-based alignment implementation
 */

#include "camera_align.h"
#include "tracking_engine.h"
#include "stepper_control.h"
#include "gps.h"

// Global instance
CameraAlign cameraAlign;

CameraAlign::CameraAlign()
    : _initialized(false)
    , _lastFrame(nullptr)
    , _sunThreshold(SUN_BRIGHTNESS_THRESHOLD)
    , _moonThreshold(MOON_BRIGHTNESS_THRESHOLD)
    , _minBlobSize(MIN_BLOB_PIXELS)
    , _fovH(CAMERA_FOV_H)
    , _fovV(CAMERA_FOV_V)
    , _frameWidth(640)
    , _frameHeight(480)
{
}

bool CameraAlign::begin() {
    DEBUG_PRINTLN("CameraAlign: Initializing...");
    
    if (!initCamera()) {
        DEBUG_PRINTLN("CameraAlign: Camera initialization failed");
        return false;
    }
    
    _initialized = true;
    DEBUG_PRINTLN("CameraAlign: Initialization complete");
    return true;
}

bool CameraAlign::initCamera() {
    camera_config_t config;
    
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = CAM_PIN_D0;
    config.pin_d1 = CAM_PIN_D1;
    config.pin_d2 = CAM_PIN_D2;
    config.pin_d3 = CAM_PIN_D3;
    config.pin_d4 = CAM_PIN_D4;
    config.pin_d5 = CAM_PIN_D5;
    config.pin_d6 = CAM_PIN_D6;
    config.pin_d7 = CAM_PIN_D7;
    config.pin_xclk = CAM_PIN_XCLK;
    config.pin_pclk = CAM_PIN_PCLK;
    config.pin_vsync = CAM_PIN_VSYNC;
    config.pin_href = CAM_PIN_HREF;
    config.pin_sccb_sda = CAM_PIN_SIOD;
    config.pin_sccb_scl = CAM_PIN_SIOC;
    config.pin_pwdn = CAM_PIN_PWDN;
    config.pin_reset = CAM_PIN_RESET;
    config.xclk_freq_hz = 20000000;
    config.frame_size = CAMERA_FRAME_SIZE;
    config.pixel_format = PIXFORMAT_JPEG;
    config.grab_mode = CAMERA_GRAB_WHEN_EMPTY;
    config.fb_location = CAMERA_FB_IN_PSRAM;
    config.jpeg_quality = CAMERA_JPEG_QUALITY;
    config.fb_count = CAMERA_FB_COUNT;
    
    // Initialize camera
    esp_err_t err = esp_camera_init(&config);
    if (err != ESP_OK) {
        DEBUG_PRINTF("CameraAlign: Camera init failed with error 0x%x\n", err);
        return false;
    }
    
    // Get sensor and configure
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_brightness(s, 0);
        s->set_contrast(s, 0);
        s->set_saturation(s, 0);
        s->set_whitebal(s, 1);
        s->set_awb_gain(s, 1);
        s->set_wb_mode(s, 0);
        s->set_exposure_ctrl(s, 1);
        s->set_aec2(s, 1);
        s->set_gain_ctrl(s, 1);
        s->set_agc_gain(s, 0);
        s->set_gainceiling(s, (gainceiling_t)6);
        s->set_bpc(s, 1);
        s->set_wpc(s, 1);
        s->set_raw_gma(s, 1);
        s->set_lenc(s, 1);
        s->set_hmirror(s, 0);
        s->set_vflip(s, 0);
        s->set_dcw(s, 1);
    }
    
    // Update frame dimensions based on actual frame size
    _frameWidth = 640;
    _frameHeight = 480;
    
    return true;
}

AlignmentResult CameraAlign::alignToSun() {
    if (!_initialized) {
        AlignmentResult result;
        result.success = false;
        result.errorMessage = "Camera not initialized";
        return result;
    }
    
    // Get calculated sun position
    float sunAz, sunEl;
    if (!trackingEngine.getSunPosition(sunAz, sunEl)) {
        AlignmentResult result;
        result.success = false;
        result.errorMessage = "Sun below horizon";
        return result;
    }
    
    DEBUG_PRINTF("CameraAlign: Sun position: Az=%.2f, El=%.2f\n", sunAz, sunEl);
    
    // Configure camera for bright sun (low exposure)
    setExposure(10);
    setGain(0);
    delay(500);  // Let camera adjust
    
    return performAlignment(sunAz, sunEl, _sunThreshold, "Sun");
}

AlignmentResult CameraAlign::alignToMoon() {
    if (!_initialized) {
        AlignmentResult result;
        result.success = false;
        result.errorMessage = "Camera not initialized";
        return result;
    }
    
    // Get calculated moon position
    float moonAz, moonEl;
    if (!trackingEngine.getMoonPosition(moonAz, moonEl)) {
        AlignmentResult result;
        result.success = false;
        result.errorMessage = "Moon below horizon";
        return result;
    }
    
    DEBUG_PRINTF("CameraAlign: Moon position: Az=%.2f, El=%.2f\n", moonAz, moonEl);
    
    // Configure camera for moon (moderate exposure)
    resetAutoExposure();
    delay(1000);  // Let camera auto-adjust
    
    return performAlignment(moonAz, moonEl, _moonThreshold, "Moon");
}

AlignmentResult CameraAlign::performAlignment(float targetAz, float targetEl,
                                               uint8_t threshold, const char* bodyName) {
    AlignmentResult result;
    result.success = false;
    
    // Move antenna to calculated position
    DEBUG_PRINTF("CameraAlign: Moving to %s position\n", bodyName);
    stepperControl.moveTo(targetAz, targetEl, MAX_SLEW_SPEED_DEG_S);
    
    // Wait for movement to complete
    uint32_t timeout = millis() + 30000;
    while (stepperControl.isMoving() && millis() < timeout) {
        stepperControl.update();
        delay(10);
    }
    
    if (stepperControl.isMoving()) {
        result.errorMessage = "Movement timeout";
        return result;
    }
    
    // Capture frame
    camera_fb_t* fb = esp_camera_fb_get();
    if (!fb) {
        result.errorMessage = "Frame capture failed";
        return result;
    }
    
    DEBUG_PRINTF("CameraAlign: Captured frame %dx%d, %d bytes\n",
                 fb->width, fb->height, fb->len);
    
    // Convert to grayscale for processing
    // For JPEG, we need to decode first - simplified: use raw format
    // In production, switch to RGB565 or GRAYSCALE format for processing
    
    // Allocate grayscale buffer
    size_t graySize = fb->width * fb->height;
    uint8_t* grayscale = (uint8_t*)ps_malloc(graySize);
    
    if (!grayscale) {
        esp_camera_fb_return(fb);
        result.errorMessage = "Memory allocation failed";
        return result;
    }
    
    // Simple brightness extraction from JPEG
    // Note: For accurate results, use PIXFORMAT_GRAYSCALE
    convertToGrayscale(fb, grayscale);
    
    // Detect bright blob
    BlobDetection blob = detectBrightBlob(grayscale, fb->width, fb->height, threshold);
    
    free(grayscale);
    
    if (!blob.found) {
        esp_camera_fb_return(fb);
        result.errorMessage = String(bodyName) + " not detected in frame";
        return result;
    }
    
    DEBUG_PRINTF("CameraAlign: Blob detected at (%d, %d), size=%d\n",
                 blob.centerX, blob.centerY, blob.pixelCount);
    
    // Calculate pixel offset from frame center
    int centerX = fb->width / 2;
    int centerY = fb->height / 2;
    int offsetX = blob.centerX - centerX;
    int offsetY = blob.centerY - centerY;
    
    esp_camera_fb_return(fb);
    
    // Convert pixel offset to angular offset
    float azError = pixelToAngleH(offsetX);
    float elError = pixelToAngleV(offsetY);
    
    // Current position error means we need to apply opposite offset
    result.azOffset = -azError;
    result.elOffset = elError;  // Note: Y increases downward in image
    
    result.success = true;
    result.blobX = blob.centerX;
    result.blobY = blob.centerY;
    result.blobSize = blob.pixelCount;
    result.confidence = min(1.0f, (float)blob.pixelCount / 500.0f);
    
    // Apply calibration offset
    float currentAzOffset = stepperControl.getAzimuthOffset();
    float currentElOffset = stepperControl.getElevationOffset();
    
    stepperControl.setCalibrationOffset(
        currentAzOffset + result.azOffset,
        currentElOffset + result.elOffset
    );
    
    DEBUG_PRINTF("CameraAlign: Alignment complete. Offsets: Az=%.3f, El=%.3f\n",
                 result.azOffset, result.elOffset);
    
    return result;
}

BlobDetection CameraAlign::detectBrightBlob(uint8_t* grayscale, int width, int height,
                                             uint8_t threshold) {
    BlobDetection result;
    result.found = false;
    result.centerX = 0;
    result.centerY = 0;
    result.pixelCount = 0;
    result.brightness = 0;
    
    // Simple centroid calculation for bright pixels
    long sumX = 0;
    long sumY = 0;
    long sumBrightness = 0;
    int count = 0;
    
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            uint8_t pixel = grayscale[y * width + x];
            if (pixel >= threshold) {
                sumX += x * pixel;
                sumY += y * pixel;
                sumBrightness += pixel;
                count++;
            }
        }
    }
    
    if (count >= _minBlobSize && sumBrightness > 0) {
        result.found = true;
        result.centerX = sumX / sumBrightness;
        result.centerY = sumY / sumBrightness;
        result.pixelCount = count;
        result.brightness = sumBrightness / count;
    }
    
    return result;
}

void CameraAlign::convertToGrayscale(camera_fb_t* fb, uint8_t* output) {
    // For JPEG format, this is a simplified approximation
    // In production, use PIXFORMAT_GRAYSCALE for direct grayscale capture
    
    if (fb->format == PIXFORMAT_JPEG) {
        // Estimate brightness from JPEG data (very rough)
        // This is a hack - proper implementation would decode JPEG
        size_t graySize = fb->width * fb->height;
        memset(output, 128, graySize);  // Default mid-gray
        
        // Sample JPEG data for brightness hints
        for (size_t i = 0; i < fb->len && i < graySize; i++) {
            output[i % graySize] = fb->buf[i];
        }
    } else if (fb->format == PIXFORMAT_GRAYSCALE) {
        memcpy(output, fb->buf, fb->width * fb->height);
    } else if (fb->format == PIXFORMAT_RGB565) {
        // Convert RGB565 to grayscale
        uint16_t* rgb = (uint16_t*)fb->buf;
        for (int i = 0; i < fb->width * fb->height; i++) {
            uint16_t pixel = rgb[i];
            uint8_t r = (pixel >> 11) & 0x1F;
            uint8_t g = (pixel >> 5) & 0x3F;
            uint8_t b = pixel & 0x1F;
            // Convert to 8-bit and calculate luminance
            r = (r * 255) / 31;
            g = (g * 255) / 63;
            b = (b * 255) / 31;
            output[i] = (r * 77 + g * 150 + b * 29) >> 8;
        }
    }
}

float CameraAlign::pixelToAngleH(int pixelOffset) {
    // Convert horizontal pixel offset to degrees
    // Positive offset = object is right of center = antenna pointing left of target
    return (float)pixelOffset * _fovH / (float)_frameWidth;
}

float CameraAlign::pixelToAngleV(int pixelOffset) {
    // Convert vertical pixel offset to degrees
    // Positive offset = object is below center = antenna pointing above target
    return (float)pixelOffset * _fovV / (float)_frameHeight;
}

size_t CameraAlign::captureFrame(uint8_t* buffer, size_t maxLen) {
    if (!_initialized) return 0;
    
    camera_fb_t* fb = esp_camera_fb_get();
    if (!fb) return 0;
    
    size_t len = min(fb->len, maxLen);
    memcpy(buffer, fb->buf, len);
    
    esp_camera_fb_return(fb);
    return len;
}

const uint8_t* CameraAlign::getLastFrame(size_t& len) {
    if (!_initialized) {
        len = 0;
        return nullptr;
    }
    
    if (_lastFrame) {
        esp_camera_fb_return(_lastFrame);
    }
    
    _lastFrame = esp_camera_fb_get();
    if (!_lastFrame) {
        len = 0;
        return nullptr;
    }
    
    len = _lastFrame->len;
    return _lastFrame->buf;
}

void CameraAlign::setExposure(int exposure) {
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_exposure_ctrl(s, 0);  // Disable auto exposure
        s->set_aec_value(s, exposure);
    }
}

void CameraAlign::setGain(int gain) {
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_gain_ctrl(s, 0);  // Disable auto gain
        s->set_agc_gain(s, gain);
    }
}

void CameraAlign::resetAutoExposure() {
    sensor_t* s = esp_camera_sensor_get();
    if (s) {
        s->set_exposure_ctrl(s, 1);  // Enable auto exposure
        s->set_gain_ctrl(s, 1);      // Enable auto gain
        s->set_aec2(s, 1);           // Enable AEC DSP
    }
}
