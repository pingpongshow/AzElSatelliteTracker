/**
 * @file web_server.h
 * @brief Web server for UI and REST API
 * 
 * Provides web-based user interface and REST API endpoints
 * for controlling the satellite tracker.
 */

#ifndef WEB_SERVER_H
#define WEB_SERVER_H

#include <Arduino.h>
#include <ESPAsyncWebServer.h>
#include <ArduinoJson.h>
#include "config.h"

/**
 * @class WebServer
 * @brief Async web server with REST API
 */
class WebServer {
public:
    WebServer();
    ~WebServer();
    
    /**
     * @brief Initialize and start web server
     * @return true if started successfully
     */
    bool begin();
    
    /**
     * @brief Stop web server
     */
    void stop();
    
    /**
     * @brief Update server (broadcast status via WebSocket)
     */
    void update();
    
    /**
     * @brief Check if server is running
     */
    bool isRunning() const { return _running; }
    
    /**
     * @brief Broadcast status to all WebSocket clients
     */
    void broadcastStatus();
    
    /**
     * @brief Send event to WebSocket clients
     * @param event Event name
     * @param data Event data as JSON string
     */
    void sendEvent(const char* event, const char* data);

private:
    AsyncWebServer* _server;
    AsyncWebSocket* _ws;
    bool _running;
    uint32_t _lastBroadcast;
    
    // Route setup
    void setupRoutes();
    void setupAPIRoutes();
    void setupWebSocketHandler();
    
    // Static file handlers
    void handleRoot(AsyncWebServerRequest* request);
    void handleNotFound(AsyncWebServerRequest* request);
    
    // API handlers - Status
    void handleGetStatus(AsyncWebServerRequest* request);
    void handleGetPosition(AsyncWebServerRequest* request);
    void handleGetGPS(AsyncWebServerRequest* request);
    void handleGetConfig(AsyncWebServerRequest* request);
    
    // API handlers - Control
    void handleSetPosition(AsyncWebServerRequest* request, JsonVariant& json);
    void handleStop(AsyncWebServerRequest* request);
    void handlePark(AsyncWebServerRequest* request);
    void handleHome(AsyncWebServerRequest* request);
    void handleSetHome(AsyncWebServerRequest* request);
    void handleCalibrate(AsyncWebServerRequest* request, JsonVariant& json);
    
    // API handlers - Tracking
    void handleStartTracking(AsyncWebServerRequest* request, JsonVariant& json);
    void handleStopTracking(AsyncWebServerRequest* request);
    void handleGetNextPass(AsyncWebServerRequest* request);
    
    // API handlers - TLE
    void handleGetTLEs(AsyncWebServerRequest* request);
    void handleLoadTLE(AsyncWebServerRequest* request, JsonVariant& json);
    void handleFetchTLE(AsyncWebServerRequest* request, JsonVariant& json);
    void handleDeleteTLE(AsyncWebServerRequest* request, JsonVariant& json);
    
    // API handlers - WiFi
    void handleGetNetworks(AsyncWebServerRequest* request);
    void handleConnectWiFi(AsyncWebServerRequest* request, JsonVariant& json);
    void handleGetWiFiStatus(AsyncWebServerRequest* request);
    
    // API handlers - System
    void handleReboot(AsyncWebServerRequest* request);
    void handleFactoryReset(AsyncWebServerRequest* request);
    void handleGetSystemInfo(AsyncWebServerRequest* request);
    void handleSetConfig(AsyncWebServerRequest* request, JsonVariant& json);
    
    // API handlers - GPS
    void handleSetManualGPS(AsyncWebServerRequest* request, JsonVariant& json);
    
    // WebSocket handler
    void onWebSocketEvent(AsyncWebSocket* server, AsyncWebSocketClient* client,
                          AwsEventType type, void* arg, uint8_t* data, size_t len);
    
    // Helper methods
    void sendJSON(AsyncWebServerRequest* request, JsonDocument& doc, int code = 200);
    void sendError(AsyncWebServerRequest* request, const char* message, int code = 400);
    void sendOK(AsyncWebServerRequest* request, const char* message = "OK");
    String buildStatusJSON();
};

// Global instance
extern WebServer webServer;

#endif // WEB_SERVER_H
